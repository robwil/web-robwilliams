/* These are a few classes I wrote to contain the data for interactive objects in the program.
   Because of the way these are written, all I have to do in main program is populate the values of Task and then everything happens pretty much automatically.
   I realize the OO design is horrible (this is basically just procedural programming wrapped in classes), but for this project it works fine. */

#include <vector>
#include <string>

class InventoryItem {
public:
	int ID; // ID is unique number used to ID this item
	GLTexture* picture; // pointer to GLTexture object representing the BMP of this object, for displaying the inventory image
	string message; // description of using item, for display purposes
	int* mood; // pointer to mood in main program that this item affects
	int* mood2; // pointer to mood in main program that this item affects (some items affect 2 moods, that's why there's two)
	int delta; // how much to change the above *mood per second
	int delta2; // same as delta but for second mood
	int total_time; // how many seconds this entire task takes
	InventoryItem(int ID_, GLTexture* picture_, string message_, int* mood_, 
		int* mood2_, int delta_, int delta2_, int total_time_) : ID(ID_), picture(picture_), 
		message(message_), mood(mood_), mood2(mood2_), delta(delta_), delta2(delta2_), total_time(total_time_) {}
	InventoryItem() : message("") {
		ID = -1;
		picture = NULL;
		mood = NULL;
		mood2 = NULL;
		delta = 0;
		delta2 = 0;
		total_time = 0;
	}

};

class TaskMessage {
public:
	string value;
	bool done;
	TaskMessage(string value_, bool done_) : done(done_), value(value_) {}
	TaskMessage() : value("") {
		done = false;
	}
};

class Task {
public:
	int ID; // ID representing the Picking Name of the object associated with this task
	string message; // message that will be printed to screen while task is being done
	int *mood; // pointers to the actual mood value in main program, so that we can change it from here (set to NULL means don't modify any mood -- like objects that just produce inventory item)
	int delta; // how much to change the main mood of this object per second
	int total_time; // time in seconds that this task takes
	int cur_time; // time left for task while it is being done
	// Note: There are objects where more than one mood is changed at a time, and in those cases the Inventory Item is used to hold those *moods and deltas and total_times
	// In those cases, the *mood, delta defined here refer to the MAIN mood of the object that isn't contingent on which item is being used
	bool time_set; // whether or not we have already setup total_time from inventory item, in the case of item-variant objects
	bool need_flag; // whether a flag must be set for this task to happen (used for Sink, which requires them to have made food or went to bathroom)
	bool *flag; // pointer to flag in main program to check (only checked if need_flag == true)
	InventoryItem *inventory; // pointer to user's inventory from main program
	InventoryItem *give; // item to give the user if they interact with this object
	string flag_message; // error message to give user if they try to use object that needs a flag that is false
	string inventory_message; // error message to give user if they try to use object without acceptable item in their inventory
	int showing_message; // how many seconds to show message
	vector<int> acceptableItems; // IDs of InventoryItems which are acceptable to use here
	Task(int ID_, string message_, int* mood_, int delta_, int total_time_, bool time_set_, bool need_flag_, bool* flag_, vector<int> acceptableItems_,
		InventoryItem *inventory_, InventoryItem* give_, string flag_message_, string inventory_message_) : ID(ID_), message(message_), mood(mood_), 
		delta(delta_), total_time(total_time_), cur_time(total_time_), time_set(time_set_), need_flag(need_flag_), flag(flag_), acceptableItems(acceptableItems_), 
		inventory(inventory_), give(give_), flag_message(flag_message_), inventory_message(inventory_message_), showing_message(3) {}
	Task() : message(""), acceptableItems(), give(), flag_message(""), inventory_message("") {
		ID = -1;
		mood = NULL;
		delta = 0;
		total_time = 0;
		time_set = false;
		need_flag = false;
		flag = NULL;
		inventory = NULL;
		showing_message = 3;
	}
		
	TaskMessage doTask() { // does the task for 1 second, and returns a TaskMessage which is handled by main program
		if (need_flag && !(*flag)) {
			if (showing_message <= 0) showing_message = 2;
			return TaskMessage(flag_message, (--showing_message <= 0));
		}
		// might be done before time is up if one of the mood bars is filled
		// check this for inventory item
		if (!acceptableItems.empty()) { // easiest way to check if we're using inventory item
			if (inventory->delta > 0 && *(inventory->mood) >= 100) {
				*(inventory->mood) = 100;
				if (showing_message <= 0) showing_message = 2;
				if (--showing_message <= 0) cur_time = total_time;
				return TaskMessage("One of the associated mood bars is already at the max value. \nCan't continue", (showing_message <= 0));
			} else if (inventory->delta < 0 && *(inventory->mood) <= 0) {
				*(inventory->mood) = 0;
				if (showing_message <= 0) showing_message = 2;
				if (--showing_message <= 0) cur_time = total_time;
				return TaskMessage("One of the associated mood bars is already at the min value. \nCan't continue", (showing_message <= 0));
			}
			if (inventory->delta2 > 0 && *(inventory->mood2) >= 100) {
				*(inventory->mood2) = 100;
				if (showing_message <= 0) showing_message = 2;
				if (--showing_message <= 0) cur_time = total_time;
				return TaskMessage("One of the associated mood bars is already at the max value. \nCan't continue", (showing_message <= 0));
			} else if (inventory->delta2 < 0 && *(inventory->mood2) <= 0) {
				*(inventory->mood2) = 0;
				if (showing_message <= 0) showing_message = 2;
				if (--showing_message <= 0) cur_time = total_time;
				return TaskMessage("One of the associated mood bars is already at the min value. \nCan't continue", (showing_message <= 0));
			}
		}
		// finally check local delta/mood for filling bar
		if (delta > 0 && *mood >= 100) {
			*mood = 100;
			if (ID == 11) return TaskMessage(message, true); // Checkers is exception because it naturally goes until bar is max'd out.
			if (showing_message <= 0) showing_message = 2;
			if (--showing_message <= 0) cur_time = total_time;
			return TaskMessage("One of the associated mood bars is already at the max value. \nCan't continue", (showing_message <= 0));
		} else if (delta < 0 && *mood <= 0) {
			*mood = 0;
			if (ID == 5) return TaskMessage(message, true); // Toilet is exception because it naturally goes until bar is min'd out.
			if (showing_message <= 0) showing_message = 2;
			if (--showing_message <= 0) cur_time = total_time;
			return TaskMessage("One of the associated mood bars is already at the min value. \nCan't continue", (showing_message <= 0));
		}

		// if bars aren't filled, proceed with mood changing
		TaskMessage ret;
		if (acceptableItems.empty()) { // doesn't require items, so proceed as normal
			// items not requiring items only have one mood, so add delta to that mood1 and store message1 as return message
			if (mood != NULL)
				*mood += delta;
			if (give != NULL) // if we need to give user item, give it to them when 1 second left of task (since it will -- below and become 0, i.e. done)
				if (cur_time == 1)
					*inventory = *give;
			ret.value = message;
		} else {
			vector<int>::iterator it;
			for (it = acceptableItems.begin(); it != acceptableItems.end(); ++it) {
				if (*it == inventory->ID) { // inventory contains acceptable item, so use it
					if (!time_set) { // only copy total_time once so we can decrement it below
						total_time = inventory->total_time;
						cur_time = total_time;
						time_set = true;
					}
					*mood += delta; // add main item delta to main mood
					*(inventory->mood) += inventory->delta; // add delta1 of item to mood1 of item
					if (inventory->mood2 != NULL) // if there is one, add delta2 of item to mood2 of item
						*(inventory->mood2) += inventory->delta2;
					ret.value = (inventory->message) + message;
					break;
				}
			}
			if (it == acceptableItems.end() && ID == 6 && inventory->ID == 3) { // special message for wine on couch
				if (showing_message <= 0) showing_message = 3;
				return TaskMessage("You can't drink wine on the couch -- wouldn't want to spill it!", (--showing_message <= 0));
			}
			if (it == acceptableItems.end()) { // means we made it through entire loop without finding acceptable item
				if (showing_message <= 0) showing_message = 3;
				return TaskMessage(inventory_message, (--showing_message <= 0));
			}
		}
		
		// if total_time is up then we're definitely done
		if (--cur_time <= 0)
			ret.done = true;

		// reset cur_time so on next use of this item, it is setup correctly
		if (ret.done)
			cur_time = total_time;

		return ret;
	}
};


#include <iostream>
#include <cmath>
#include <ctime>
#include <windows.h>
#include <GL/glut.h>
#include "vector.hpp"
#include "vssg.hpp"
#include "pui/pu.h"
#include "GLTexture.h"
#include "Task.hpp"
#include "KeyFrame.hpp"
using namespace std;

// window height and width -- these values don't matter since they come from Game Mode anyway -- see GameModeString in main() function
int window_width = 1280;
int window_height = 720;

// define PUI widgets
puText			*timer_text;
puText			*satisfaction_text;
puText			*position_text;
puText			*rotation_text;
puText			*task_text;
puText			*game_text;
puText			*help_text;
puSlider		*hunger_slider;
puSlider		*bladder_slider;
puSlider		*leisure_slider;
puSlider		*comfort_slider;
puSlider		*hygiene_slider;
puSlider		*thirst_slider;

// define images
GLTexture *oven_pic, *fridge_pic, *tea_pic, *wine_pic, *book_pic, *placeholder_pic;
InventoryItem placeholder;

// camera globals
SF3dVector position, rotation; // position (translation) and rotation of camera
double angle; // angle camera is facing
int lastx = 0, lasty = 0;

// global display lists
GLuint tree_list;

// model objects to hold 3DS models we're loading in
Model_3DS *house_model, *windows_model, *oven_model, *sink_model, *toilet_model, *sofa_model, *fridge_model, 
*chair_model, *table_model, *bookshelf_model, *teaset_model, *wine_model, *checkers_model, *shower_model,
*car_model, *road_model;

// names used for selection/picking
enum {NONE, KITCHEN_TABLE, TEASET_TABLE, OVEN, SINK, TOILET, SOFA, FRIDGE, CHAIR, BOOKSHELF, WINE, CHECKERS, SHOWER};
//     0      1              2            3      4       5     6     7      8        9        10    11         12

// IDs used for inventory items
enum {OVEN_FOOD=0, FRIDGE_FOOD=1, TEA_DRINK=2, WINE_DRINK=3, BOOK_ITEM=4, PLACEHOLDER=5};
//     0           1             2         3           4


// global state
// intro scene variables
bool intro_screen; // whether or not we are showing intro screen (which displays totally different scene)
double intro_car_posx, intro_car_posy, intro_car_posz, intro_car_rotx, intro_car_roty, intro_car_rotz; // store data for car during intro scene
double intro_cam_pos1x, intro_cam_pos1y, intro_cam_pos1z, intro_cam_rot1x, intro_cam_rot1y; // store data for overhead camera during intro scene
double intro_cam_pos2x, intro_cam_pos2y, intro_cam_pos2z, intro_cam_rot2x, intro_cam_rot2y; // store data for driver camera during intro sceneint current_frame; // current keyframe it is on
int current_frame;
int frames_done; // how many frames animated so far in current keyframe
KeyFrame frames[12]; // holds the keyframe data for the intro scene animation
int viewport; // holds which viewport of the camera we are using (Overhead = 1, Driver = 2)
// non-intro scene variables
bool select_mode; // true when in selection mode
int satisfaction; // overall satisfaction of character in game
time_t orig_time, last_time, cur_time; // used to maintain timer
Task tasks[13]; // holds the data for every possible task
InventoryItem inventory; // holds the current inventory item in user's possession
InventoryItem items[5]; // holds the data for every possible item
char* task; // the string description of the task that is currently being performed (if any)
char* task_buf; // used to sprintf some stuff into task
char* ellipsis; // used to show varying amount of periods to show time elapsing during tasks
bool doing_task; // used to tell program whether we are in task_do mode or not (when interaction temporarily disable)
Task *current_task; // pointer to current task we are doing
int bladder, hunger, thirst, comfort, hygiene, leisure; // hold values for moods
bool cooked_or_bathroom; // set to true if they just cooked on oven or used toilet
bool won_game; // whether game is won or not
bool first_mouse; // whether mouse moved for first time in game yet (used to setup initial lastx,lasty for mouse rotation of camera)

// quadric object for using gluCylinder in making trees
GLUquadricObj *quadratic;

// root node of scene graph
vssgNode *root, *intro_root;

// some materials to use throughout the program
material_struct* no_material = new material_struct(0,0,0,1, 0,0,0,1, 0,0,0,1, 0); // used to clear material to nothing (doesn't reflect any light -- shows up black)
material_struct* red_material = new material_struct(132/255.0, 54/255.0, 54/255.0, 1.0, 132/255.0, 54/255.0, 54/255.0, 1.0, 0,0,0,1, 0); // used for interior of large house (house2)
material_struct* blue_material = new material_struct(22/255.0, 89/255.0, 141/255.0, 1.0, 22/255.0, 89/255.0, 141/255.0, 1.0, 0,0,0,1, 0); // used for exterior of large house (house2)
material_struct* yellow_material = new material_struct(242/255.0,177/255.0,77/255.0, 1.0, 242/255.0,177/255.0,77/255.0, 1.0, 0,0,0,1, 0); // used for exterior of normal houses (house)
material_struct* glass_material = new material_struct(1,1,1,1, 125/255.0, 60/255.0, 60/255.0, 0.5, 1,1,1,1,1);; // slightly translucent (50%) reddish material used for tinted windows
GLfloat tree_trunk_material[] = {142/255.0,111/255.0,90/255.0, 1.0}; // used for trunk of tree (tan color)
GLfloat tree_material[] = {24/255.0,94/255.0,0, 1.0}; // used for tree (greenish color) 
GLfloat white_material[] = {1,1,1,1};
GLfloat global_ambient[] = {0.2, 0.2, 0.2, 1.0}; // used to setup global ambient (outdoor) light 

// Take an amount of seconds and split it into HH:MM:SS and output as char* string
char* convertTime(int seconds) {
	int hours = seconds / 3600;
	int minutes = (seconds - hours*3600) / 60;
	seconds = (seconds - hours*3600 - minutes*60);
	char* str = (char*)calloc(20,sizeof(char));
	sprintf(str, "Timer %02d:%02d:%02d", hours, minutes, seconds);
	return str;
}

// Convert satisfaction (int) to char* string for display purposes
char* showSatisfaction() {
	char* str = (char*)calloc(20,sizeof(char));
	satisfaction = 0;
	if (hunger <= 0) satisfaction += 15;
	if (bladder <= 0) satisfaction += 15;
	if (hygiene >= 100) satisfaction += 15;
	if (thirst <= 0) satisfaction += 15;
	if (leisure >= 100) satisfaction += 15;
	if (comfort >= 100) satisfaction += 25;
	sprintf(str, "Satisfaction %d%%", satisfaction);
	if (satisfaction >= 100) {
		won_game = true;
		sprintf(task_buf, "You win the game in %d seconds.\nPress X to quit or R to reset game.", cur_time);
		task = task_buf;
	} else if (satisfaction == 75) {
		won_game = true;
		task = "You lost the game since it's now impossible for you to fill Comfort.\nThat's right, this isn't just a race against time! Press X to quit or R to reset game.";
	}
	return str;
}

char* showCameraPos() {
	char* str = (char*)calloc(40,sizeof(char));
	sprintf(str, "Position: x: %5f, y: %5f, z: %5f",position.x,position.y,position.z);
	return str;
}
char* showCameraRot() {
	char* str = (char*)calloc(40,sizeof(char));
	sprintf(str, "Rotation: x: %5f, y: %5f, z: %5f",rotation.x,rotation.y,rotation.z);
	return str;
}

// function that runs while OpenGL is Idle. Used for animating intro scene and also animating ellipsis of doing a task in main game.
void idleFunc() {
	if (intro_screen) { // in intro screen, idle func interpolates between key frames, causing animation
		if (current_frame < 11) { // < 11 because when on last key frame (current_frame == 11), we're done
			// interpolate between current frame and next frame
			double f = (double)(frames_done) / (frames[current_frame].frames);
			intro_car_posx = frames[current_frame].car_pos.x * (1 - f) + frames[current_frame+1].car_pos.x * f;
			intro_car_posy = frames[current_frame].car_pos.y * (1 - f) + frames[current_frame+1].car_pos.y * f;
			intro_car_posz = frames[current_frame].car_pos.z * (1 - f) + frames[current_frame+1].car_pos.z * f;
			intro_car_rotx = frames[current_frame].car_rot.x * (1 - f) + frames[current_frame+1].car_rot.x * f;
			intro_car_roty = frames[current_frame].car_rot.y * (1 - f) + frames[current_frame+1].car_rot.y * f;
			intro_car_rotz = frames[current_frame].car_rot.z * (1 - f) + frames[current_frame+1].car_rot.z * f;
			intro_cam_pos1x = frames[current_frame].cam_pos1.x * (1 - f) + frames[current_frame+1].cam_pos1.x * f;
			intro_cam_pos1y = frames[current_frame].cam_pos1.y * (1 - f) + frames[current_frame+1].cam_pos1.y * f;
			intro_cam_pos1z = frames[current_frame].cam_pos1.z * (1 - f) + frames[current_frame+1].cam_pos1.z * f;
			intro_cam_rot1x = frames[current_frame].cam_rot1.x * (1 - f) + frames[current_frame+1].cam_rot1.x * f;
			intro_cam_rot1y = frames[current_frame].cam_rot1.y * (1 - f) + frames[current_frame+1].cam_rot1.y * f;
			intro_cam_pos2x = frames[current_frame].cam_pos2.x * (1 - f) + frames[current_frame+1].cam_pos2.x * f;
			intro_cam_pos2y = frames[current_frame].cam_pos2.y * (1 - f) + frames[current_frame+1].cam_pos2.y * f;
			intro_cam_pos2z = frames[current_frame].cam_pos2.z * (1 - f) + frames[current_frame+1].cam_pos2.z * f;
			intro_cam_rot2x = frames[current_frame].cam_rot2.x * (1 - f) + frames[current_frame+1].cam_rot2.x * f;
			intro_cam_rot2y = frames[current_frame].cam_rot2.y * (1 - f) + frames[current_frame+1].cam_rot2.y * f;

			if (++frames_done == frames[current_frame].frames) {
				current_frame++;
				frames_done = 0;
			}

			// redraw screen
			glutPostRedisplay();
			Sleep((DWORD)(1000/60.0)); // cap to 60 frames per second

		}

	} else { // idle func is only used in main program when user is doing a task
		// ensure display gets redisplayed while program is idle (doing a task)
		glutPostRedisplay();
	}
}


// reset global state variables, to simulate starting game over
void reset_state_variables() {
	// initialize intro scene variables
	intro_screen = true;
	intro_car_posx = -572.14; // position car in tunnel
	intro_car_posy = -587.5;
	intro_car_posz = -226.57;
	intro_car_rotx = 0; // rotate car to face forward
	intro_car_roty = 180;
	intro_car_rotz = 0;
	intro_cam_pos1x = -716.39; // position and rotate camera to be above the tunnel
	intro_cam_pos1y = -371.5;
	intro_cam_pos1z = -265.58;
	intro_cam_rot1x = 44;
	intro_cam_rot1y = 472;
	intro_cam_pos2x = -571.91; // position and rotate camera to be in driver view, showing car's hood in tunnel
	intro_cam_pos2y = -575.0;
	intro_cam_pos2z = -229.12;
	intro_cam_rot2x = 17;
	intro_cam_rot2y = 178;
	current_frame = 0;
	frames_done = 0;
	glutIdleFunc(idleFunc);
	task = "Press S to start game, or H for instructions on how to play.\nPress V to switch viewpoints, or R to reset animation.";
	//viewport = 1; // don't change viewport on reset.. it is just annoying
	// initialize non-intro-scene variables
	satisfaction = 0;
	cur_time = last_time = orig_time = time(NULL);
	current_task = NULL;
	doing_task = false;
	bladder = 50;
	hunger = thirst = 100;
	comfort = hygiene = leisure = 0;
	inventory = placeholder;
	cooked_or_bathroom = false;
	won_game = false;
	first_mouse = true;
	// hide non-intro screen GUI elements for now
	rotation_text->hide(); // used to debug camera
	position_text->hide();
	timer_text->hide();
	help_text->hide();
	satisfaction_text->hide();
	hunger_slider->hide();
	bladder_slider->hide();
	leisure_slider->hide();
	comfort_slider->hide();
	hygiene_slider->hide();
	thirst_slider->hide();
}

// start the main game by appropriate setting some state variables
void start_game() {
	glutIdleFunc(NULL); // turn off animation from intro screen
	intro_screen = false; // tell program to render other scene (main house scene)
	task = "";
	// hide intro screen GUI elements and show game elements
	rotation_text->hide();
	position_text->hide();
	help_text->hide();
	timer_text->reveal();
	satisfaction_text->reveal();
	hunger_slider->reveal();
	bladder_slider->reveal();
	leisure_slider->reveal();
	comfort_slider->reveal();
	hygiene_slider->reveal();
	thirst_slider->reveal();
	// position user to front of house, facing doorway
	position.x = -45;
	position.y = 2.5;
	position.z = -5;
	rotation.x = rotation.z = 0;
	rotation.y = 90;
	first_mouse = true;
}

// Initialize the program
void init() {
	// setup GL settings
	glEnable(GL_DEPTH_TEST);
	// enable transparency
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

	// setup lighting
    glEnable (GL_LIGHTING);
	glEnable (GL_LIGHT0); // LIGHT0 used for main lighting
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE); // make sure to shade both sides of polygons

	// setup viewing
	window_width = glutGet(GLUT_WINDOW_WIDTH); // because the window width and height passed to enter Game Mode is only a suggestion that OpenGL usually doesn't take.
	window_height = glutGet(GLUT_WINDOW_HEIGHT);
	glViewport(0,0,window_width,window_height);
	glPointSize(3);
	glClearColor(63/255.0, 138/255.0, 68/255.0,1);
	//glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	position = F3dVector(-45,2.5,-5);
	rotation = F3dVector(0,90,0);

	// initialize PUI environment
	puInit () ;
	puSetDefaultStyle        ( PUSTYLE_SMALL_SHADED ) ;
	puSetDefaultColourScheme ( 0.3f, 0.4f, 0.6f, 1.0f) ;

	// build GUI by adding PUI widgets to the screen
	timer_text = new puText ( 10, 80 ) ;
	timer_text -> setColour ( PUCOL_LABEL, 1.0, 1.0, 1.0 ) ;
	satisfaction_text = new puText(240, 80);
	satisfaction_text -> setColour ( PUCOL_LABEL, 1.0, 1.0, 1.0 ) ;
	position_text = new puText(540, 80);
	position_text -> setColour ( PUCOL_LABEL, 1.0, 1.0, 1.0 ) ;
	rotation_text = new puText(540, 50);
	rotation_text -> setColour ( PUCOL_LABEL, 1.0, 1.0, 1.0 ) ;
	game_text = new puText(window_width-175, window_height-35);
	game_text->setColor(PUCOL_LABEL, 1,1,1);
	task_text = new puText(0, window_height-25);
	task_text->setColor(PUCOL_LABEL, 1,1,1);
	help_text = new puText(0, window_height-200);
	help_text->setColor(PUCOL_LABEL, 1,1,1);
	help_text->setLabelFont(PUFONT_TIMES_ROMAN_24);
	help_text->setLabel("You are driving home from a long day of work and you want to get happy as fast as possible.\n\nIn the game, you move using the WSAD keys and the mouse, like any first-person shooter.\n\nClick on objects while close to them to interact with them.\n\nDifferent objects help you fill different mood bars.\nThe objective of the game is to fill or empty every bar (use common sense to decide which).\nDo this as FAST as you can.\n\nPress S whenever you are ready to start playing, or press R to watch the animation again.");

	hunger_slider = new puSlider(10, 60, 150, FALSE, 20);
	hunger_slider->setLabel("Hunger");
	hunger_slider->setColor(PUCOL_LABEL, 1, 1, 1);
	leisure_slider = new puSlider(10, 35, 150, FALSE, 20);
	leisure_slider->setLabel("Leisure");
	leisure_slider->setColor(PUCOL_LABEL, 1, 1, 1);
	comfort_slider = new puSlider(10, 10, 150, FALSE, 20);
	comfort_slider->setLabel("Comfort");
	comfort_slider->setColor(PUCOL_LABEL, 1, 1, 1);
	bladder_slider = new puSlider(240, 60, 150, FALSE, 20);
	bladder_slider->setLabel("Bladder");
	bladder_slider->setColor(PUCOL_LABEL, 1, 1, 1);
	hygiene_slider = new puSlider(240, 35, 150, FALSE, 20);
	hygiene_slider->setLabel("Hygiene");
	hygiene_slider->setColor(PUCOL_LABEL, 1, 1, 1);
	thirst_slider = new puSlider(240, 10, 150, FALSE, 20);
	thirst_slider->setLabel("Thirst");
	thirst_slider->setColor(PUCOL_LABEL, 1, 1, 1);

	// setup global state
	task_buf = (char*)calloc(100,sizeof(char));
	ellipsis = (char*)calloc(20, sizeof(char));
	// setup inventory with placeholder picture
	placeholder_pic = new GLTexture();
	placeholder_pic->Load("pics/placeholder.bmp");
	placeholder = InventoryItem(PLACEHOLDER, placeholder_pic, "", &comfort, NULL, 2, 0, 20);
	viewport = 1;
	reset_state_variables();

	// setup images (textures) that will be shown
	oven_pic = new GLTexture();
	oven_pic->Load("pics/oven.bmp");
	fridge_pic = new GLTexture();
	fridge_pic->Load("pics/fridge.bmp");
	tea_pic = new GLTexture();
	tea_pic->Load("pics/tea.bmp");
	wine_pic = new GLTexture();
	wine_pic->Load("pics/wine.bmp");
	book_pic = new GLTexture();
	book_pic->Load("pics/book.bmp");

	// setup quadric for drawing
	quadratic=gluNewQuadric();			
	gluQuadricNormals(quadratic, GLU_SMOOTH);

	// load 3DS models
	house_model = new Model_3DS();
	house_model->Load("models/house3.3ds");
	house_model->rot.x = 180;
	house_model->rot.z = 180;
	house_model->scale.x = 0.05;
	house_model->scale.y = 0.05;
	house_model->scale.z = 0.05;
	windows_model = new Model_3DS();
	windows_model->Load("models/windows.3ds");
	windows_model->rot.x = 180;
	windows_model->rot.z = 180;
	windows_model->scale.x = 0.05;
	windows_model->scale.y = 0.05;
	windows_model->scale.z = 0.05;


	oven_model = new Model_3DS();
	oven_model->Load("models/oven.3ds");
	oven_model->pos.x = 5.3;
	oven_model->pos.y = 1.4;
	oven_model->pos.z = -11;
	oven_model->rot.y = 90;
	oven_model->scale.x = 0.0055;
	oven_model->scale.y = 0.0055;
	oven_model->scale.z = 0.0055;
	sink_model = new Model_3DS();
	sink_model->Load("models/sink.3ds");
	sink_model->pos.x = -4.5;
	sink_model->pos.y = 2;
	sink_model->pos.z = 3.75;
	sink_model->scale.x = 0.001;
	sink_model->scale.y = 0.001;
	sink_model->scale.z = 0.001;
	toilet_model = new Model_3DS();
	toilet_model->Load("models/toilet.3ds");
	toilet_model->pos.x = -5.4;
	toilet_model->pos.y = 1.35;
	toilet_model->pos.z = 6;
	toilet_model->rot.y = 90;
	toilet_model->scale.x = 0.00004;
	toilet_model->scale.y = 0.00004;
	toilet_model->scale.z = 0.00004;
	sofa_model = new Model_3DS();
	sofa_model->Load("models/sofa.3ds");
	sofa_model->pos.x = 2;
	sofa_model->pos.y = 1.3;
	sofa_model->pos.z = -3.1;
	sofa_model->rot.y = 90;
	sofa_model->scale.x = 0.2;
	sofa_model->scale.y = 0.2;
	sofa_model->scale.z = 0.2;
	fridge_model = new Model_3DS();
	fridge_model->Load("models/fridge.3ds");
	fridge_model->pos.x = 7;
	fridge_model->pos.y = 1.35;
	fridge_model->pos.z = -5.5;
	fridge_model->scale.x = 0.4;
	fridge_model->scale.y = 0.4;
	fridge_model->scale.z = 0.4;
	chair_model = new Model_3DS();
	chair_model->Load("models/chair.3ds");
	chair_model->pos.x = -4;
	chair_model->pos.y = 1.35;
	chair_model->pos.z = -1.1;
	chair_model->rot.y = 180;
	chair_model->scale.x = 0.00075;
	chair_model->scale.y = 0.00095;
	chair_model->scale.z = 0.00075;
	table_model = new Model_3DS();
	table_model->Load("models/table.3ds");
	table_model->pos.x = -4;
	table_model->pos.y = 1.35;
	table_model->pos.z = -2;
	table_model->scale.x = 0.05;
	table_model->scale.y = 0.05;
	table_model->scale.z = 0.05;
	bookshelf_model = new Model_3DS();
	bookshelf_model->Load("models/bookshelf.3ds");
	bookshelf_model->pos.x = -0.8;
	bookshelf_model->pos.y = 3.1;
	bookshelf_model->pos.z = -10;
	bookshelf_model->rot.y = 180;
	bookshelf_model->scale.x = 0.001;
	bookshelf_model->scale.y = 0.001;
	bookshelf_model->scale.z = 0.001;
	teaset_model = new Model_3DS();
	teaset_model->Load("models/teaset.3ds");
	teaset_model->pos.x = -2;
	teaset_model->pos.y = 2.2;
	teaset_model->pos.z = -8.4;
	teaset_model->rot.y = 135;
	teaset_model->scale.x = 0.0007;
	teaset_model->scale.y = 0.0007;
	teaset_model->scale.z = 0.0007;
	wine_model = new Model_3DS();
	wine_model->Load("models/wine.3ds");
	wine_model->pos.x = 7.2;
	wine_model->pos.y = 1.35;
	wine_model->pos.z = 4;
	wine_model->rot.y = -90;
	wine_model->scale.x = 0.001;
	wine_model->scale.y = 0.001;
	wine_model->scale.z = 0.001;
	checkers_model = new Model_3DS();
	checkers_model->Load("models/checkers.3ds");
	checkers_model->pos.x = 7.3;
	checkers_model->pos.y = 1.35;
	checkers_model->pos.z = 8.8;
	checkers_model->scale.x = 0.0015;
	checkers_model->scale.y = 0.0015;
	checkers_model->scale.z = 0.0015;
	shower_model = new Model_3DS();
	shower_model->Load("models/shower.3ds");
	shower_model->pos.x = -1;
	shower_model->pos.y = 2.35;
	shower_model->pos.z = 3.6;
	shower_model->scale.x = 0.00075;
	shower_model->scale.y = 0.00075;
	shower_model->scale.z = 0.00075;

	// build display list for tree
	tree_list = glGenLists(1);
	glNewList(tree_list, GL_COMPILE);
	glPushMatrix();
	glRotatef(90,0,1,0);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, tree_trunk_material);
	gluDisk(quadratic,0,.13,32,32);
	gluCylinder(quadratic,0.13,0.13,0.2,32,32);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, tree_material);
	glTranslatef(0,0,0.2);
	gluCylinder(quadratic,0.4,0.15,0.3,32,32);
	glTranslatef(0,0,0.15);
	gluCylinder(quadratic,0.4,0.15,0.3,32,32);
	glTranslatef(0,0,0.15);
	gluCylinder(quadratic,0.35,0.1,0.3,32,32);
	glTranslatef(0,0,0.15);
	gluCylinder(quadratic,0.3,0.05,0.3,32,32);
	glTranslatef(0,0,0.15);
	gluCylinder(quadratic,0.25,0.00,0.3,32,32);
	glPopMatrix();
	glEndList();

	// set base material to white opaque (this is what shows anywhere light doesn't hit)
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, white_material);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, white_material);

	///// BUILD TREE DESCRIBING THE SCENE
	// first create Model Nodes for every model we plan to show in scene
	vssgNode* tree = new DisplayNode(tree_list, no_material); // no material because display list contains material definitions
	vssgNode* house = new ModelNode(house_model); // model for a house
	vssgNode* windows = new TranslucentModelNode(windows_model, glass_material); // model for the windows of the house
	vssgNode* oven = new ModelNode(oven_model); // model for an oven
	vssgNode* sink = new ModelNode(sink_model); // model for a sink
	vssgNode* toilet = new ModelNode(toilet_model); // model for a toilet
	vssgNode* sofa = new ModelNode(sofa_model); // model for a sofa
	vssgNode* fridge = new ModelNode(fridge_model); // model for a sofa
	vssgNode* chair = new ModelNode(chair_model); // model for a chair
	vssgNode* table = new ModelNode(table_model); // model for a table
	vssgNode* bookshelf = new ModelNode(bookshelf_model); // model for a bookshelf
	vssgNode* teaset = new ModelNode(teaset_model); // model for a teaset
	vssgNode* wine = new ModelNode(wine_model); // model for wine on a table
	vssgNode* checkers = new ModelNode(checkers_model); // model for a checkers table for outdoor
	vssgNode* shower = new ModelNode(shower_model); // model for shower
	// add models to scene as nodes off the root; adding a Name node for each for selection purposes
	root = new RootNode();
		root->addChild(house);	
		vssgNode* kitchen_table = new NameNode(KITCHEN_TABLE); // Kitchen table consists of chair and table-- clicking on either will work
			kitchen_table->addChild(table);
			kitchen_table->addChild(chair);
		vssgNode* sink_name = new NameNode(SINK);
			sink_name->addChild(sink);
		vssgNode* oven_name = new NameNode(OVEN);
			oven_name->addChild(oven);
		vssgNode* toilet_name = new NameNode(TOILET);
			toilet_name->addChild(toilet);
		vssgNode* fridge_name = new NameNode(FRIDGE);
			fridge_name->addChild(fridge);
		vssgNode* sofa_name = new NameNode(SOFA);
			sofa_name->addChild(sofa);
		vssgNode* bookshelf_name = new NameNode(BOOKSHELF);
			bookshelf_name->addChild(bookshelf);
		vssgNode* wine_name = new NameNode(WINE);
			wine_name->addChild(wine);
		vssgNode* checkers_name = new NameNode(CHECKERS);
			checkers_name->addChild(checkers);
		vssgNode* shower_name = new NameNode(SHOWER);
			shower_name->addChild(shower);
		vssgNode* teaset_table = new NameNode(TEASET_TABLE); // teaset table consists of table with a tea set above it -- clicking on either will work
			teaset_table->addChild(teaset);
			vssgNode* translate_teaset_table = new TranslateNode(-0.2,0,-13.4); // move table to new position (since it has innate position of kitchen table defined above)
				vssgNode* rotate_teaset_table = new RotateNode(90,0,1,0); // rotate table
					rotate_teaset_table->addChild(table);
				translate_teaset_table->addChild(rotate_teaset_table);
			teaset_table->addChild(translate_teaset_table);
		root->addChild(sink_name);
		root->addChild(oven_name);
		root->addChild(oven_name);
		root->addChild(toilet_name);
		root->addChild(sofa_name);
		root->addChild(fridge_name);
		root->addChild(kitchen_table);
		root->addChild(bookshelf_name);
		root->addChild(teaset_table);
		root->addChild(wine_name);
		root->addChild(checkers_name);
		root->addChild(shower_name);
		root->addChild(windows); // draw windows last for translucency purposes


		// SETUP THE DATA FOR THE TASK INTERACTION
		// setup the item data
		items[OVEN_FOOD] = InventoryItem(OVEN_FOOD, oven_pic, "Eating yummy food from the oven", &hunger, &bladder, -20, 10, 5);
		items[FRIDGE_FOOD] = InventoryItem(FRIDGE_FOOD, fridge_pic, "Eating decent food from the fridge", &hunger, &bladder, -10, 2, 10);
		items[TEA_DRINK] = InventoryItem(TEA_DRINK, tea_pic, "Drinking nice warm tea", &thirst, &bladder, -20, 5, 5);
		items[WINE_DRINK] = InventoryItem(WINE_DRINK, wine_pic, "Drinking too-sweet wine", &thirst, &bladder, -10, 5, 10);
		items[BOOK_ITEM] = InventoryItem(BOOK_ITEM, book_pic, "Reading a good book", &leisure, NULL, 10, 0, 5);
		
		// get vectors ready to represent acceptable Items for two variant objects
		vector<int> table_items, sofa_items, no_items, shower_items;
		table_items.push_back(OVEN_FOOD); table_items.push_back(FRIDGE_FOOD); table_items.push_back(TEA_DRINK);
		table_items.push_back(BOOK_ITEM);
		sofa_items = table_items; // sofa is same as table items except no wine
		table_items.push_back(WINE_DRINK);  // add wine to table items
		shower_items.push_back(PLACEHOLDER); // you can't shower with any items - plus we use Placeholder to give it comfort bonus

		// setup the task data
		tasks[KITCHEN_TABLE] = Task(KITCHEN_TABLE, " at the table", &comfort, 2, 0, false, false, NULL, table_items, &inventory, NULL, "", "You need food, drink, or a book to sit at the table");
		tasks[OVEN] = Task(OVEN, "Cooking tasty food", NULL, 0, 5, false, false, NULL, no_items, &inventory, &items[OVEN_FOOD], "", "");
		tasks[FRIDGE] = Task(FRIDGE, "Grabbing some quick food", NULL, 0, 3, false, false, NULL, no_items, &inventory, &items[FRIDGE_FOOD], "", "");
		tasks[TOILET] = Task(TOILET, "Going to the bathroom", &bladder, -10, 10, false, false, false, no_items, &inventory, NULL, "", "");
		tasks[SINK] = Task(SINK, "Washing hands", &hygiene, 10, 3, false, true, &cooked_or_bathroom, no_items, &inventory, NULL, "Your hands are already clean", ""); 
		tasks[TEASET_TABLE] = Task(TEASET_TABLE, "Getting a cup of tea", NULL, 0, 3, false, false, NULL, no_items, &inventory, &items[TEA_DRINK], "", "");
		tasks[SOFA] = Task(SOFA, " on the sofa", &comfort, 5, 0, false, false, NULL, sofa_items, &inventory, NULL, "", "You need food, drink, or a book to sit on the sofa");
		tasks[BOOKSHELF] = Task(BOOKSHELF, "Selecting a book", NULL, 0, 5, false, false, NULL, no_items, &inventory, &items[BOOK_ITEM], "", "");
		tasks[WINE] = Task(WINE, "Pouring a glass of wine, careful not to spill", NULL, 0, 5, false, false, NULL, no_items, &inventory, &items[WINE_DRINK], "", "");
		tasks[CHECKERS] = Task(CHECKERS, "Coming up with a new checkers strategy", &leisure, 15, 8, false, false, NULL, no_items, &inventory, NULL, "", "");
		tasks[SHOWER] = Task(SHOWER, "Taking a long, hot shower", &hygiene, 5, 20, false, false, NULL, shower_items, &inventory, NULL, "", "You can't shower with any items");

		// BUILD TREE DESCRIBING INTRO SCREEN SCENE
		car_model = new Model_3DS();
		car_model->Load("models/car.3ds");
		car_model->scale.x = .1;
		car_model->scale.y = .1;
		car_model->scale.z = .1;
		vssgNode* car = new ModelNode(car_model);
		road_model = new Model_3DS();
		road_model->Load("models/road.3ds");
		road_model->scale.x = 0.01;
		road_model->scale.y = 0.01;
		road_model->scale.z = 0.01;
		vssgNode* road = new ModelNode(road_model);
		intro_root = new RootNode();
			intro_root->addChild(road);
			intro_root->addChild(car);
			vssgNode* translate_house = new TranslateNode(878, -428, 679);
				vssgNode* rotate_house = new RotateNode(0, 1, 0, 0);
					vssgNode* scale_house = new ScaleNode(5,5,5);
						scale_house->addChild(house);
					rotate_house->addChild(scale_house);
				translate_house->addChild(rotate_house);
			intro_root->addChild(translate_house);

		// SETUP KEY FRAMES FOR INTRO SCREEN ANIMATION
		frames[0] = KeyFrame(-572.14, -587.5, -226.57, 0, 180, 0,-716.39, -371.5, -265.58, 44, 112, -572.14,-575,-229.12,18,178,120);
		frames[1] = KeyFrame(-567.14, -569.5, -26.67, 0, 180, 0,-838.75, -233.75, 87.303, 44, 58, -567.14, -557, -31.38, 18, 178, 60);
		frames[2] = KeyFrame(-564.12, -564.5, 61.2, 0, 180, 0,-842.39, -258.75, 300.77, 40, 62, -564.12, -552, 55.2, 18, 179, 120);
		frames[3] = KeyFrame(-560.88, -595.75, 286.41, 12, 180, 0,-846.39, -275.75, 512.77, 40, 62, -561.03, -580, 280.5, 18, 179, 60);
		frames[4] = KeyFrame(-554, -625, 400.5, 15,185,0,         -846.39, -275.75, 512.77, 40, 62, -556.75, -606.5, 393.4,23,173, 120);
		frames[5] = KeyFrame(-515.54, -641, 580.15, -4, 210, -6,-846.39, -275.75, 512.77, 40, 122,-519.48,-627.5,573.4,3,147,120);
		frames[6] = KeyFrame(-369.4, -606.25, 779.18, -16, 225, -12, -456.6, -302, 427.2, 30, 145, -378.86, -585.5, 773.85, 8, 124,90);
		frames[7] = KeyFrame(-235, -577.75, 872, -43, 260, -40, -643.8, -470,753, 9, 93, -241.35, -564.5, 873.6, 4, 91,  120);
		frames[8] = KeyFrame(195.5, -525.5, 917.9, -5, 275, -8, -448, -401, 603, 15, 117, 186.68, -512, 918.8, 6, 82, 60);
		frames[9] = KeyFrame(355.35, -529.5, 900.68, 29, 290, 27, -92.7, -470, 864.3, 5, 90, 345.5, -517.25, 904.33, -3, 76, 60);
		frames[10] = KeyFrame(621.75, -448.75, 854.4, 29, 310, 26, 146.34, -391.25, 1016.48, 10, 65, 608.68, -438.5, 860, -8, 57, 90);
		frames[11] = KeyFrame(720.5, -412.5, 770.4, 10, 332, 0, 235.56, -191.75, 590.08, 23, 108, 713, -396.5, 778.8, 10, 38, 0);
}

// process selection/pick from mouse to see which interactive object it was (if any)
void processHits(GLint hits, GLuint* buffer) {
	// loop through picking buffer and figure out which hit object is closest to user (that becomes selected)
	int selected = -1;
	int depth = 1;
	if (hits > 0) {
		selected = buffer[3];
		depth = buffer[1];
		for (int loop = 1; loop < hits; loop++) {	
			if (buffer[loop*4+1] < GLuint(depth)) {
				selected = buffer[loop*4+3];
				depth = buffer[loop*4+1];
			}
		}
	}
	if (depth < -230000000) { // the distance I decided the user should be to the object for it to be effective
		TaskMessage message = tasks[selected].doTask(); // perform task and then process message
		if (message.done) {
			doing_task = false;
			glutIdleFunc(NULL);
			task = "";
			current_task = &tasks[selected];
			if (!current_task->acceptableItems.empty())
					inventory = placeholder;
			if (current_task->ID == TOILET || current_task->ID == OVEN)
				cooked_or_bathroom = true;
			if (current_task->need_flag)
				*(current_task->flag) = false;
		} else {
			if (!doing_task)
				strcpy(ellipsis, "");
			current_task = &tasks[selected];
			doing_task = true;
			glutIdleFunc(idleFunc);
			strcat(ellipsis, "."); // add period to ellipsis buffer
			sprintf(task_buf, "%s %s", message.value.c_str(), ellipsis); // show message followed by ellipsis (varying amt of periods)
			task = task_buf; // show it on screen
		}
	} else {
		task = "";
	}

}

// traverse scene graph to draw scene as intended
void traverse(vssgNode* current) {
	if (current == NULL) return;
	glPushMatrix();
	if (!current->isName() || select_mode)
		current->execute();
	vssgNode* child;
	while (child = current->nextChild())
		traverse(child);
	if (select_mode && current->isName()) {
		glLoadName(NONE);
	}
	glPopMatrix();
}

// setup all the lighting before any drawing takes place.
// this takes care of whether the user is indoor or outdoor and only enables the right lights accordingly
void applyLighting() {
	// setup basic global (outdoor) ambient light
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, global_ambient);

	// render main outdoor distant light (like sun)
	GLfloat position1[] = {0,100,0,0};
	GLfloat ambient1[] = {0,0,0,1};
	GLfloat diffuse1[] = {.5,.5,.5,1};
	GLfloat specular1[] = {.5,.5,.5,1};
	glLightfv(GL_LIGHT0, GL_POSITION, position1);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient1);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse1);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular1);
}

// draw GUI elements that overlay scene
void drawGUIOverlay() {
	// draw GUI using PUI
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,window_width,0.0,window_height);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	if (intro_screen) {
		position_text->setLabel( showCameraPos() );
		rotation_text->setLabel( showCameraRot() );
		game_text->setLabel("Sim Adventure Game");
		task_text->setLabel(task);
		// turn off depth test and lighting for some 2D HUD drawing
		glDisable(GL_DEPTH_TEST); // must turn off depth test or else image will get covered by parts of scene
		glDisable(GL_LIGHT0); // turn off lighting since this stuff shouldn't be affected by lights

		// draw background for HUD
		glColor3f(0,0,0);
		glBegin(GL_QUADS);
			// small strip on top for messages about tasks/ winning game/ etc.
			glVertex2f(0, window_height);
			glVertex2f(window_width, window_height);
			glVertex2f(window_width, window_height-50);
			glVertex2f(0, window_height-50);
		glEnd();

		// re-enable depth test, lighting
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_LIGHT0);
	} else {
		// update timer
		if (!won_game) {// don't update timer if game is won
			cur_time = time ( NULL ) - orig_time ;
			if (cur_time != last_time) { // one second has elapsed, so apply any secondly offsets.
				last_time = cur_time;
				// if doing task, doTask for one more second
				if (doing_task) {
					TaskMessage message = current_task->doTask();
					if (message.done) {
						doing_task = false;
						glutIdleFunc(NULL);
						task = "";
						// if task had an item associated with it, remove that item since it was just used up
						if (!current_task->acceptableItems.empty())
							inventory = placeholder;
						if (current_task->ID == TOILET || current_task->ID == OVEN)
							cooked_or_bathroom = true;
						if (current_task->need_flag)
							*(current_task->flag) = false;
					} else {
						strcat(ellipsis, "."); // add period to ellipsis buffer
						sprintf(task_buf, "%s %s", message.value.c_str(), ellipsis); // show message followed by ellipsis (varying amt of periods)
						task = task_buf; // show it on screen
					}
				}
			}
		}
		// update all text fields
		timer_text -> setLabel ( convertTime(cur_time) ) ;
		satisfaction_text->setLabel( showSatisfaction() );
		task_text->setLabel(task);

		// update sliders
		hunger_slider->setValue(hunger / 100.0f);
		leisure_slider->setValue(leisure / 100.0f);
		bladder_slider->setValue(bladder / 100.0f);
		comfort_slider->setValue(comfort / 100.0f);
		thirst_slider->setValue(thirst / 100.0f);
		hygiene_slider->setValue(hygiene / 100.0f);

		// turn off depth test and lighting for some 2D HUD drawing
		glDisable(GL_DEPTH_TEST); // must turn off depth test or else image will get covered by parts of scene
		glDisable(GL_LIGHT0); // turn off lighting since this stuff shouldn't be affected by lights

		// draw background for HUD
		glColor3f(0,0,0);
		glBegin(GL_QUADS);
			// big strip on bottom for mood sliders and inventory and timer and satisfaction text
			glVertex2f(0,0);
			glVertex2f(window_width, 0);
			glVertex2f(window_width, 120);
			glVertex2f(0, 120);
			// small strip on top for messages about tasks/ winning game/ etc.
			glVertex2f(0, window_height);
			glVertex2f(window_width, window_height);
			glVertex2f(window_width, window_height-50);
			glVertex2f(0, window_height-50);
		glEnd();

		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, white_material);

		// show invetory image
		inventory.picture->Use(); // bind bmp as texture
		// draw 2D square of 100x100 pixels which will get BMP texture, effectively showing a square image on screen
		glBegin( GL_QUADS );
			glTexCoord2f(0.0, 0.0); 
			glVertex2f(window_width-150,10);
			glTexCoord2f(1.0, 0.0); 
			glVertex2f(window_width-50,10);
			glTexCoord2f(1.0, 1.0);
			glVertex2f(window_width-50,110);
			glTexCoord2f(0.0, 1.0);
			glVertex2f(window_width-150,110);
		glEnd();

		// show crosshair
		int centerx = window_width/2.0; int centery = window_height/2.0;
		glLineWidth(1.5);
		glBegin( GL_LINES );
			glVertex2f(centerx+4, centery+4);
			glVertex2f(centerx-4, centery-4);
			glVertex2f(centerx-4, centery+4);
			glVertex2f(centerx+4, centery-4);
		glEnd();
		glLineWidth(1.0);

		// re-enable depth test, lighting, and turn off texture from inventory image
		glEnable(GL_DEPTH_TEST);
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, global_ambient);
		glEnable(GL_LIGHT0);
		inventory.picture->UnUse();
	}

	// call pui display callback
	puDisplay () ;
	
}

// actually draw the objects as well as setting up the model view and camera
void drawObjects(GLenum mode) {
	// setup model view
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	if (!intro_screen) { // if not at intro screen, show house world as normal
		// apply camera transformations
		glRotatef(rotation.x, 1,0,0); // rotate camera along x-axis
		glRotatef(rotation.y, 0,1,0); // rotate camera along y-axis
		glTranslatef(-position.x, -position.y, -position.z); // translate screen to position of camera

		// apply lighting
		applyLighting();

		//////// DRAW WORLD BY TRAVERSING SCENE GRAPH
		if (mode == GL_SELECT) select_mode = true;
		traverse(root);
		select_mode = false;
	} else { // otherwise show the intro scene, with the car and the road
		// position and rotate camera
		if (viewport == 1) {
			glRotatef(intro_cam_rot1x, 1, 0, 0);
			glRotatef(intro_cam_rot1y, 0, 1, 0);
			glTranslatef(-intro_cam_pos1x, -intro_cam_pos1y, -intro_cam_pos1z);
		} else {
			glRotatef(intro_cam_rot2x, 1, 0, 0);
			glRotatef(intro_cam_rot2y, 0, 1, 0);
			glTranslatef(-intro_cam_pos2x, -intro_cam_pos2y, -intro_cam_pos2z);
		}

		// position and rotate car
		car_model->pos.x = intro_car_posx;
		car_model->pos.y = intro_car_posy;
		car_model->pos.z = intro_car_posz;
		car_model->rot.x = intro_car_rotx;
		car_model->rot.y = intro_car_roty;
		car_model->rot.z = intro_car_rotz;

		// apply lighting
		applyLighting();

		// traverse scene graph to show intro scene
		traverse(intro_root);
	}
}

void display() {
	// clear frame
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	if (help_text->isVisible() == FALSE) {
		GLint viewport[4];
		glGetIntegerv(GL_VIEWPORT, viewport);
		// setup basic viewport
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(35,(double)window_width/window_height,0.1,2000);

		// draw objects
		drawObjects(GL_RENDER);

		// check for errors
		GLenum errCode;
		const GLubyte *errString;
		if ((errCode = glGetError()) != GL_NO_ERROR) {
			errString = gluErrorString(errCode);
			sprintf (task_buf, "OpenGL Error: %s", errString);
			task=task_buf;
		}
	}

	// draw GUI overlay
	drawGUIOverlay();

	// redraw screen and double buffer
	glFlush();
	glutSwapBuffers();
}

// mouse callback handles selection / picking (which in this program is used to turn light on/off
void mouse(int button, int state, int x, int y) {
	if (!doing_task && !won_game && !intro_screen) { // interaction disabled when performing tasks
		GLuint nameBuff[512] = {0};
		GLint hits;
		GLint viewport[4];
		if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
			// setup viewport
			glGetIntegerv(GL_VIEWPORT, viewport);
			glMatrixMode(GL_PROJECTION);
			glPushMatrix();
			glLoadIdentity();

			// init selection mode
			glSelectBuffer(512, nameBuff);
			glRenderMode(GL_SELECT);
			glInitNames();
			glPushName(NONE); // so glLoadName doesn't make GL_INVALID_OPERATION when trying to replace top of stack.

			// setup a 2x2 clipping volume for picking
			gluPickMatrix(window_width/2.0, window_height/2.0, 2, 2, viewport);
			gluPerspective(35,(double)window_width/window_height,0.1,2000);

			// draw objects and check for hit
			drawObjects(GL_SELECT);

			// restore saved viewport
			glMatrixMode(GL_PROJECTION);
			glPopMatrix();
			glFlush();

			// return to normal render mode
			hits = glRenderMode(GL_RENDER);
			processHits(hits, nameBuff);

			// normal render
			glutPostRedisplay();
		}
	}
}

// mouse motion callback handles camera rotation
void mouse_move(int x, int y) {
	if (!doing_task && !won_game && !intro_screen) { // interaction disabled when performing tasks
		// calculate change from last x,y position
		if (first_mouse) {
			first_mouse = false;
			lastx = x;
			lasty = y;
		}
		int deltax = x - lastx;
		int deltay = y - lasty;
		// set lastx,lasty to new positions for x,y
		lastx = x;
		lasty = y;
		// modify rotation by a scale appropriate to how much the mouse moved
		if (rotation.x + deltay < 90 && rotation.x + deltay > -90)
			rotation.x += deltay;
		//if (rotation.y + deltax < 180 && rotation.y + deltax > 0)
			rotation.y += deltax;
		glutPostRedisplay();
	}
}


// below keyboard callback handles camera movement

void keyboard(unsigned char key, int x, int y) {
	if (!doing_task && !won_game && !intro_screen) { // interaction disabled when performing tasks, game over, or at intro screen
		double step = .25; // step is how much to move each time, something we need to tweak depending on the coordinate system of world to get it to feel right
		double DEG2RAD = 3.14159/180;
		
		// Note: No camera movement messed with y position because there is no need for user to "jump" or "fly".

		switch(key) {
			case 's': // slide camera backward
			case 'S': 
				position.x -= sin(rotation.y*DEG2RAD) * step;
				position.z += cos(rotation.y*DEG2RAD) * step;
				break;
			case 'w': // slide camera forward
			case 'W':
				position.x += sin(rotation.y*DEG2RAD) * step;
				position.z -= cos(rotation.y*DEG2RAD) * step;
				break;
			case 'd': // slide camera right
			case 'D':
				position.x += cos(rotation.y*DEG2RAD) * step;
				position.z += sin(rotation.y*DEG2RAD) * step;
				break;
			case 'a': // // slide camera left
			case 'A':
				position.x -= cos(rotation.y*DEG2RAD) * step;
				position.z -= sin(rotation.y*DEG2RAD) * step;
				break;
			/*case 'z':
				position.y-=step;
				break;
			case 'Z':
				position.y+=step;
				break;*/
			case 'R': // reset game
			case 'r':
				// reset state variables
				reset_state_variables();
				break;
			case 'x': // exit game
			case 'X':
				glutLeaveGameMode();
				exit(0);
				break;
				// this was debugging stuff
			/*case 'v':
			case 'V':
				viewport = (viewport == 1) ? 2 : 1;
				break;
			case '+':
				intro_car_rotx++;
				break;
			case '-':
				intro_car_rotx--;
				break;
			case ']':
				intro_car_rotz++;
				break;
			case '[':
				intro_car_rotz--;
				break;*/
			default:
				break;
		}

		// this was debugging stuff
		/*sprintf(task_buf, "%f %f", intro_car_rotx, intro_car_rotz);
		task = task_buf;*/

		
	} else { // if won game or performing task or in intro screen, we should still be able to reset game or exit game
		switch (key) {
			case 'R': // reset game
			case 'r':
				// position user to front of house, facing doorway
				position.x = -45;
				position.y = 2.5;
				position.z = -5;
				rotation.x = rotation.z = 0;
				rotation.y = 90;
				// reset state variables
				reset_state_variables();
				break;
			case 'x': // exit game
			case 'X':
				glutLeaveGameMode();
				exit(0);
				break;
		}
	}
	if (intro_screen) { // on intro screen, there are two other options -- start game or change viewports or View Help
		switch (key) {
			case 's': // start game
			case 'S':
				start_game();
				break;
			case 'v': // change viewports
			case 'V':
				viewport = (viewport == 1) ? 2 : 1;
				break;
			case 'h': // show game intro / instructions
			case 'H':
				help_text->reveal();
				glutIdleFunc(NULL);
				break;
			default:
				break;
		}
	}
	glutPostRedisplay();
}

int main(int argc, char** argv) {
	// setup GLUT window
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH); // enable double-buffer and z-buffer
	glutGameModeString("1920x1200:32@60");
	glutEnterGameMode();
	glutSetCursor(GLUT_CURSOR_NONE);

	// map callback functions
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);
	glutPassiveMotionFunc(mouse_move);
	glutIdleFunc(NULL);

	// call init to setup viewport, initialize state, and set global GL settings
	init();

	// start main event loop
	glutMainLoop();
}
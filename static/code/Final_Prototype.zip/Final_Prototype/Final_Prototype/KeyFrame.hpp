
class KeyFrame {
public:
	SF3dVector car_pos, car_rot, cam_pos1, cam_rot1, cam_pos2, cam_rot2;
	int frames;
	KeyFrame() {
		car_pos.x = car_pos.y = car_pos.z = car_rot.x = car_rot.y = car_rot.z =
		cam_pos1.x = cam_pos1.y = cam_pos1.z = cam_rot1.x = cam_rot1.y = cam_rot1.z = 
		cam_pos2.x = cam_pos2.y = cam_pos2.z = cam_rot2.x = cam_rot2.y = cam_rot2.z = 0;
		frames = 0;
	}
	KeyFrame(float car_posx_, float car_posy_, float car_posz_, float car_rotx_, float car_roty_, float car_rotz_,
		     float cam_pos1x_, float cam_pos1y_, float cam_pos1z_, float cam_rot1x_, float cam_rot1y_,
			  float cam_pos2x_, float cam_pos2y_, float cam_pos2z_, float cam_rot2x_, float cam_rot2y_, int frames_)
			 : frames(frames_) {
				 car_pos.x = car_posx_;
				 car_pos.y = car_posy_;
				 car_pos.z = car_posz_;
				 car_rot.x = car_rotx_;
				 car_rot.y = car_roty_;
				 car_rot.z = car_rotz_;
				 cam_pos1.x = cam_pos1x_;
				 cam_pos1.y = cam_pos1y_;
				 cam_pos1.z = cam_pos1z_;
				 cam_rot1.x = cam_rot1x_;
				 cam_rot1.y = cam_rot1y_;
				  cam_pos2.x = cam_pos2x_;
				 cam_pos2.y = cam_pos2y_;
				 cam_pos2.z = cam_pos2z_;
				 cam_rot2.x = cam_rot2x_;
				 cam_rot2.y = cam_rot2y_;
	}
				 
			
};
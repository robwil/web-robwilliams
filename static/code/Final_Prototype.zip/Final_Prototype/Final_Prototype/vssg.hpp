/* 
VSSG - Very Simple Scene Graph
by Rob Williams, 2010

Very simple scene graph which operates like a tree of transformations, with leaves being displayable
    using display lists or 3DS models. Only eight basic node types supported as of now:
	- Root
	- Translate
	- Rotate
	- Scale
	- Display
	- Name
	- Model
	- TranslucentModel
*/

#include <GL/glut.h>
#include <vector>
#include "Model_3DS.h"
using namespace std;

// define a material structure since DisplayNodes now use materials as opposed to colors for displaying
struct material_struct {
	GLfloat ambient[4];
	GLfloat diffuse[4];
	GLfloat specular[4];
	GLfloat shininess;
	material_struct(GLfloat a0, GLfloat a1, GLfloat a2, GLfloat a3, GLfloat d0, GLfloat d1, GLfloat d2, GLfloat d3, GLfloat s0, GLfloat s1, GLfloat s2, GLfloat s3, GLfloat sh) {
		ambient[0] = a0;
		ambient[1] = a1;
		ambient[2] = a2;
		ambient[3] = a3;
		diffuse[0] = d0;
		diffuse[1] = d1;
		diffuse[2] = d2;
		diffuse[3] = d3;
		specular[0] = s0;
		specular[1] = s1;
		specular[2] = s2;
		specular[3] = s3;
		shininess = sh;
	}
};

extern bool select_mode;

class vssgNode {
protected:
	GLfloat properties[4];
	vector<vssgNode*> children;
	vector<vssgNode*>::iterator next;
	int known_count;
public:
	vssgNode(GLfloat p1, GLfloat p2, GLfloat p3, GLfloat p4) : children() {
		properties[0] = p1;
		properties[1] = p2;
		properties[2] = p3;
		properties[3] = p4;
		next = children.begin();
		known_count = 0;
		select_mode = false;
	}

	virtual bool isName() { return false; }

	virtual bool isDisplay() { return false; }

	virtual GLuint getName() { return -1; }

	virtual void execute() = 0;

	void addChild(vssgNode* child) {
		children.push_back(child);
	}

	vssgNode* nextChild() {
		if (known_count != children.size()) {
			known_count = children.size();
			next = children.begin();
		}
		if (next == children.end()) {
			next = children.begin();
			return NULL;
		}
		vssgNode* ret = *next;
		next++;
		return ret;
	}
};

class RootNode : public vssgNode {
public:
	RootNode() : vssgNode(0,0,0,0) {}
	void execute() {}
};

class TranslateNode : public vssgNode {
public:
	TranslateNode(GLfloat p1, GLfloat p2, GLfloat p3) : vssgNode(p1, p2, p3, 0) {}
	void execute() {
		glTranslatef(properties[0], properties[1], properties[2]);
	}
};

class RotateNode : public vssgNode {
public:
	RotateNode(GLfloat p1, GLfloat p2, GLfloat p3, GLfloat p4) : vssgNode(p1, p2, p3, p4) {}
	void execute() {
		glRotatef(properties[0], properties[1], properties[2], properties[3]);
	}
};

class ScaleNode : public vssgNode {
public:
	ScaleNode(GLfloat p1, GLfloat p2, GLfloat p3) : vssgNode(p1, p2, p3, 0) {}
	void execute() {
		glScalef(properties[0], properties[1], properties[2]);
	}
};

class DisplayNode : public vssgNode {
private:
	material_struct* front_mat;
	material_struct* back_mat;
public:
	DisplayNode(GLfloat p1, material_struct* front_mat_, material_struct* back_mat_) : vssgNode(p1, 0, 0, 0), front_mat(front_mat_), back_mat(back_mat_) {}
	DisplayNode(GLfloat p1, material_struct* mat_) : vssgNode(p1, 0, 0, 0), front_mat(mat_), back_mat(mat_) {}
	bool isDisplay() { return true; }
	void execute() {
		glMaterialfv(GL_FRONT, GL_AMBIENT, front_mat->ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, front_mat->diffuse);
		glMaterialfv(GL_FRONT, GL_SPECULAR, front_mat->specular);
		glMaterialf(GL_FRONT, GL_SHININESS, front_mat->shininess);
		glMaterialfv(GL_BACK, GL_AMBIENT, back_mat->ambient);
		glMaterialfv(GL_BACK, GL_DIFFUSE, back_mat->diffuse);
		glMaterialfv(GL_BACK, GL_SPECULAR, back_mat->specular);
		glMaterialf(GL_BACK, GL_SHININESS, back_mat->shininess);
		glCallList((GLuint)(properties[0]));
	}
};

class NameNode : public vssgNode {
public:
	NameNode(GLuint p1) : vssgNode((GLfloat)p1, 0,0,0) {}
	bool isName() { return true; }
	GLuint getName() { return (GLuint)properties[0]; }
	void execute() {
		if (select_mode)
			glLoadName((GLuint)properties[0]);
	}
};

class ModelNode : public vssgNode {
private:
	Model_3DS* m;
public:
	ModelNode(Model_3DS* m_) : vssgNode(0,0,0,0), m(m_) {}
	void execute() {
		m->Draw();
	}
};

class TranslucentModelNode : public vssgNode {
private:
	Model_3DS* m;
	material_struct* mat; // This material struct should have the diffuse map set to a translucent one, where the ambient is set to the original (one to restore back to after this is drawn)
public:
	TranslucentModelNode(Model_3DS* m_, material_struct* mat_) : vssgNode(0,0,0,0), m(m_), mat(mat_) {}
	void execute() {
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat->diffuse);
		m->Draw();
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat->ambient);
	}
};
#include <ctime>
#include <iostream>
#include <GL/glut.h>
#include "pui/pu.h"
#include "GLTexture.h"
using namespace std;

// define PUI widgets
int          main_window ;
puText			*timer_text;
puText			*satisfaction_text;
puSlider		*hunger;
puSlider		*bladder;
puSlider		*leisure;
puSlider		*social;
puSlider		*hygiene;
puSlider		*thirst;

// define images
GLTexture* book_tex;

// global state variables
int firsttime;
int satisfaction = 0;
time_t orig_time, last_time, cur_time;
float hunger_per_sec = 0.0;

char* convertTime(int seconds) {
	int hours = seconds / 3600;
	int minutes = (seconds - hours*3600) / 60;
	seconds = (seconds - hours*3600 - minutes*60);
	char* str = (char*)calloc(20,sizeof(char));
	sprintf(str, "Timer %02d:%02d:%02d", hours, minutes, seconds);
	return str;
}

char* showSatisfaction() {
	char* str = (char*)calloc(20,sizeof(char));
	sprintf(str, "Satisfaction %d%%", satisfaction);
	return str;
}

// Display function
void displayfn (void) {
	// clear the screen
	glClearColor ( 0.1f, 0.3f, 0.5f, 1.0f ) ;
	glClear      ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ) ;

	// setup viewport
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,window_width,0.0,window_height);
	glMatrixMode(GL_MODELVIEW);

	// update timer
	cur_time = time ( NULL ) - orig_time ;
	if (cur_time != last_time) { // one second has elapsed, so apply any secondly offsets.
		last_time = cur_time;
		float value;
		hunger->getValue(&value);
		if (value > 0)
			hunger->setValue(value - hunger_per_sec);
	}
	timer_text -> setLabel ( convertTime(cur_time) ) ;
	satisfaction_text->setLabel( showSatisfaction() );

	book_tex->Use();
	glBegin( GL_QUADS );
		glTexCoord2f(0.0, 0.0); 
		glVertex2f(480,10);
		glTexCoord2f(1.0, 0.0); 
		glVertex2f(580,10);
		glTexCoord2f(1.0, 1.0);
		glVertex2f(580,110);
		glTexCoord2f(0.0, 1.0);
		glVertex2f(480,110);
	glEnd();
		

	// refresh screen
	puDisplay () ;
	glutSwapBuffers   () ;
	glutPostRedisplay () ;
}

 void mousefn ( int button, int updown, int x, int y )
{
	/*if (updown == GLUT_DOWN) {
		hunger_per_sec = (hunger_per_sec == 0) ? 0.1 : 0.0;
		glutPostRedisplay () ;
	}*/
}

int main ( int argc, char **argv ) {
	// standard GL initializations
	glutInitWindowPosition( 100,   0 ) ;
	glutInitWindowSize    ( window_width, window_height ) ;
	glutInit              ( &argc, argv ) ;
	glutInitDisplayMode   ( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH ) ;
	main_window = glutCreateWindow      ( "PUI Prototype"  ) ;
	glutDisplayFunc       ( displayfn ) ;
	glutIdleFunc          ( displayfn ) ;
	glutMouseFunc(mousefn);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	// initialize PUI environment
	puInit () ;
	puSetDefaultStyle        ( PUSTYLE_SMALL_SHADED ) ;
	puSetDefaultColourScheme ( 0.3f, 0.4f, 0.6f, 1.0f) ;


	// build GUI by adding PUI widgets to the screen
	timer_text = new puText ( 10, 80 ) ;
	timer_text -> setColour ( PUCOL_LABEL, 1.0, 1.0, 1.0 ) ;
	satisfaction_text = new puText(240, 80);
	satisfaction_text -> setColour ( PUCOL_LABEL, 1.0, 1.0, 1.0 ) ;

	hunger = new puSlider(10, 60, 150, FALSE, 20);
	hunger->setLabel("Hunger");
	hunger->setValue(1.0f);
	leisure = new puSlider(10, 35, 150, FALSE, 20);
	leisure->setLabel("Leisure");
	leisure->setValue(0.0f);
	social = new puSlider(10, 10, 150, FALSE, 20);
	social->setLabel("Social");
	social->setValue(0.0f);
	bladder = new puSlider(240, 60, 150, FALSE, 20);
	bladder->setLabel("Bladder");
	bladder->setValue(1.0f);
	hygiene = new puSlider(240, 35, 150, FALSE, 20);
	hygiene->setLabel("Hygiene");
	hygiene->setValue(0.0f);
	thirst = new puSlider(240, 10, 150, FALSE, 20);
	thirst->setLabel("Thirst");
	thirst->setValue(1.0f);

	book_tex = new GLTexture();
	book_tex->Load("patterson_book.bmp");

	// init state
	orig_time = last_time = time (NULL);

	glutMainLoop () ;
	return 0 ;
}



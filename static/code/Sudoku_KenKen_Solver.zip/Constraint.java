import java.awt.Point;

/**
 * Constraints are strings in the following format:<br>
 * "# +R xy xy"<br>
 * where # is the amount of coordinates required,<br>
 * + is the operator (can be +, -, *, or /)<br>
 * R is the result of the operation<br>
 * xy are the coordinates, e.g. 24 is row 2 col 4<br>
 * <p>
 * To specify a definite number (where you just fill it in), use, for example:<br>
 * 1 3 23<br>
 * To put the number 3 in row 2 col 3.
 * @author rwillia2
 *
 */
public class Constraint {
	
	private char op;
	private int result;
	private int coordcount;
	private Point coords[];
	
	public Constraint(String str) {
		String split[] = str.split(" ");
		coordcount = Integer.parseInt(split[0]);
		if (coordcount == 1) {
			result = Integer.parseInt(split[1]);
			coords = new Point[1];
			coords[0] = new Point(Integer.parseInt(split[2].substring(0,1)), Integer.parseInt(split[2].substring(1,2)));
		} else {
			op = split[1].charAt(0);
			result = Integer.parseInt(split[1].substring(1));
			coords = new Point[coordcount];
			for (int i = 0; i < coordcount; i++)
				coords[i] = new Point(Integer.parseInt(split[2+i].substring(0,1)), Integer.parseInt(split[2+i].substring(1,2)));
		}
	}

	private void apply(int cellbits[][], int ... x) {
		if (x.length != coords.length) {
			System.err.println("Something went wrong");
			return;
		}
		for (int i = 0; i < coords.length; i++)
			for (int j = 0; j < x.length; j++)
				cellbits[coords[i].x-1][coords[i].y-1] |= (1<<x[j]);
	}
	
	public void process(int cellbits[][]) {
		if (coordcount == 1)
			cellbits[coords[0].x-1][coords[0].y-1] |= (1<<result);
		else if (coordcount == 2) {
			for (int i = 1; i <= 4; i++) {
				for (int j = 1; j <= 4; j++) {
					if (i == j) continue;
					switch (op) {
						case '+':
							if ((i + j) == result)
								apply(cellbits,i,j);
							break;
						case '*':
							if ((i * j) == result)
								apply(cellbits,i,j);
							break;
						case '/':
							if ((i / j) == result || (j / i) == result)
								apply(cellbits,i,j);
							break;
						case '-':
							if ((i - j) == result || (j - i) == result)
								apply(cellbits,i,j);
							break;
					}
				}
			}		
		} else if (coordcount == 3) {
			for (int i = 1; i <= 4; i++) {
				for (int j = 1; j <= 4; j++) {
					for (int k = 1; k <= 4; k++) {
						switch (op) {
							case '+':
								if ((i + j + k) == result)
									apply(cellbits,i,j,k);
								break;
							case '*':
								if ((i * j * k) == result)
									apply(cellbits,i,j,k);
								break;
							case '/':
								if ((i / j / k) == result || (j / i / k) == result
										|| (i / k / j) == result || (j / k / i) == result ||
										(k / i / j) == result || (k / j / i) == result)
									apply(cellbits,i,j,k);
								break;
							case '-':
								if ((i - j - k) == result || (j - i - k) == result
										|| (i - k - j) == result || (j - k - i) == result ||
										(k - i - j) == result || (k - j - i) == result)
									apply(cellbits,i,j,k);
								break;
						}
					}
				}
			}		
		} else {
			System.err.println("Too many coords...");
		}
	}
}

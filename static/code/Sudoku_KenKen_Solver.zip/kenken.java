import java.util.Scanner;

public class kenken {
	static int grid[][];
	static int cellbits[][];
	static int rowbits[];
	static int colbits[];
	static boolean done;
	
	public static void printGrid() {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if (grid[i][j] != 0)
					System.out.print(grid[i][j] + " ");
				else
					System.out.print("  ");
			}
			System.out.print("\n");
		}
	}
	
	public static void guess(int i) {
		int row, col;
		row = i/4;
		col = i-row*4;
		while (grid[row][col] != 0) {
			i++;
			col++;
			if (col == 4) {
				col = 0;
				row++;
			}
		}
		for (int j = 1; j <= 4; j++) {
			if (done) // this is required so that we kill all recursive guess()'s from stack after we're done
				return; // not doing this leads to ArrayIndexOutOfBounds errors when it gets in an infinite loop of
						// trying to find another right answer
			if ((cellbits[row][col] & (1<<j)) != 0) {
				if ((rowbits[row] & (1<<j)) == 0) {
					if ((colbits[col] & (1<<j)) == 0) {
						grid[row][col] = j;
						rowbits[row] |= (1<<j);
						colbits[col] |= (1<<j);
						if (i == 4*4-1) {
							printGrid();
							done = true;
							return;
						}
						guess(i+1);
						grid[row][col] = 0;
						rowbits[row] &= ~(1<<j);
						colbits[col] &= ~(1<<j);
					}
				}
			}
		}
		return;
	}	
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String line;
		Constraint c;
		done = false; // used to terminate all recursive methods of guess() after we find answer
		grid = new int[4][4];
		cellbits = new int[4][4];
		rowbits = new int[4];
		colbits = new int[4];
		System.out.println("Enter constraints. Empty line means end.");
		while (true) {
			line = scan.nextLine();
			if (line.equals(""))
				break;
			c = new Constraint(line);
			c.process(cellbits);
		}
		guess(0);
	}
}

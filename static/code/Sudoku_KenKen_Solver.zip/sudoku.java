import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class sudoku {
	
	static int n;
	static int rows;
	static int cols;
	static int grid[][];
	static int cellbits[][];
	static int boxbits[][];
	static int rowbits[];
	static int colbits[];
	final static int MAX_ITER = 12; // just an arbitrary number.. used to prevent an infinite loop in main solveSudoku() function
	
	/** calcBits()
	 * Initializes the array rowbits[i] and colbits[j] where i is the row and j is the col. The value of each element
	 * is the bit map that contains every number that has been used already in the row or column. 
	 */
	public static void calcBits() {
		for (int i =0; i< n; i++) {
			for (int j =0; j<n; j++) {
				if (grid[i][j] != 0) {
					rowbits[i] |= (1<<grid[i][j]);
					colbits[j] |= (1<<grid[i][j]);
				}
			}
		}
	}
	/** calcBoxBits()
	 * Initializes the array boxbits[i][j] where i is the row and j is the col of the box. The value of each element
	 * is the bit map that contains every number that has been used already in the box. 
	 */
	public static void calcBoxBits() {
		for (int i = 0; i < n/rows; i++)
			for (int j = 0; j < n/cols; j++)
				for (int r = i*n/rows; r < (i*n/rows)+n/rows; r++)
					for (int c = j*n/cols; c < (j*n/cols)+n/cols; c++)
						if (grid[r][c] != 0)
							boxbits[i][j] |= (1<<grid[r][c]);
	}
	
	/** calcCellBits()
	 * Initializes the array cellbits[i][j] where i is the row and j is the col of the cell. The value of each element
	 * is the bit map that contains every number that can possibly occupy the cell. 
	 */
	public static void calcCellBits() {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (grid[i][j] == 0) {
					cellbits[i][j] |= rowbits[i];
					cellbits[i][j] |= colbits[j];
					cellbits[i][j] |= boxbits[i/rows][j/cols];
					cellbits[i][j] = ~(cellbits[i][j]);
				}
			}
		}
	}
	/** calcCellBits2()
	 * Works exactly like calcCellBits() above except the first thing it does is take the complement of the cell bits.
	 * If we don't do this then the following ORs will be doing the opposite of what we want (unsetting the values
	 * of the numbers that can occupy the cell instead of setting them).
	 * NOTE: This is the one that is used more in the program. The calcCellBits() function is only used once to set
	 * the original values.
	 */
	public static void calcCellBits2() {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (grid[i][j] == 0) {
					cellbits[i][j] = ~(cellbits[i][j]);
					cellbits[i][j] |= rowbits[i];
					cellbits[i][j] |= colbits[j];
					cellbits[i][j] |= boxbits[i/rows][j/cols];
					cellbits[i][j] = ~(cellbits[i][j]);
				}
			}
		}
	}
	private static boolean powerOf2(int num) {
	    int num2 = 1;
	    while (num>num2){
	        num2=num2<<1;
	    }
	    return ((num^num2) == 0);
	}
	private static int[] rowInfer (int r) {
		int ret[] = new int[2];
		int num = 0;
		int first = 0;
		main_outer:
		for (int i = 0; i < n; i++) {
			if (grid[r][i] == 0) {
				first = 0;
				for (int j = 0; j < n; j++) {
					if (grid[r][j] == 0 && i != j) {
						if (first == 0) {
							num = cellbits[r][i]^cellbits[r][j];
							first++;
						} else
							num &= (cellbits[r][i]^cellbits[r][j]);
					}
				}
				num &= cellbits[r][i];
				if (num != 0 && powerOf2(num)) {
					for (int k = 0; k < n; k++) {
						if (k != i && (num & cellbits[r][k]) == num)
							continue main_outer;
					}
					ret[0] = (int) (Math.log(num)/Math.log(2));
					ret[1] = i;
					return ret;
				}
			}
		}
		return ret;
	}
	private static int[] colInfer (int c) {
		int ret[] = new int[2];
		int num = 0;
		int first = 0;
		main_outer:
		for (int i = 0; i < n; i++) {
			if (grid[i][c] == 0) {
				first = 0;
				for (int j = 0; j < n; j++) {
					if (grid[i][c] == 0 && i != j) {
						if (first == 0) {
							num = cellbits[i][c]^cellbits[j][c];
							first++;
						} else
							num &= (cellbits[i][c]^cellbits[j][c]);
					}
				}
				num &= cellbits[i][c];
				if (num != 0 && powerOf2(num)) {
					for (int k = 0; k < n; k++) {
						if (k != i && (num & cellbits[k][c]) == num)
							continue main_outer;
					}
					ret[0] = (int) (Math.log(num)/Math.log(2));
					ret[1] = i;
					return ret;
				}
			}
		}
		return ret;
	}
	/** printInt(int)
	 * Prints the binary representation of an integer. Used for debugging bitwise operators.
	 * @param n
	 */
	@SuppressWarnings("unused")
	private static void printInt (int n) {
		int i = 0;
		String x = "";
		for (i=0;i<32;i++) {
			if (((n>>i) & 1) == 1)
				x = x + "1";
			else
				x = x + "0";
		}
		StringBuffer buffer = new StringBuffer(x);
		buffer = buffer.reverse();
		System.out.println(buffer.toString());
	}
	
	/**
	 * Solve Sudoku works by iteratively moving through the grid and filling in any Naked or Hidden Singles. Unfortunately,
	 * those are the only two things it can test for, so if a puzzle requires other methods, it will not fully solve it.
	 */
	public static void solveSudoku() {
		calcBits();
		calcBoxBits();
		calcCellBits();
		int count = 0;
		int num = 0;
		int set = 0;
		int lastset = 0;
		int tmp[];
		int i, j;
		int iterations = 0;
		// this loop only runs MAX_ITER times... it should solve it then
		while (iterations < MAX_ITER) {
			iterations++;
			set = 0;
			for (i = 0; i < n; i++) {
				tmp = rowInfer(i);
				if (tmp[0] != 0) {
					j = tmp[1];
					num = tmp[0];
					cellbits[i][j] = 0;
					grid[i][j] = num;
					set++;
					rowbits[i] |= (1<<num);
					colbits[j] |= (1<<num);
					boxbits[i/rows][j/cols] |= (1<<num);
					calcCellBits2();
				}
				tmp = colInfer(i);
				if (tmp[0] != 0) {
					j = i;
					i = tmp[1];
					num = tmp[0];
					cellbits[i][j] = 0;
					grid[i][j] = num;
					set++;
					rowbits[i] |= (1<<num);
					colbits[j] |= (1<<num);
					boxbits[i/rows][j/cols] |= (1<<num);
					calcCellBits2();
				}
				for (j = 0; j < n; j++) {
					if (cellbits[i][j] != 0) {
						for (int k = 1; k <= n; k++) {
							if (count > 1)
								break;
							if ((cellbits[i][j] & (1<<k)) != 0) {
								count++;
								num = k;
							}
						}
						if (count == 1) { // only one possibility for the cell, so set it
							// actually set the number
							grid[i][j] = num;
							set++;
							// do book keeping
							cellbits[i][j] = 0; // so we know it is set later on
							rowbits[i] |= (1<<num);
							colbits[j] |= (1<<num);
							boxbits[i/rows][j/cols] |= (1<<num);
							calcCellBits2();
						}
						count = 0;
						num = 0;
					} else
						set++;
				}
			}
			System.out.println(set);
			if (lastset == set && set == 81)
				break;
			lastset = set;
		}
		System.out.println("\n\n--------------------\nSolved grid follows:");
		printGrid();
	}
	/**
	 * Prints out the Sudoku Grid. This is called at the end when everything is solved.
	 */
	public static void printGrid() {
		for (int i = 0; i < n; i++) {
			if ( ((i) % rows) == 0)
				System.out.print("\n");
			for (int j = 0; j < n; j++) {
				if (j == 0)
					System.out.print("| ");
				if (grid[i][j] != 0)
					System.out.print(grid[i][j] + " ");
				else
					System.out.print("  ");
				if ( ((j+1) % cols) == 0)
					System.out.print("| ");
			}
			System.out.print("\n");
		}
	}
	public static void main(String[] args) throws IOException {
		// initialize main variables and arrays after getting some basic variables from standard input
		Scanner scan = new Scanner(System.in);
		n = scan.nextInt();
		rows = scan.nextInt();
		cols = scan.nextInt();
		grid = new int[n][n];
		cellbits = new int[n][n];
		rowbits = new int[n];
		colbits = new int[n];
		boxbits = new int[n/rows][n/cols];
		String str;
		InputStreamReader converter = new InputStreamReader(System.in);
		BufferedReader in = new BufferedReader(converter);
		int j =0;
		// read in sudoku grid from standard input
		for (int i=0;i<=n; i++) {
			str = in.readLine();
			char[] arr = str.toCharArray();
			for (char n : arr) {
				//if (j>n) break;
				if (n == ' ') grid[i][j] = 0;
				else
					grid[i][j] = Integer.parseInt(n + "");
				j++;
			}
			j=0;
		}
		
		/* easy puzzle below used to test code
		int grid2[][] = 
		   {{0,2,0,0,0,1,0,0,9},
			{5,0,0,4,8,0,0,0,0},
			{0,3,0,2,0,0,0,0,8},
			{0,4,0,0,0,6,0,8,7},
			{0,8,7,0,0,0,6,2,0},
			{2,6,0,9,0,0,0,4,0},
			{1,0,0,0,0,9,0,7,0},
			{0,0,0,0,1,4,0,0,5},
			{6,0,0,7,0,0,0,1,0}};
		grid = grid2.clone(); */

		solveSudoku();
	}
}

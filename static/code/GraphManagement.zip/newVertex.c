/*
 * newVertex.c
 * Create new vertex with name and put it into the array.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

boolean newVertex(graph* G, char* name) {
  int length = 0;
  char* buffer;
  
  if (name == NULL || strlen(name) == 0)
    return FALSE;
  if (G->size >= G->capacity)
    if (!resize(G, G->capacity*2))
      return FALSE;

  /* copy input buffer into new malloc'd array */
  length = strlen(name);
  buffer = (char*)malloc(sizeof(char) * length);
  strcpy(buffer, name);

  /* put new buffer in names array, and modify graph parameters */
  G->names[G->size] = buffer;
  G->visited[G->size] = FALSE;
  G->size++;
  
  return TRUE;
}

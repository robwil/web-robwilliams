/*
 * dijkstra.c
 * Find the shortest path from a given node to all other nodes, using the Dijkstra's Algorithm.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

void dijkstra(graph *G, int start) {
  int i, min, minIndex, path;
  char out[50];
  
  /* initialize values */
  G->distances[start * G->capacity + start] = 0;
  G->visited[start] = TRUE;

  /* put distances from start node to all its neighbors in the distances array
     This makes the while(1) loop work correctly in finding the minimum path */
  for (i = firstNeighbor(G, start); i != NOT_FOUND; i = nextNeighbor(G, start, i))
    G->distances[start * G->capacity + i] = G->edges[start * G->capacity + i];
  
  while (1) {
    /* find the minimum path */
    for (i = 0, min = 1 << 30; i < G->size; i++) {
      if (G->visited[i]) continue;
      path = G->distances[start * G->capacity + i];
      if (path < min) {
	minIndex = i;
	min = path;
      }
    }
    
    if (min == 1 << 30) break; // because we don't have any more paths
    
    /* recalculate distances from current minimum node to all its neighbors */
    G->visited[minIndex] = TRUE;  
    for (i = firstNeighbor(G, minIndex); i != NOT_FOUND; i = nextNeighbor(G, minIndex, i)) {
      if (G->visited[i]) continue;
      path = G->edges[minIndex * G->capacity + i] + G->distances[start * G->capacity + minIndex];
      if (path < G->distances[start * G->capacity + i]) G->distances[start * G->capacity + i] = path;
    }
  }

  write(1, "Shortest Path\n", 14);
  for (i = 0; i < G->size; i++)
    {
      sprintf(out, "to %d: %d \n", i, G->distances[start * G->capacity + i]); 
      write(1, out, strlen(out));
    }

  
}

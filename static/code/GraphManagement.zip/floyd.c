/*
 * floyd.c
 * Find the shortest path between all pairs of nodes, using the Floyd's algorithm.
 *
 *  Created on: May 3, 2009
 *      Author: rwillia2
 */

#include "graph.h"

void floyd(graph* G) {
  int i,j,k;
  int min;
  char out[10]; // used to output number swith sprintf
  /* copy existing, unminimzed edges into distances array */
  memcpy(G->distances, G->edges, G->capacity * G->capacity * sizeof(int));
  
  /* minimize G->distances using dynamic programming concept of sub problems */
  for (k = 0; k < G->capacity; k++) {
    for (i = 0; i < G->capacity; i++) {
      for (j = 0; j < G->capacity; j++) {
	if (i == j) G->distances[i * G->capacity + j] = 0;
	// set D[i,j] to minimum of D[i,j] and D[i,k] + D[k,j]
	// we have a lot of if statements to take care of infinite case (-1)
	if (G->distances[i * G->capacity + j] == -1) 
	  {
	    if (G->distances[i * G->capacity + k] == -1)
	      continue;
	    if (G->distances[k * G->capacity + j] == -1)
	      continue;
	    G->distances[i * G->capacity + j] = G->distances[i * G->capacity + k] + G->distances[k * G->capacity + j];
	  }
	else if (G->distances[i * G->capacity + k] == -1 || G->distances[k * G->capacity + j] == -1) 
	  {
	    if (G->distances[i * G->capacity + j] == -1)
	      continue;
	    // else distance stays the same
	  }
	else 
	  {
	    if (G->distances[i * G->capacity + j] < G->distances[i * G->capacity + k] + G->distances[k * G->capacity + j])
	      G->distances[i * G->capacity + j] = G->distances[i * G->capacity + j];
	    else
	      G->distances[i * G->capacity + j] = G->distances[i * G->capacity + k] + G->distances[k * G->capacity + j];
	  }
      }
    }
  }

  /* print out 2D array of distances */
  write(1, "\nShortest Paths\n\t", 17);
  for (i = 0; i < G->size; i++) 
    {
      write(1, G->names[i], strlen(G->names[i]));
      write(1, "\t", 1);
    }
  write(1, "\n", 1);
  for (i = 0; i < G->size; i++) 
    {
      write(1, G->names[i], strlen(G->names[i]));
      write(1, "\t", 1);
      for (j = 0; j < G->size; j++) 
	{
	 
	  sprintf(out, "%d\t", G->distances[i * G->capacity + j]);
	  write(1, out, strlen(out));
	}
      write(1, "\n", 1);
    }
}

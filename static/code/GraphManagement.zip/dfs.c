/*
 * dfs.c
 * Depth First Search - Perform a DFS using a recursive call to implement backtracking.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

void dfs(graph* G, int start) {
  int n;

  if (start < 0 || start > G->size)
    return;

  /* go to the first neighbor of the current node (this is recursive so "start" is not necessarily the original node)
     and then go to that node's first neighbor, as far as possible. When it can't go any further, it returns and therefore
     backtracks to print out the rest. */
  for (n = firstNeighbor(G, start); n != NOT_FOUND; n = nextNeighbor(G, start, n)) {
    if (!G->visited[n]) {
      G->visited[n] = TRUE;
      write(1, ", ", 2);
      write(1, G->names[n], strlen(G->names[n]));
      dfs(G, n);
    }
  }
  //write(1, " ", 1);
}

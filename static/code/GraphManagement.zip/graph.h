/*
 * graph.h
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#ifndef GRAPH_H_
#define GRAPH_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifndef NULL
#define NULL 0
#endif

#ifndef NOT_FOUND
#define NOT_FOUND -1
#endif

#ifndef BOOLEAN_T
#define BOOLEAN_T
typedef char boolean;
#ifndef TRUE
#define TRUE 1
#endif // true
#ifndef FALSE
#define FALSE 0
#endif // false
#endif // boolean

typedef struct s_graph {
	int size;
	int capacity;
	char** names;
	boolean* visited;
	int* edges;
	int* distances; /* used by Dijkstra's and Floyd's algorithm */
} graph;

/* main function signatures */
boolean newVertex(graph* G, char* name);
boolean newEdge(graph* G, int index1, int index2, int weight);
boolean readFromFile(graph* G, char* file);
void bfs(graph* G, int start);
void dfs(graph* G, int start);
void dijkstra(graph* G, int start);
void prims(graph* G, int start);
void floyd(graph* G);

/* helper function signatures */
graph* create(int startingCapacity);
boolean resize(graph* G, int newCapacity);
int firstNeighbor(graph* G, int index);
int nextNeighbor(graph* G, int index, int currentNeighbor);
void cleanup(graph* G);

#endif /* GRAPH_H_ */

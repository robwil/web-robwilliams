/*
 * prims.c
 *
 *  Created on: May 3, 2009
 *      Author: rwillia2
 */

#include "graph.h"

void prims(graph* G, int start) {
  int i, n, path, min, minIndex;
  int weight = 0; // represents the weight of the minimum spanning tree

  /* visitedNodes represents the nodes we've been to already */
  int* visitedNodes = (int*)malloc(sizeof(int) * G->size);
  memset(visitedNodes, 0, G->size * sizeof(int));
  int visited = 0;
  char out[10]; // used to output weight using sprintf and write

  /* set start node as a visited node */
  G->visited[start] = TRUE;
  visitedNodes[visited++] = start;
  
  while (visited < G->size) { // keep going until we've seen all nodes

    /* check neighbors of all visited nodes and find the minimum value that hasn't been visited so far */
    for (i = 0, min = 1 << 30; i < visited; i++) {
      for (n = firstNeighbor(G,visitedNodes[i]); n != NOT_FOUND; n = nextNeighbor(G,visitedNodes[i],n)) {
	if (G->visited[n]) continue;
	path = G->edges[visitedNodes[i] * G->capacity + n];
	if (path < min) {
	  min = path;
	  minIndex = n;
	}
      }
    }
    if (min == 1 << 30) break; // means we haven't found a min, so stop loop

    /* mark node as visited and add its weight to overall */
    G->visited[minIndex] = TRUE;
    visitedNodes[visited++] = minIndex;
    weight += min;
  }

  /* Print out the path, as well as the weight */
  write(1, "Path: ", 6);
  for (i = 0; i < visited; i++) 
    {
      sprintf(out, "%d", visitedNodes[i]);
      if (i != 0) write(1, " -> ", 4);
      write(1, out, strlen(out));
    }
  write(1, "\nMST Weight: ", 13);
  sprintf(out, "%d", weight);
  write(1, out, strlen(out));
  
}

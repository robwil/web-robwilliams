/*
 * bfs.c
 * Breadth First Search algorithm, using an array that acts as a very basic queue, instead of a whole new data structure.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

void bfs(graph* G, int start) {
  int n, i;
  boolean skip = TRUE;
  
  /* create queue and put start node in it at first */
  int queue[G->size + 1];
  for (i = 0; i < G->size + 1; i++)
    queue[i] = -1;
  int head = 0;
  int next = 0;
  queue[next++] = start;

  /* go until queue loops around or we encounter a -1 (meaning queue is equivalent to empty) */
  while (queue[head] != -1) {

    /* dequeue from queue array and set it to visited */
    start = queue[head++];
    if (G->visited[start]) break;
    G->visited[start] = TRUE;
    if (skip == TRUE) skip = FALSE;
    else write(1, ", ", 2);
    write(1, G->names[start], strlen(G->names[start]));
    
    /* add all neighbors of start that aren't on queue to the queue */
    for (n = firstNeighbor(G, start); n != NOT_FOUND; n = nextNeighbor(G, start, n)) 
      {
	if (G->visited[n]) continue;
	for (i = 0; i < next; i++)
	  if (queue[i] == n)
	    skip = TRUE;
	if (skip) 
	  {
	    skip = FALSE;
	    continue;
	  }
	queue[next++] = n;
      }
  }
  
}

/*
 * nextNeighbor.c
 * Return next neighbor, given an index and the currentNeighbor.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

int nextNeighbor(graph* G, int index, int currentNeighbor) {
	int i;
	for (i = currentNeighbor+1; i < G->size; i++)
		if (G->edges[index * G->capacity + i] != -1)
			return i;
	return NOT_FOUND;
}

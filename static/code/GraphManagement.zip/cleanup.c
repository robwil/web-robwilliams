/*
 * cleanup.c
 * Cleanup utility function used to make sure some things are initialized before running any other functions.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

void cleanup(graph* G) {
  int i,j;
  memset(G->visited, FALSE, G->capacity);
  for (i = 0; i < G->capacity; i++)
    for (j = 0; j < G->capacity; j++)
      G->distances[i * G->capacity + j] = 1 << 30;
  
}

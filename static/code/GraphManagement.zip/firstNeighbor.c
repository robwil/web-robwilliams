/*
 * firstNeighbor.c
 * Returns the first neighbor of the node at index.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

int firstNeighbor(graph* G, int index) {
	int i;
	for (i = 0; i < G->size; i++)
		if (G->edges[index * G->capacity + i] != -1)
			return i;
	return NOT_FOUND;
}

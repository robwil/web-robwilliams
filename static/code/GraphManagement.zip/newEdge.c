/*
 * newEdge.c
 * Create a new edge between two nodes identified by their index.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

boolean newEdge(graph* G, int index1, int index2, int weight) {
  
  /* some error checking */
  if (weight < 0)
    return FALSE;
  
  /* create the actual edge in adjacency matrix */
  G->edges[index1 * G->capacity + index2] = weight;
  G->edges[index2 * G->capacity + index1] = weight;
  
  return TRUE;
}

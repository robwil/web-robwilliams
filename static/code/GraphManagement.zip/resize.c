/*
 * resize.c
 * Used to resize the graph to a new capacity. Takes care of resizing all arrays and values.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

boolean resize(graph* G, int newCapacity) {
	int i, j;
	if (newCapacity < G->capacity)
		return FALSE;
	G->names = (char**) realloc(G->names, sizeof(char*) * newCapacity);
	G->visited = (boolean*) realloc(G->visited, sizeof(boolean) * newCapacity);
	memset(G->visited, FALSE, newCapacity * sizeof(boolean));
	G->edges = (int*) realloc(G->edges, sizeof(int) * newCapacity * newCapacity);
	/* need to set new edge possibilities to -1 but only in new areas */
	for (i = 0; i < G->capacity; i++)
		for (j = G->capacity; j < newCapacity; j++)
			G->edges[i * newCapacity + j] = -1;
	for (i = G->capacity; i < newCapacity; i++)
		for (j = 0; j < newCapacity; j++)
			G->edges[i * newCapacity + j] = -1;
	G->capacity = newCapacity;
	G->distances = (int*) realloc(G->distances, sizeof(int) * newCapacity * newCapacity);
	return TRUE;
}

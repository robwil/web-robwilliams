/*
 * create.c
 * Create a new graph object.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

graph* create(int startingCapacity) {
  int i, j;
  if (startingCapacity <= 0)
    return NULL;

  /* allocate memory for the new graph struct */
  graph* newGraph = (graph*)malloc(sizeof(graph));
  
  /* set basic values to defaults */
  newGraph->size = 0;
  newGraph->capacity = startingCapacity;

  /* initialize and set up the arrays */
  newGraph->names = (char**) malloc(sizeof(char*) * startingCapacity);
  newGraph->visited = (boolean*) malloc(sizeof(boolean) * startingCapacity);
  memset(newGraph->visited, FALSE, startingCapacity * sizeof(boolean));
  newGraph->edges = (int*) malloc(sizeof(int) * startingCapacity * startingCapacity);
  for (i = 0; i < startingCapacity; i++)
    for (j = 0; j < startingCapacity; j++)
      newGraph->edges[i * startingCapacity + j] = -1;
  newGraph->distances = (int*) malloc(sizeof(int) * startingCapacity * startingCapacity);

  return newGraph;
}

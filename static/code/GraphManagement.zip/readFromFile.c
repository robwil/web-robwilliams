/*
 * readFromFile.c
 * Reads from the file specified by the file char*, and adds all the vertices and edges that it specifies.
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

boolean readFromFile(graph* G, char* file) 
{
  int i, index1 = NOT_FOUND, index2 = NOT_FOUND;
  FILE* fd;
  char buffer[80];
  char* split = "|";
  char* token;

  /* open file */
  fd = fopen(file, "r");
  if (fd == NULL)
    {
      write(0, "Error opening file\n",19);
      return FALSE;
    }
  else 
    {
      /* read file line by line into buffer */
      while(fgets(buffer, 80, fd))
	{
	  switch (buffer[0])
	    {
	      /* if we find vertex in file, use newVertex to add it */
	    case 'V':
	      buffer[strlen(buffer)-1] = '\0';
	      newVertex(G, buffer+2);
	      break;
	      
	      /* if we find edge in file, use newEdge to add it */
	    case 'E':
	      /* split edge line into tokens */
	      token = strtok(buffer, split);
	      token = strtok(NULL, split);
	      
	      /* find indices that correspond to two names */
	      for (i = 0; i < G->size; i++) 
		{ 
		  if (!strcmp(G->names[i], token))
		    index1 = i;
		}
	      if (index1 == NOT_FOUND) 
		{
		  write(0, "Name not found.\n", 16);
		  continue;
		}

	      /* get the second name index */
	      token = strtok(NULL, split);
	      for (i = 0; i < G->size; i++) 
		{
		  if (!strcmp(G->names[i], token))
		    index2 = i;
		}
	      if (index2 == NOT_FOUND) 
		{
		  write(0, "Name not found.\n", 16);
		  continue;
		}
	      
	      /* get the weight */
	      token = strtok(NULL, split);
	      i = atoi(token);

	      newEdge(G, index1, index2, i);
	      
	      break;
	      
	    default:
	      // if we get an improper line, ignore it
	      break;
	    }
	}  
    }
  fclose(fd);

  write(1, "Success.\n", 9);
  
}


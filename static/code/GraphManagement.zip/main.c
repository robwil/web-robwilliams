/*
 * main.c
 * Main Program - displays a menu to allow users to interactively create a graph and work with it
 *
 *  Created on: May 2, 2009
 *      Author: rwillia2
 */

#include "graph.h"

int main(int argc, char** argv) {
  int i, j, bytes, cap, choice;
  char in[10]; // used to read in numerical values
  char out[10]; // used to output numerical values
  char buffer[80]; // used to read in string values

  /* get initial capacity from user */
  write(1, "What do you want the starting capacity of the graph to be?\n", 59);
  bytes = read(0, in, 10);
  in[bytes - 1] = '\0';
  cap = atoi(in);

  /* create graph structure */
  graph* g = create(cap);

  /* main menu repeats until user asks to exit */
  while (1) 
    {
      /* display menu to screen */
      write(1, "\nMenu:\n", 7);
      write(1, "1) Add Node\n", 12);
      write(1, "2) Add Edge\n", 12);
      write(1, "3) Load from File\n", 18);
      write(1, "4) DFS Traversal\n", 17);
      write(1, "5) BFS Traversal\n", 17);
      write(1, "6) MST\n", 7);
      write(1, "7) Shortest Path\n", 17);
      write(1, "8) All Pairs Shortest Path\n", 27);
      write(1, "9) Print Edges\n", 15);
      write(1, "0) Exit\n", 8);
      write(1, "Enter your choice: ", 19);
  
      /* read choice to choice variable */
      bytes = read(0, in, 10);
      in[bytes] = '\0';
      choice = atoi(in);

      /* decide what to do based on user's input */
      switch(choice) 
	{
	  
	case 1:
	  write(1, "\nEnter label for new node: ", 28);
	  bytes = read(0, buffer, 80);
	  buffer[bytes-1] = '\0';
	  if (newVertex(g, buffer))
	    write(1, "Success.\n", 9);
	  else
	    write(1, "Error.\n", 7);
	  break;
	  
	case 2:
	  write(1, "\n", 1);
	  for (i = 0; i < g->size; i++) 
	    {
	      memset(in, 0, 0);
	      bytes = sprintf(in, "%d ", i);
	      in[bytes] = '\0';
	      write(1, in, strlen(in));
	      write(1, g->names[i], strlen(g->names[i]));
	      write(1, "\n", 1);
	    }
	  write(1, "\nEnter index of start node for new edge: ", 42);
	  bytes = read(0, in, 10);
	  in[bytes-1] = '\0';
	  i = atoi(in);
	  if (i < 0 || i > g->size - 1) 
	    {
	      write(1, "Input error.\n", 13);
	      break;
	    }
	  write(1, "Enter index of end node for new edge: ", 38);
	  bytes = read(0, in, 10);
	  in[bytes-1] = '\0';
	  j = atoi(in);
	  if (j < 0 || j > g->size - 1 || i == j) 
	    {
	      write(0, "Input error.\n", 13);
	      break;
	    }
	  write(1, "Enter weight of edge: ", 22);
	  bytes = read(0, in, 10);
	  in[bytes-1] = '\0';
	  cap = atoi(in);
	  if (cap < 0) 
	    {
	      write(1, "Input error.\n", 13);
	      break;
	    }
	  
	  if (newEdge(g, i, j, cap))
	    write(1, "Success.\n", 9);
	  else
	    write(1, "Error.\n", 7);
	  
	  break;
	  
	case 3:
	  write(1, "\nEnter filename: ", 17);
	  bytes = read(0, buffer, 80);
	  buffer[bytes-1] = '\0';
	  readFromFile(g, buffer);
	  break;
	  
	case 4:
	  write(1, "\nEnter starting node: ", 22);
	  bytes = read(0, in, 10);
	  in[bytes] = '\0';
	  i = atoi(in);
	  if (i < 0 || i > g->size) 
	    {
	      write(1, "Input Error.\n", 13);
	      break;
	    }
	  
	  cleanup(g); // resets visited
	  g->visited[i] = TRUE;
	  write(1, g->names[i], strlen(g->names[0]));
	  dfs(g, i);
	  write(1, "\n", 1);
	  break;
	  
	case 5:
	  write(1, "\nEnter starting node: ", 22);
	  bytes = read(0, in, 10);
	  in[bytes] = '\0';
	  i = atoi(in);
	  if (i < 0 || i > g->size) 
	    {
	      write(1, "Input Error.\n", 13);
	      break;
	    }
	  
	  cleanup(g); // resets visited
	  bfs(g, i);
	  write(1, "\n", 1);
	  break;
	  
	case 6:
	  write(1, "\nEnter starting node: ", 22);
	  bytes = read(0, in, 10);
	  in[bytes] = '\0';
	  i = atoi(in);
	  if (i < 0 || i > g->size) 
	    {
	      write(1, "Input Error.\n", 13);
	      break;
	    }
	  
	  cleanup(g); // resets visited
	  prims(g, i);
	  write(1, "\n", 1);
	  break;
	  
	case 7:
	  write(1, "\nEnter starting node: ", 22);
	  bytes = read(0, in, 10);
	  in[bytes] = '\0';
	  i = atoi(in);
	  if (i < 0 || i > g->size) 
	    {
	      write(1, "Input Error.\n", 13);
	      break;
	    }
	  
	  cleanup(g); // resets visited and distances
	  dijkstra(g, i);
	  write(1, "\n", 1);
	  break;
	  
	case 8:
	  floyd(g);
	  write(1, "\n", 1);
	  break;
	  
	case 9:
	  for (i = 0; i < g->capacity; i++) 
	    {
	      for (j = 0; j < g->capacity; j++) 
		{
		  sprintf(out, "%d\t", g->edges[i * g->capacity + j]);
		  write(1, out, strlen(out));
		}
	      write(1, "\n", 1);
	    }
	  break;
	  
	case 0:
	  exit(0);
	  break;
	}
    }
  
  return 0;
}

import java.util.Scanner;
import java.util.Arrays;
import java.io.*;

@SuppressWarnings("unused")
public class prime { // 513927161
	static FileOutputStream fout;		
	static PrintStream ps;
	public static void main(String[] args) {
		
		try
		{
		    // Open an output stream
		    fout = new FileOutputStream ("primes.txt");

		    // Print a line of text
		    ps = new PrintStream(fout);
		    driver();
		    // Close our output stream
		    fout.close();		
		}
		// Catches any error conditions
		catch (IOException e)
		{
			System.err.println ("Unable to write to file");
			System.exit(-1);
		}
		
		/*Scanner scan = new Scanner(System.in);
		System.out.print("enter n:");
		long n = scan.nextLong();
		//System.out.print("enter a:");
		//long a = scan.nextLong();
		//System.out.println(isFermatSPRP(n,a));
		int ret = primalityTest(n);
		if (ret == 0)
			System.out.println("NOT PRIME");
		else if (ret == 1)
			System.out.println("PRIME");*/
	}
	
	private static void driver() {
		long sum = 2;
		long amount = 1;
		for (int i = 3; i < 2000000; i+= 2) {
			if (primalityTest(i) == 1) {
				if (++amount == 10001) {
					System.out.println(i);
					break;
				}
				// uncomment below to output all primes found to file primes.txt
				//ps.println(i);
				sum += i;
			}
		}
		System.out.println(sum);
	}
	
	/* primalityTest(long n) tests if n is prime, using a composite (no pun intended) of methods
	 * first, the Fermat test for PRPs is used to quickly rule out certain numbers that aren't prime
	 * second, the Fermat test for SPRPs for base a is used, where base a = every prime number from 1 to 17.
	 * this function works for any n < 341,550,071,728,321 according to research by Jaeschke
	 * 
	 * returns 1 for prime, 0 for not prime, -1 for error
	 */
	public static byte primalityTest(long n) {
		long primes[] = {2, 3, 5, 7, 11, 13, 17};
		if (n >= 341550071728321l)
			System.out.println("You must test a positive number less than 341,550,071,728,321.");
		else if (n <= 1)
			System.out.println("You must test a positive number greater than 1.");
		else if (n <= 17) { // test low primes quickly since we already have them in array
			if (Arrays.binarySearch(primes, n) > -1) // found n in primes[] so it is prime
				return 1;
			else // otherwise, it's not prime
				return 0;
		} else if (!odd(n)) { // means it is an even number
			// keep in mind, if it was 2, the previous condition would have took care of it
			// so we don't have to worry about that situation
			// Anyway, if it's even and not 2, it's not prime
			return 0;
		} else { // means it is odd, so use other methods to test primality
			//if (!isFermatPRP(n)) // use Fermat test for PRP first to quickly rule out not prime numbers
			//	return 0;
			//else { // now we use Fermat test for SPRP
				for (int i = 0; i < primes.length; i++) {
					if (!isFermatSPRP(n,primes[i]))
						return 0;
				}
				// if it got here, it must be prime
				return 1;
			//}
		}
		return -1; // if it gets here, there was an error.
	}

	/*isFermatSPRP(long a) uses the Fermat test for super probable prime numbers (SPRPs)
	 * Mathematical definition for super probable prime numbers is as follows:
	 * --------------------------------------------------------------
		Write n-1 = (2^s)*d where d is odd and s is non-negative:
		n is a strong probable-prime base a (an a-SPRP) if either:
			a^d mod n = +-1 mod n or (a^d)^(2r) mod n = -1 mod n
				(for some non-negative r less than s).
	   --------------------------------------------------------------
				We must do some simplification of this math to make it
				practical to program.
				
			1 mod n gets simplified to 1 by properties of modular arithmetic
			similarly, -1 mod n gets simplified to -1
			a = 2, d = 42 r = 7 n = 41
			Also, (a^d)^(2r) mod n is the same as ((a^d) mod n)^(2r) mod n
			Because of the way mod works, a negative is never returned, so we will never get -1.
			9 % 5 = 4 in Java, but, by congruent class of modulo, 9 % 5 === -1
			In other words, if a % m = m - 1, a % m === -1.
			All of this makes the test cases now:
			a^d mod n = 1 OR a^d mod n = n-1 OR ((a^d) mod n)^(2r) mod n = n-1
		(
	*/
	private static boolean isFermatSPRP(long n, long a) {
		// first step is to Write n-1 = (2^s)*d where d is odd and s is non-negative
		// This is accomplished by starting d at n-1 and dividing by 2, incrementing s each time.
		long d = n - 1;
		long s = 0;
		while (!odd(d)) {
			d >>= 1; // d /= 2
			s++;
		}
		// next test if a^d mod n = 1 OR a^d mod n = n-1 OR ((a^d) mod n)^(2r) mod n = n-1
		// r is any non-negative integer less than s, so we loop through all possibilities (if first one doesn't work)
		long r = 1;
		long p = modpower(a,d,n);
		// note: since p represents a^d mod n, ((a^d) mod n)^(2r) mod n = n-1 can be rewritten p^2r mod n which saves time
		// 		( because p is calculated once and then used over and over)
		if (p == 1 || p == n-1)
			return true;
		for (r = 1; r < s; r++) {
			p = modpower(p, 2, n);
			if (p == n-1) return true;
		}
		return false;
	}


	/* isFermatPRP(long a) uses the Fermat test for probable prime numbers (PRPs)
		Given n > 1, choose a > 1 and calculate a^n-1 modulo n:
			If the result is not one modulo n, then n is composite, so return false.
			If it is one modulo n, then n might be prime, so return true.
			Note: 1 % n = 1
	*/
	private static boolean isFermatPRP(long n) {
		long x = n;
		if (x > 100) // only test first 1000 bases to keep speed high
			x = 100;
		for (long a=2; a < x; a++) {
			if (modpower(a,n-1,n) != 1)
				return false;
		}
		return true;
	}

	/* power (long n, long a) calculates n^a very efficiently using binary decomposition
	 * it is, however, commented out, because we don't use it in this program. It remains
	 * because it is the base for the following function, modpower.
	 */
	/*private static long power(long n, long a) {
		long prod = 1;
		while (a > 1) {
			if (odd(a)) prod *= n;
			a >>= 1; // a /= 2
			n *= n;
		}
		return n*prod;
	}*/
	
	/* modpower(long n, long a, long m) calculates n^a mod m very efficiently
	 * using binary decomposition.
	 * due to the properties of mods, we simply apply %m to all mathematical
	 * operations that have to do with the return value (which excludes the
	 * value of the exponent, a) to change power(long,long) to modpower(long,long,long)
	 */
	public static long modpower(long n, long a, long m) {
		long prod = 1;
		while (a > 1) {
			if (odd(a)) prod = (prod * n) % m;
			a >>= 1; // a >>= 1 is a /= 2
			n = (n*n) % m;
		}
		return (n*prod)%m;
	}
	
	/* odd(long n) returns true if n is odd, false if n is even. used all over this program */
	public static boolean odd(long n) {
		return ((n % 2) != 0);
	}
}
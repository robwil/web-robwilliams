import java.util.Scanner;

public class primeCount {
	
	public static void main(String[] args) {
		System.out.println("This program counts primes between two numbers, inclusive.");
		Scanner scan = new Scanner(System.in);
		System.out.print("enter starting number:");
		long n = scan.nextLong();
		System.out.print("enter ending number:");
		long a = scan.nextLong();
		long count = 0;
		for (long i=n; i <= a; i++) {
			int ret = primeSlow.primalityTest(i);
			//961750633
			//961754351
			//System.out.print(i);
			//if (ret == 1)
			//	System.out.println(i + " is PRIME");
			//else
			//	System.out.println(" is NOT PRIME");
			if (ret == 1)
				count++;
		}
		System.out.println("There are " + count + " primes between " + n + " and " + a + ", inclusive.");
	}
	
}

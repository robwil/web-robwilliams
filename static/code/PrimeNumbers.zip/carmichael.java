import java.util.Scanner;

public class carmichael {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("enter n:");
		long n = scan.nextLong();
		System.out.println(isCarmichael(n));
	}
	
	/* 
	 * boolean isCarmichael(long n) returns whether or not n is a Carmichael number
	 * a Carmichael number is defined as follows:
	 * The composite integer n is a Carmichael number if a^(n-1) mod n=1
	 * for every integer a coprime to n. 
	 */
	public static boolean isCarmichael(long n) {
		if (primeSlow.primalityTest(n) == 1 || n <= 1) // Carmichael numbers can't be prime
			return false;
		for (long a = 1; a < n; a++)
			if (isCoprime(n,a))
				if (prime.modpower(a, n-1, n) != 1)
					return false;
		return true;
	}
	
	/*
	 * boolean isCoprime(long a, long b) returns whether or not n and m are coprime
	 * coprime is defined as follows:
	 * the integers a and b are said to be coprime if their greatest common divisor is 1
	 */
	private static boolean isCoprime(long a, long b) {
		if (gcd(a,b) == 1)
			return true;
		else
			return false;
	}
	
	
	 /* 
	  * long gcd(long a, long b) returns the GCD (greatest common divisor) of a and b
	  * It uses the Euclidean algorithm for GCD, which is defined as follows:
	  * Given two natural numbers a and b,
	  * check if b is zero; if yes, a is the gcd.
	  * If not, repeat the process using, respectively, b, and the remainder after dividing a by b. 
	  * (The remainder after dividing a by b is usually written as a % b.)
	  */
	private static long gcd(long a, long b) {
		if (b == 0)
			return a;
		else
			return gcd(b, a % b);
	}
}

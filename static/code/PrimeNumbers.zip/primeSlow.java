import java.util.Scanner;


public class primeSlow { //513927161
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("enter n:");
		long n = scan.nextLong();
		int ret = primalityTest(n);
		if (ret == 0)
			System.out.println("NOT PRIME");
		else if (ret == 1)
			System.out.println("PRIME");
	}
	
	public static byte primalityTest(long n) {
		if (n == 1)
			return -1;
		else if (!odd(n))
			return -1;
		for (long i = 3; i <= Math.sqrt(n); i+=2) {
			// note: we don't need a test for n == i because of the i < Math.sqrt(n) condition
			if (n % i == 0) {
				return 0;
			}
		}
		return 1;
	}
	
	/* odd(long n) returns true if n is odd, false if n is even. used all over this program */
	public static boolean odd(long n) {
		return ((n % 2) != 0);
	}
}
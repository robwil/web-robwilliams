import java.util.Scanner;

public class carmichaelcount {
	
	public static void main(String[] args) {
		System.out.println("This program counts Carmichaels between two numbers, inclusive.");
		Scanner scan = new Scanner(System.in);
		System.out.print("enter starting number:");
		long n = scan.nextLong();
		System.out.print("enter ending number:");
		long a = scan.nextLong();
		long count = 0;
		for (long i=n; i <= a; i++) {
			boolean ret = carmichael.isCarmichael(i);
			//System.out.print(i);
			//if (ret)
			//	System.out.println(i + " is Carmichael number");
			//else
			//	System.out.println(" is NOT Carmichael number");
			if (ret)
				count++;
		}
		System.out.println("There are " + count + " Carmichaels between " + n + " and " + a + ", inclusive.");
	}
	
}

public class measureSpeed {
	public static void main(String[] args) {
		int i; long before, after; double primeTime, primeSlowTime;
		before = System.nanoTime();
		for (i=3;i<1000000;i+=2) {
			prime.primalityTest(i);
		}
		after = System.nanoTime();
		primeTime = (after - before)/1000000000.0;/*primeTime = 0;/**/
		System.out.println("done prime");
		before = System.nanoTime();
		for (i=3;i<1000000;i+=2) {
			primeSlow.primalityTest(i);
		}
		after = System.nanoTime();
		primeSlowTime = (after - before)/1000000000.0;
		System.out.println("done primeSlow");
		System.out.println("Prime Time: " + primeTime + "\nPrime Slow Time: " + primeSlowTime);
	}
}

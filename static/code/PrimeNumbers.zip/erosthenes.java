import java.util.*;

public class erosthenes {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("enter n:");
		long n = scan.nextLong();
		if (n > 2000000)
			System.out.println("2000000 is max value");
		else
			sieve(n);
	}

	private static void sieve(long n) {
		List<Long> list = new ArrayList<Long>();
		for (long i = 2; i < n; i++)
			list.add(i);
		int index = 0;
		long newPrime = 0;
		long sqrtOfN = (long) Math.sqrt(n);
		while (index < list.size()) {
			newPrime = list.get(index);
			System.out.println(newPrime);
			if (newPrime > sqrtOfN) // we can skip below loop. all numbers in list are prime
				index++;
			else
				for (int i = ++index; i < list.size(); i++)
					if (list.get(i) % newPrime == 0)
						list.remove(i);
		}
	}
}

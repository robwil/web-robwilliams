Skindle GUI by Rob Williams



Here is a quick guide on how to use the program:



1. Buy the book you want from Amazon.



2. Download and install Kindle for PC.



3. View the book in Kindle for PC. (in other words, make sure it is downloaded to your computer, not in "Archived Items")



4. Open SkindleGUI (download link below).



5. The program will list all the Kindle books on your computer. The filenames don't have anything to do with the book title, so you probably won't know which is your book. However, when you select a book it will display its cover image, and this should help you find the book you want.



6. Browse for output anywhere (e.g. your desktop) and give it a file name.



7. Press Convert.



8. You can now use the outputted file as input for Calibre or another tool to convert it to the format you want.







See http://robwilliams.me/2010/07/skindle-gui/ for more info.
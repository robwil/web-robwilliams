<?php
////////////////////////////////////////////////////////////////////////////////////////
//////																			  //////
//////    Make sure you put your Wordpress URL/username/password below.			  //////
//////																			  //////
////////////////////////////////////////////////////////////////////////////////////////

$url = "http://www.yoursite.com/wordpress/"; // wherever the xmlrpc.php file is
$user = "admin";
$pass = "your_pass";

////////////////////////////////////////////////////////////////////////////////////////
//////																			  //////
//////    Anything below here will probably need to be changed, since it's		  //////
//////	  pretty specific to Hoboken Grace's setup (we use the Powerpress plug-in)//////
//////																			  //////
////////////////////////////////////////////////////////////////////////////////////////

// parse arguments
// call with php xmlrpc.php -f "/path/to/file.mp3" -t "title" -d "description"
// 							-u "h:mm:ss" -s "file size in bytes"
$arguments = getopt("f:t:d:u:s:");
$filename = $arguments['f'];
$name = basename($filename);
$title = $arguments['t'];
$description = $arguments['d'];
$duration = $arguments['u'];
$filesize = $arguments['s'];
//print_r($arguments);

// setup base parameters
require("wp-includes/class-IXR.php");
$blog_id = 1;
$rpc_url = $url . "xmlrpc.php";

// start up IXR client
$client = new IXR_Client($rpc_url);

// upload file
$file = new IXR_Base64(file_get_contents($filename));
$post = array(
	"name" => $name,
	"type" => "audio/mpeg",
	"bits" => $file,
	"overwrite" => "true"
);
$status = $client->query("wp.uploadFile", $blog_id, $user, $pass, $post);
// check for error and report success/failure
if (!$status) {
	print("Error in RPC request\n");
	print_r($client);
	exit(1);
}
$result = $client->getResponse();
$url = $result['url'];


// construct enclosure in form that PowerPress likes podcasts
$enclosure = $url . "\n" . $filesize . "\naudio/mpeg\n";
$enclosure .= "a:1:{s:8:\"duration\";s:7:\"" . $duration . "\";}";
// construct post structure including title, description, enclosure
$post = array(
	"title" => $title,
	"description" => $description,
	"categories" => array("Podcast"),
	"post_type" => "post",
	"custom_fields" => array(array(
		"key" => "enclosure",
		"value" => $enclosure
	))
);
// send new post request
$status = $client->query("metaWeblog.newPost", $blog_id, $user, $pass, $post, true);
// check for error and report success/failure
if (!$status) {
	print("Error in RPC request\n");
	print_r($client);
	exit(1);
}

$result = $client->getResponse();
print($url . "?p=$result");
?>
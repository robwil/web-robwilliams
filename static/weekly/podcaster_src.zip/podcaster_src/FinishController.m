//
//  FinishController.m
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/26/10.
//  Copyright 2010 RobWilliams. All rights reserved.
//

#import "FinishController.h"

@implementation FinishController

- (IBAction)quit:(id)sender
{
	[NSApp terminate:self];	
}

@end

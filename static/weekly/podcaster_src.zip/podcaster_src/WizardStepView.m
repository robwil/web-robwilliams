//
//  WizardStepView.m
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "WizardStepView.h"


@implementation WizardStepView

@synthesize previousView, nextView;

- (void) awakeFromNib
{
	// disable buttons if their destination doesn't exist
	[previousButton setEnabled:(previousView != nil)];
	[nextButton setEnabled:(nextView != nil)];
}

@end

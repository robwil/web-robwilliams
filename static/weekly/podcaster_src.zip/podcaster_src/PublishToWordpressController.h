//
//  PublishToWordpressController.h
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/25/10.
//  Copyright 2010 RobWilliams. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WizardStepView.h"
@class HobokenGracePodcasterAppDelegate;

@interface PublishToWordpressController : NSObject {
	IBOutlet HobokenGracePodcasterAppDelegate *delegate;
	IBOutlet WizardStepView *publishToWordpressView;
	
	IBOutlet NSTextField *convertedAudioPath;
	IBOutlet NSTextField *titleText;
	IBOutlet NSTextField *descriptionText;
	
	IBOutlet NSProgressIndicator *publishingSpinner;
	IBOutlet NSTextField *statusText;
}

@property (retain) HobokenGracePodcasterAppDelegate *delegate;
@property (retain) WizardStepView *publishToWordpressView;
@property (retain) NSTextField *convertedAudioPath, *titleText, *descriptionText, *statusText;
@property (retain) NSProgressIndicator *publishingSpinner;

- (IBAction)browseAudio:(id)sender;
- (IBAction)publish:(id)sender;

@end

//
//  ConvertAudioController.m
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/25/10.
//  Copyright 2010 RobWilliams. All rights reserved.
//

#import "ConvertAudioController.h"


@implementation ConvertAudioController

@synthesize delegate, convertAudioView, wordpressController, audioFilePath, imageFilePath, 
			audioFileIcon, imageFileIcon, convertingSpinner, statusText;

// initialize default image path
- (void) awakeFromNib
{
	[imageFilePath setStringValue:@"default.jpg"];
	NSImage *image = [[NSImage alloc] initWithContentsOfFile:[imageFilePath stringValue]];
	[imageFileIcon setImage:image];
	[image release];
}

// handler called when user picks file in Open dialog
- (void)openPanelDidEnd:(NSOpenPanel *)op
			 returnCode:(int)returnCode
			contextInfo:(void *)ci
{
	// only proceed if OK button was pressed
	if (returnCode == NSOKButton) {
		NSString *path = [op filename]; // in both cases, path to the file will be added to appropriate NSTextField
		// for images, show the image in the image well
		if ([(NSString*)ci compare:@"image"] == NSOrderedSame) {
			NSImage *image = [[NSImage alloc] initWithContentsOfFile:path];
			[imageFileIcon setImage:image];
			[imageFilePath setStringValue:path];
			[image release];
		}
		// for audio, show a green checkmark as feedback that all is well
		else {
			NSImage *image = [NSImage imageNamed:@"check.tif"];
			[audioFileIcon setImage:image];
			[audioFilePath setStringValue:path];
		}
	}
}

// action associated with audio path Browse... button
- (IBAction)browseAudio:(id)sender
{
	// Create the File Open Dialog class.
	NSOpenPanel *op = [NSOpenPanel openPanel];
	
	// Show sheet for File Open dialog
	[op beginSheetForDirectory:nil
						  file:nil
						 types:[NSArray arrayWithObjects:@"wav", nil] // only allow wave files
				modalForWindow:[convertAudioView window]
				 modalDelegate:self
				didEndSelector:@selector(openPanelDidEnd:returnCode:contextInfo:)
				   contextInfo:@"audio"]; //context info lets common DidEnd handler tell whether image or audio was selected
}

// action associated with image path Browse... button
- (IBAction)browseImage:(id)sender
{
	// Create the File Open Dialog class.
	NSOpenPanel *op = [NSOpenPanel openPanel];
	
	// Show sheet for File Open dialog
	[op beginSheetForDirectory:nil
						  file:nil
						 types:[NSArray arrayWithObjects:@"jpg", @"jpeg", nil] // only allow jpeg files
				modalForWindow:[convertAudioView window]
				 modalDelegate:self
				didEndSelector:@selector(openPanelDidEnd:returnCode:contextInfo:)
				   contextInfo:@"image"]; //context info lets common DidEnd handler tell whether image or audio was selected
}

// action associated with Continue button on convert audio screen
- (IBAction)convert:(id)sender
{
	// if no audio file specified, warn user they need an MP3
	if ([[audioFilePath	stringValue] length] == 0) {
		int iResponse = NSRunAlertPanel(@"No Audio File Specified", 
										@"You did not specify an audio file, so no conversion will take place. If you proceed, you will need to browse to an MP3 file that has already been converted.",
										@"Continue Without Converting", @"Cancel", nil, nil);
		if (iResponse == NSAlertAlternateReturn)
			return;
		else if (iResponse == NSAlertDefaultReturn) {
			[delegate nextView];
			return;
		}
	}
	// if no image file specified, warn user iTunes won't have image for podcast
	else if ([[imageFilePath stringValue] length] == 0) {
		int iResponse = NSRunAlertPanel(@"No Image Specified",
										@"You did not specify an image file. If you proceed, iTunes will not have an image for the podcast.",
										@"Continue Anyway", @"Cancel", nil, nil);
		if (iResponse == NSAlertAlternateReturn)
			return;
	}
	
	// if it gets to this point, proceed with the conversion by creating NSTask for Lame
	NSTask *task;
	task = [[NSTask alloc] init];
	[task setLaunchPath:@"lame"];
	
	// setup arguments for LAME
	NSMutableArray *arguments;
	NSString *string = @"-V8 --vbr-new -q0 -B128 --lowpass 11.6 --resample 22";
	NSArray *chunks = [string componentsSeparatedByString: @" "];
	arguments = [NSMutableArray arrayWithArray:chunks];
	NSString *wavpath = [[NSString alloc] initWithString:[audioFilePath stringValue]];
	NSMutableString *mp3path = [NSMutableString stringWithString:wavpath];
	[mp3path replaceOccurrencesOfString:@".wav"
							 withString:@".mp3"
								options:0
								  range:NSMakeRange(0, [wavpath length])];
	[[wordpressController convertedAudioPath] setStringValue:mp3path];
	if ([[imageFilePath stringValue] length] > 0) {
		[arguments addObject:@"--ti"];
		[arguments addObject:[imageFilePath stringValue]];
	}
	[arguments addObject:wavpath];
	[wavpath release];
	[arguments addObject:mp3path];
	[task setArguments:arguments];
	
	// check to see if file is already converted (meaning an MP3 already exists)
	NSFileManager *fm = [NSFileManager defaultManager];
	// if it does exist, don't bother converting - release and nil task
	if ([fm fileExistsAtPath:mp3path]) {
		[task release];
		task = nil;
	}
	else {
		// show status text and spinner before calling actual conversion process
		[statusText setHidden:NO];
		[statusText setStringValue: @"Converting File. This may take a few minutes depending on the length of the input audio."];
		[convertingSpinner setHidden: NO];
		[convertingSpinner startAnimation:self];
	}
	
	// must make delayed call in order to get UI to refresh while conversion takes place
    [self performSelector:@selector(delayedConvert:) withObject:task afterDelay:0];
}

// performs the actual conversion
- (void) delayedConvert:(id)sender
{
	NSTask* task = sender;
	
	BOOL DontContinue = NO; // specifies whether to stay on this screen. Set to YES if errors occur.
	
	if (task != nil) {
		// setup pipe to capture standard out and standard error of LAME output
		NSPipe *pipe;
		pipe = [NSPipe pipe];
		[task setStandardOutput:pipe];
		[task setStandardError:pipe];
		NSFileHandle *file;
		file = [pipe fileHandleForReading];

		// run task and capture output
		@try {
			[task launch];
			NSData *data;
			data = [file readDataToEndOfFile]; // synchronous call - waits for execution to complete before continuing
			NSString* string = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
			[task waitUntilExit];
			int status = [task terminationStatus];
			if (status != 0) {
				DontContinue = YES;
				// show error
				NSLog(@"%@", string);
				[statusText setStringValue:string];
				[string release];
			} else {
				[statusText setHidden:YES];
			}
		}
		@catch (NSException * e) {
			DontContinue = YES;
			NSLog(@"%@", e);
			[statusText setStringValue:[e description]];
		}
		@finally {
			[convertingSpinner stopAnimation:nil];
			[convertingSpinner setHidden:YES];
			// regardless of outcome, the task should be over now so terminate and force release
			[task terminate];
			[task release];
		}
	}
	
	// after conversion is done, go to next view to continue wizard
	if (!DontContinue)
		[delegate nextView];
}

@end

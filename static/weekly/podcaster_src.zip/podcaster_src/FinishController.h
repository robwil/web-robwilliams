//
//  FinishController.h
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/26/10.
//  Copyright 2010 RobWilliams. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FinishController : NSObject {
}

- (IBAction)quit:(id)sender;

@end

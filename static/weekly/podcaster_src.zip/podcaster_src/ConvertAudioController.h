//
//  ConvertAudioController.h
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/25/10.
//  Copyright 2010 RobWilliams. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WizardStepView.h"
#import "PublishToWordpressController.h"
@class HobokenGracePodcasterAppDelegate;

@interface ConvertAudioController : NSObject {
	IBOutlet HobokenGracePodcasterAppDelegate *delegate;
	IBOutlet WizardStepView *convertAudioView;
	IBOutlet PublishToWordpressController *wordpressController;
	
	IBOutlet NSTextField *audioFilePath;
	IBOutlet NSTextField *imageFilePath;
	IBOutlet NSImageView *audioFileIcon;
	IBOutlet NSImageView *imageFileIcon;
	
	IBOutlet NSProgressIndicator *convertingSpinner;
	IBOutlet NSTextField *statusText;
}

@property (retain) HobokenGracePodcasterAppDelegate *delegate;
@property (retain) WizardStepView *convertAudioView;
@property (retain) PublishToWordpressController *wordpressController;
@property (retain) NSTextField *audioFilePath, *imageFilePath, *statusText;
@property (retain) NSImageView *audioFileIcon, *imageFileIcon;
@property (retain) NSProgressIndicator *convertingSpinner;

- (IBAction)browseAudio:(id)sender;
- (IBAction)browseImage:(id)sender;
- (IBAction)convert:(id)sender;

@end

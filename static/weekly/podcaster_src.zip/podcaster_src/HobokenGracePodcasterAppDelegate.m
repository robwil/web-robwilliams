//
//  HobokenGracePodcasterAppDelegate.m
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "HobokenGracePodcasterAppDelegate.h"

@implementation HobokenGracePodcasterAppDelegate

@synthesize window, currentView;

- (void) awakeFromNib
{
	// make sure current working directory is set to where app was launched from
	[[NSFileManager defaultManager] changeCurrentDirectoryPath:
	 [[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent]];
	//NSRunAlertPanel(@"Current working directory is:", 
	//				[[NSFileManager defaultManager] currentDirectoryPath],
	//				@"OK", nil, nil, nil);
	
	// add initial subview
	NSView *contentView = [[self window] contentView];
	[contentView addSubview:[self currentView]];
}

// setter/mutator method for currentView that handles replacing the sub view and book-keeping of currentView property
- (void)setCurrentView:(WizardStepView*)newView
{
    if (!currentView) {
        currentView = newView;
        return;
    }
    NSView *contentView = [[self window] contentView];
    [[contentView animator] replaceSubview:currentView with:newView];
    currentView = newView;
}

// proceed to next view - called by controller for the view, not directly from button (so not IBAction)
- (void)nextView
{
    if (![[self currentView] nextView]) return;
    [self setCurrentView:[[self currentView] nextView]];
}

// proceed to previous view - tied to Go Back buttons
- (IBAction)previousView:(id)sender
{
    if (![[self currentView] previousView]) return;
    [self setCurrentView:[[self currentView] previousView]];
}

// make window close cause program quit
- (void)windowWillClose:(NSNotification *)aNotification {
	[NSApp terminate:self];
}


@end

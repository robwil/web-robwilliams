//
//  PublishToWordpressController.m
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/25/10.
//  Copyright 2010 RobWilliams. All rights reserved.
//

#import "PublishToWordpressController.h"
#import <QTKit/QTKit.h>

@implementation PublishToWordpressController

@synthesize delegate, publishToWordpressView, convertedAudioPath, titleText,
			descriptionText, publishingSpinner, statusText;

// handler called when user picks file in Open dialog
- (void)openPanelDidEnd:(NSOpenPanel *)op
			 returnCode:(int)returnCode
			contextInfo:(void *)ci
{
	// only proceed if OK button was pressed
	if (returnCode == NSOKButton) {
		NSString *path = [op filename]; // path to the file will be added to NSTextField
		[convertedAudioPath setStringValue:path];
	}
}

// action associated with audio path Browse... button
- (IBAction)browseAudio:(id)sender
{
	// Create the File Open Dialog class.
	NSOpenPanel *op = [NSOpenPanel openPanel];
	
	// Show sheet for File Open dialog
	[op beginSheetForDirectory:nil
						  file:nil
						 types:[NSArray arrayWithObjects:@"mp3", nil] // only allow mp3 files
				modalForWindow:[publishToWordpressView window]
				 modalDelegate:self
				didEndSelector:@selector(openPanelDidEnd:returnCode:contextInfo:)
				   contextInfo:nil];
}

- (IBAction)publish:(id)sender
{
	// if not all fields filled in, we can't continue
	if ([[convertedAudioPath stringValue] length] == 0 || [[titleText stringValue] length] == 0 || [[descriptionText stringValue] length] == 0) {
		NSRunAlertPanel(@"All Fields Are Required", 
										@"You did not fill in all fields. They are all required for posting to Wordpress.",
										@"OK", nil, nil, nil);
		
		return;
	}
	
	// if it gets to this point, proceed with the publishing by creating NSTask for PHP
	NSTask *task;
	task = [[NSTask alloc] init];
	[task setLaunchPath:@"/usr/bin/php"];
	
	// need to get some data about MP3 file
	// 1. file size
	NSError *error;
	NSFileManager *fm = [NSFileManager defaultManager];
	NSDictionary *fileInfo = [fm attributesOfItemAtPath:[convertedAudioPath stringValue] error:&error];
	NSString *fileSize = [NSString stringWithFormat:@"%d", [fileInfo objectForKey:NSFileSize], nil];
	// 2. MP3 duration
	QTMovie *song = [QTMovie movieWithFile:[convertedAudioPath stringValue] error:&error];
	long seconds = [song duration].timeValue / [song duration].timeScale;
	long hours = seconds / 3600;
	long minutes = seconds / 60 % 60;
	seconds = seconds % 60;
	NSString* duration = [NSString stringWithFormat:@"%01d:%02d:%2d", hours, minutes, seconds, nil];
	
	// setup arguments for PHP
	NSMutableArray *arguments;
	arguments = [NSMutableArray arrayWithObject:@"xmlrpc.php"];
	[arguments addObject:@"-f"];
	[arguments addObject:[convertedAudioPath stringValue]];
	[arguments addObject:@"-t"];
	[arguments addObject:[titleText stringValue]];
	[arguments addObject:@"-d"];
	[arguments addObject:[descriptionText stringValue]];
	[arguments addObject:@"-u"];
	[arguments addObject:duration];
	[arguments addObject:@"-s"];
	[arguments addObject:fileSize];
	[task setArguments:arguments];
	
	// show status text and spinner before calling actual conversion process
	[statusText setHidden:NO];
	[statusText setStringValue: @"Publishing post. This may take a few minutes depending on your internet connection speed."];
	[publishingSpinner setHidden: NO];
	[publishingSpinner startAnimation:self];
	
	// must make delayed call in order to get UI to refresh while conversion takes place
    [self performSelector:@selector(delayedPublish:) withObject:task afterDelay:0];
}

// performs the actual publishing
- (void) delayedPublish:(id)sender
{
	NSTask* task = sender;
	
	BOOL DontContinue = NO; // specifies whether to stay on this screen. Set to YES if errors occur.
	
	if (task != nil) {
		// setup pipe to capture standard out and standard error of PHP script output
		NSPipe *pipe;
		pipe = [NSPipe pipe];
		[task setStandardOutput:pipe];
		[task setStandardError:pipe];
		NSFileHandle *file;
		file = [pipe fileHandleForReading];
		
		// run task and capture output
		@try {
			[task launch];
			NSData *data;
			data = [file readDataToEndOfFile]; // synchronous call - waits for execution to complete before continuing
			NSString* string = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
			[task waitUntilExit];
			int status = [task terminationStatus];
			if (status != 0) {
				DontContinue = YES;
				// show error
				NSLog(@"%@", string);
				[statusText setStringValue:string];
			} else {
				[statusText setHidden:YES];
			}
			[string release];
		}
		@catch (NSException * e) {
			DontContinue = YES;
			NSLog(@"%@", e);
			[statusText setStringValue:[e description]];
		}
		@finally {
			[publishingSpinner stopAnimation:nil];
			[publishingSpinner setHidden:YES];
			// regardless of outcome, the task should be over now so terminate and force release
			[task terminate];
			[task release];
		}
	}
	
	// after publishing is done, go to next view to finish wizard
	if (!DontContinue)
		[delegate nextView];
}

@end

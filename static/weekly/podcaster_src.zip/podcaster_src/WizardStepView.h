//
//  WizardStepView.h
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WizardStepView : NSView {
	IBOutlet WizardStepView *previousView;
	IBOutlet WizardStepView *nextView;
	
	IBOutlet NSButton *previousButton;
	IBOutlet NSButton *nextButton;
}

@property (retain) WizardStepView *previousView, *nextView;

@end

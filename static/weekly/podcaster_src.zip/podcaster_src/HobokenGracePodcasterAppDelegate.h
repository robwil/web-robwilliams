//
//  HobokenGracePodcasterAppDelegate.h
//  HobokenGracePodcaster
//
//  Created by Rob Williams on 8/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "WizardStepView.h"

@interface HobokenGracePodcasterAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
	IBOutlet WizardStepView *currentView;
}

@property (assign) IBOutlet NSWindow *window;
@property (retain) WizardStepView *currentView;

- (void) nextView;
- (IBAction) previousView: (id)sender;

@end

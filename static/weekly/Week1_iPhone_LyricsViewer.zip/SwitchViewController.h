//
//  SwitchViewController.h
//  Lyrics Viewer
//
//  Created by Rob Williams on 8/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FormViewController;
@class LyricsViewController;

@interface SwitchViewController : UIViewController {
	FormViewController *formViewController;
	LyricsViewController *lyricsViewController;
}

@property (nonatomic, retain) FormViewController *formViewController;
@property (nonatomic, retain) LyricsViewController *lyricsViewController;

-(IBAction)switchViews:(id)sender;

@end

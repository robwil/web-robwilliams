//
//  LyricsViewController.h
//  Lyrics Viewer
//
//  Created by Rob Williams on 8/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SwitchViewController.h"

@interface LyricsViewController : UIViewController {
	SwitchViewController *switchView;
	UILabel *artist;
	UILabel *song;
	UIWebView *lyrics;
}

@property (nonatomic, retain) SwitchViewController *switchView;
@property (nonatomic, retain) IBOutlet UILabel *artist;
@property (nonatomic, retain) IBOutlet UILabel *song;
@property (nonatomic, retain) IBOutlet UIWebView *lyrics;

- (IBAction)back:(id)sender;

@end

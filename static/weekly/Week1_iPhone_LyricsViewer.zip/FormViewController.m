//
//  FormViewController.m
//  Lyrics Viewer
//
//  Created by Rob Williams on 8/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "FormViewController.h"
#import "HyperParser.h"

@implementation FormViewController
@synthesize switchView;
@synthesize artist;
@synthesize song;
@synthesize lyrics;

- (IBAction) textFieldDone: (id)sender {
	[sender resignFirstResponder];
}


- (IBAction) fetchLyrics: (id)sender {
	// get artist and song in format for LyricWiki.. e.g. Miley Cyrus becomes Miley_Cyrus
	NSString * artist_str = [[[artist text] componentsSeparatedByCharactersInSet: [NSCharacterSet whitespaceCharacterSet]] componentsJoinedByString: @"_"];
	NSString * song_str = [[[song text] componentsSeparatedByCharactersInSet: [NSCharacterSet whitespaceCharacterSet]] componentsJoinedByString: @"_"];
	NSMutableString *url = [NSString stringWithFormat:@"http://lyricwiki.org/%@:%@",artist_str,song_str];
	
	NSString *htmlData =  [[NSString alloc] initWithContentsOfURL:[NSURL URLWithString:url]
													encoding:NSUTF8StringEncoding error:nil];
	
	if ([htmlData length] == 0) self.lyrics = @"There was a problem loading the lyrics page. Check the artist and song name.";
	else {
		NSString *tmp;
		HyperInput * input = [[HyperInput alloc] initWithString: htmlData];
		while ([input hasNext]) {
			tmp = [input substringToSuffix:@"<"];
			tmp = [input substringFromPrefix:@"div class='lyricbox'" toSuffix:@"<p>"];
			if ([tmp length] > 0) {
				NSLog(tmp);
				self.lyrics = [tmp stringByReplacingOccurrencesOfString:@">" withString:@"" options:0 range:NSMakeRange(0, 3)];
				break;
			}
		}
		[input release];
	}
	
	[switchView switchViews:sender];

	[htmlData release];

}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[switchView release];
	[artist release];
	[song release];
    [super dealloc];
}


@end

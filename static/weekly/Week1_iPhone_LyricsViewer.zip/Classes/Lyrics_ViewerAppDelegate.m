//
//  Lyrics_ViewerAppDelegate.m
//  Lyrics Viewer
//
//  Created by Rob Williams on 8/24/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "Lyrics_ViewerAppDelegate.h"
#import "SwitchViewController.h"

@implementation Lyrics_ViewerAppDelegate

@synthesize window;
@synthesize switchViewController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    [window addSubview:switchViewController.view];
    [window makeKeyAndVisible];
}

- (void)dealloc {
    [window release];
	[switchViewController release];
    [super dealloc];
}


@end

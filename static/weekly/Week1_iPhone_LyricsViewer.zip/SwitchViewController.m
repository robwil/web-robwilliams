//
//  SwitchViewController.m
//  Lyrics Viewer
//
//  Created by Rob Williams on 8/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SwitchViewController.h"
#import "FormViewController.h"
#import "LyricsViewController.h"


@implementation SwitchViewController
@synthesize formViewController;
@synthesize lyricsViewController;


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	FormViewController *formController = [[FormViewController alloc] initWithNibName:@"FormView" bundle:nil];
	self.formViewController = formController;
	[formController setSwitchView:self];
	[self.view insertSubview:formController.view atIndex:0];
	[formController release];
}

- (IBAction)switchViews:(id)sender {
	if (self.lyricsViewController == nil) {
		LyricsViewController *lyricsController = [[LyricsViewController alloc] initWithNibName:@"LyricsView" bundle:nil];
		self.lyricsViewController = lyricsController;
		[lyricsController setSwitchView: self];
		[lyricsController release];
	}
	
	[UIView beginAnimations:@"View Flip" context: nil];
	[UIView setAnimationDuration:1.25];
	[UIView setAnimationCurve: UIViewAnimationCurveEaseInOut];
	
	if (self.formViewController.view.superview == nil) {
		[UIView setAnimationTransition: UIViewAnimationTransitionFlipFromRight forView:self.view cache:YES];
		[lyricsViewController viewWillDisappear:YES];
		[formViewController viewWillAppear:YES];
		[lyricsViewController.view removeFromSuperview];
		[self.view insertSubview:formViewController.view atIndex:0];
		[lyricsViewController viewDidDisappear:YES];
		[formViewController viewDidAppear:YES];
	} else {
		[UIView setAnimationTransition: UIViewAnimationTransitionFlipFromLeft forView:self.view cache:YES];
		[formViewController viewWillDisappear:YES];
		[lyricsViewController viewWillAppear:YES];
		[formViewController.view removeFromSuperview];
		[self.view insertSubview:lyricsViewController.view atIndex:0];
		[formViewController viewDidDisappear:YES];
		[lyricsViewController viewDidAppear:YES];
		
		NSString *lyrics = [formViewController lyrics];
		[lyricsViewController.lyrics loadHTMLString:lyrics baseURL:[NSURL URLWithString:@"http://lyricwiki.org/"]];
		[lyricsViewController.song setText:[formViewController.song text]];
		[lyricsViewController.artist setText:[formViewController.artist text]];
	}
	[UIView commitAnimations];
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[formViewController release];
	[lyricsViewController release];
    [super dealloc];
}


@end

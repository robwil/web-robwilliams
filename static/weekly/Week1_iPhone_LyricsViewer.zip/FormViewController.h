//
//  FormViewController.h
//  Lyrics Viewer
//
//  Created by Rob Williams on 8/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SwitchViewController.h"

@interface FormViewController : UIViewController {
	SwitchViewController *switchView;
	UITextField *artist;
	UITextField *song;
	NSString *lyrics;
}

@property (nonatomic, retain) SwitchViewController *switchView;
@property (nonatomic, retain) IBOutlet UITextField *artist;
@property (nonatomic, retain) IBOutlet UITextField *song;
@property (nonatomic, retain) NSString *lyrics;

- (IBAction)textFieldDone:(id)sender;
- (IBAction)fetchLyrics:(id)sender;

@end

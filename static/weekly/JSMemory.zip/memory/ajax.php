<?php
require("../wp-load.php");
global $current_user;
get_currentuserinfo();

if (current_user_can(edit_posts)) {
	
	$mode = $_POST['mode'];
	if ($mode == "get") {
		$active = $_POST['active'];
		$deck = get_user_meta($current_user->ID, "memoryDeck" . $active, true);
		echo $deck;
	}
	else if ($mode == "getdecks") {
		$decks = get_user_meta($current_user->ID, "memoryDecks", true);
		echo $decks;
	}
	else if ($mode == "save") {
		$deck = $_POST['deck'];
		$active = $_POST['active'];
		// handle situation where the same exact deck is already saved (happens quite often)
		$existingDeck = get_user_meta($current_user->ID, "memoryDeck" . $active, true);
		if ($existingDeck == stripslashes($deck)) {
			$success = true;
		} else {
			// save the deck to the DB
			$success = update_user_meta($current_user->ID, "memoryDeck" . $active, $deck);
		}
		if ($success == true) {
			echo "SUCCESS";
		} else {
			echo "FAIL";
		}
	}
	
} // end if wrapper for security/login
else {
	echo "LOGIN_ERROR";	
}
?>
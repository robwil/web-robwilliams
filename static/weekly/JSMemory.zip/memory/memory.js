/*
 * Memory-JS by Rob Williams
 * Developed in 2012
 * More info available here: http://robwilliams.me/2012/03/flashcard-js-app/
 */

// Add remove() function to Array.prototype
Array.prototype.remove = function(value)
	{
		i = this.indexOf(value);
		if (i != -1) {
			this.splice(i, 1);
		}
	};
	
// Global variables
decks = {};
active = 0;
deck = {};
currentSlide = null;
showingQuestion = true;
editing = false;
deckChanging = false;

$(document).ready(function()
{
	// The DOM (document object model) is constructed
	// We will initialize and run code now.
	
	//
	// Button Event Handlers
	//
	newSlideEventHandler = function()
		{
			// clear text that may be in the New Slide form
			$('input#questionText').val('');
			$('textarea#answerText').val('');
			editing = false;
			
			// show the New Slide form, if it was hidden
			$('div#neweditslide').show('slow');
			
			// hide main form so they don't try to do other stuff
			hideMainControls();
		};
	editSlideEventHandler = function()
		{
			// populate text for the current slide
			$('input#questionText').val(currentSlide.question);
			$('textarea#answerText').val(currentSlide.answer);
			editing = true;
			
			// show the Edit Slide form, if it was hidden
			$('div#neweditslide').show('slow');
			
			// hide main form so they don't try to do other stuff.
			// If they manually show it with Firebug and do stuff, it's their own fault.
			hideMainControls();
		};
	saveSlideEventHandler = function()
		{
			// get the values they entered, and use to construct a new slide object
			question = $('input#questionText').val();
			answer = $('textarea#answerText').val();
			slide = { 'isMemorized': false, 'weight': 0, 'question': question, 'answer': answer };
			if (editing) {
				// Editing means the currentSlide was updated.
				// So first delete currentSlide from wherever it came from.
				deck.notMemorizedSlides.remove(currentSlide);
				deck.finishedSlides.remove(currentSlide);
				deck.remainingSlides.remove(currentSlide);
				
				// copy details from original slide into new slide object
				slide.isMemorized = currentSlide.isMemorized;
				slide.weight = currentSlide.weight;
				
				// add it to the appropriate deck
				if (slide.isMemorized) {
					deck.remainingSlides.push(slide);
				} else {
					deck.notMemorizedSlides.push(slide);
				}
			} else {
				// If new slide, just add it to not memorized section
				deck.notMemorizedSlides.push(slide);
			}
			
			// Force the current slide to refresh; possibly to same slide but maybe not
			currentSlide = null;
			handleNewSlides();
			
			// hide the New/Edit slide form now that we're done with it
			$('div#neweditslide').hide('slow');
			
			// show main form again
			showMainControls();
		};
	showDeckEventHandler = function()
		{
			//populate HTML of div here
			deckHtml = "<strong>Not Memorized Slides:</strong><br/><br/>";
			deckHtml += "<table border='1'><tr><th>Question</th><th>Answer</th><th>Weight</th>";
			for (var i = 0; i < deck.notMemorizedSlides.length; i++) {
				iSlide = deck.notMemorizedSlides[i];
				deckHtml += "<tr><td>" + iSlide.question + "</td><td class='answer'>" + iSlide.answer + "</td><td>" + iSlide.weight + "</td></tr>";
			}
			deckHtml += "</table>";
			
			deckHtml += "<br/><br/><strong>Remaining Slides:</strong><br/><br/>";
			deckHtml += "<table border='1'><tr><th>Question</th><th>Answer</th><th>Weight</th>";
			for (var i = 0; i < deck.remainingSlides.length; i++) {
				iSlide = deck.remainingSlides[i];
				deckHtml += "<tr><td>" + iSlide.question + "</td><td class='answer'>" + iSlide.answer + "</td><td>" + iSlide.weight + "</td></tr>";
			}
			deckHtml += "</table>";
			
			deckHtml += "<br/><br/><strong>Finished Slides:</strong><br/><br/>";
			deckHtml += "<table border='1'><tr><th>Question</th><th>Answer</th><th>Weight</th>";
			for (var i = 0; i < deck.finishedSlides.length; i++) {
				iSlide = deck.finishedSlides[i];
				deckHtml += "<tr><td>" + iSlide.question + "</td><td class='answer'>" + iSlide.answer + "</td><td>" + iSlide.weight + "</td></tr>";
			}
			deckHtml += "</table>";
			
			// show the Deck View div
			$('div#deckview').html(deckHtml + '<br/><br/><button tabindex="0" id="close" style="width:100%">Close</button>');
			$('div#deckview').show('slow');
			$('button#close').click(hideDeckView);
			
			// hide main form so they don't try to do other stuff.
			// If they manually show it with Firebug and do stuff, it's their own fault.
			hideMainControls();
		};
	hideDeckView = function()
		{
			// hide the Deck View div now that we're done with it
			$('div#deckview').hide('slow');
			
			// show main form again
			showMainControls();
		};
	upEventHandler = function()
		{
			// Increase the weight of a card when the user presses "up" button
			currentSlide.weight++;
			updateScreenText();
		};
	downEventHandler = function()
		{
			// Decrease the weight of a card when the user presses "down" button
			currentSlide.weight--;
			updateScreenText();
		};
	
	//
	// Helper functions
	//
	hideMainControls = function()
		{
			// hide main form and slide view so they don't try to do other stuff
			// this is used during slide editing/creation and deck viewing
			$('div#deckchoose').hide('slow');
			$('div#topstatus').hide('slow');
			$('div#topbuttons').hide('slow');
			$('div#main').hide('slow');
			$('div#bottomstatus').hide('slow');
			$('div#bottombuttons').hide('slow');
		};
	showMainControls = function()
		{
			// hide main form and slide view so they don't try to do other stuff
			// this is used during slide editing/creation and deck viewing
			$('div#deckchoose').show('slow');
			$('div#topstatus').show('slow');
			$('div#topbuttons').show('slow');
			$('div#main').show('slow');
			$('div#bottomstatus').show('slow');
			$('div#bottombuttons').show('slow');
		};
	updateScreenText = function()
		{
			// Calculate the remaining, finished, and not memorized counts
			// And then display them in #topstatus
			remainingCount = deck.remainingSlides.length;
			finishedCount = deck.finishedSlides.length;
			notMemorizedCount = deck.notMemorizedSlides.length;
			statusText = "<p>Finished: " + finishedCount + "</p>";
			statusText += "<p>Remaining: " + remainingCount + "</p>";
			statusText += "<p>Not Memorized: " + notMemorizedCount + "</p>";
			$('div#topstatus').html(statusText);
			
			// handle situation where there is no current slide selected.
			// This happens when they have exhausted the deck.
			if (currentSlide == null) {
				$('div#main').html("No slide available. Press 'Reset' to start from the beginning.");
				$('div#bottomstatus').html(''); // no bottom status for a non-existant card
			}
			else {
				// Display memorization status, weight in #bottomstatus
				statusText = "<p>Weight: " + currentSlide.weight + "</p>";
				if (currentSlide.isMemorized) {
					statusText += "<p>Memorized</p>";
					$('div#main').css('color', '#90EE90');
				} else {
					statusText += "<p>Not Memorized</p>";
					$('div#main').css('color', '#FFA07A');
				}
				$('div#bottomstatus').html(statusText);
				
				// Show the current slide in main area
				if (showingQuestion) {
					$('div#main').html(currentSlide.question);
				} else {
					$('div#main').html(currentSlide.answer);
				}
			}
		};
	toggleMemorized = function()
		{
			// If slide was memorized, toggling means it becomes Not Memorized.
			// As a result, take it from Remaining Slides and put it to Not Memorized slides.
			if (currentSlide.isMemorized)
            {
                deck.remainingSlides.remove(currentSlide);
                deck.notMemorizedSlides.push(currentSlide);
            }
			// If slide was not memorized, toggling means it becomes Memorized.
			// As a result, take it from Not Memorized Slides and put it to Remaining slides.
            else
            {
                deck.notMemorizedSlides.remove(currentSlide);
                deck.remainingSlides.push(currentSlide);
            }
			
			// Actually toggle the memorized flag, and handle new slides to re-sort slides.
            currentSlide.isMemorized = !currentSlide.isMemorized;
			handleNewSlides();
		};
	showNextAvailableSlide = function()
		{
			// Regardless of what situation we are in, abandon the current slide and
			// retrieve the next available slide, displaying it on the screen.
			
			// Resetting showingQuestion ensures the new slide will show the question side.
			showingQuestion = true;
			
			// Set currentSlide variable to next available slide
			// First get from Not Memorized pile, then from Remaining pile.
            if (deck.notMemorizedSlides.length > 0)
            {
                currentSlide = deck.notMemorizedSlides[0];
            }
            else if (deck.remainingSlides.length > 0)
            {
                currentSlide = deck.remainingSlides[0];
            }
			// Otherwise, there are no remaining slides, so set currentSlide to null.
            else
            {
                currentSlide = null;
            }
			
			// Force refresh of screen to draw the new slide
			updateScreenText();
		};
	advanceSlide = function()
		{
			// Advance Slide means to proceed from Question->Answer of the current slide
			// andthen from Answer->new slide's Question side.
		
			// handle case where it is still showing question. Just flip card
			if (showingQuestion) {
				$('div#main').html(currentSlide.answer);
				showingQuestion = false;
			}
			// otherwise, handle answer case, where we need to go to next slide
			else {
				// handle normal case, where card is memorized
				if (currentSlide.isMemorized)
				{
					// Add slide to Finished deck.
					deck.finishedSlides.push(currentSlide);
	
					// Remove slide from wherever it came from. Could be either of the two piles, so do both.
					deck.remainingSlides.remove(currentSlide);
					deck.notMemorizedSlides.remove(currentSlide);
				}
	
				// If not memorized, don't even move it
				//
	
				// Get next available card and show it to the screen.
				showingQuestion = true;
				showNextAvailableSlide();
				
				// The design decision was to automatically save after each card is finished (advanced twice).
				// This basically means that the system will save when it matters, ridding the user of the need
				// to manually save that often.
				saveSlides();
			}
		};
	deleteCurrentSlide = function()
		{
			// Delete the current slide by removing it from all possible piles
			deck.remainingSlides.remove(currentSlide);
            deck.notMemorizedSlides.remove(currentSlide);
            deck.finishedSlides.remove(currentSlide);
			
			// Then show the next available slide
            showNextAvailableSlide();
		};
	strcmp = function(str1, str2) {
		// http://kevin.vanzonneveld.net
		// +   original by: Waldo Malqui Silva
		// +      input by: Steve Hilder
		// +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
		// +    revised by: gorthaur
		// *     example 1: strcmp( 'waldo', 'owald' );
		// *     returns 1: 1
		// *     example 2: strcmp( 'owald', 'waldo' );
		// *     returns 2: -1
	
		return ( ( str1 == str2 ) ? 0 : ( ( str1 > str2 ) ? 1 : -1 ) );
	};
	slideSortFunc = function(a, b) {
			if (a.weight == b.weight) {
				// If the weights are equal, compare the strings of the question
				//return strcmp(a.question, b.question);
				// commented out for now because I think it might be better random
			}
			return b.weight - a.weight;
		};
	handleNewSlides = function()
        {
            // Sort the piles by weight to handle latest additions
            deck.remainingSlides.sort(slideSortFunc);
			deck.finishedSlides.sort(slideSortFunc);
			deck.notMemorizedSlides.sort(slideSortFunc);
			
            // If no slide is currently being displayed, but we have stuff to display, show the next available slide.
			// This is most likely to be the case when first creating slides, or after Reset.
            if (currentSlide == null && (deck.remainingSlides.length + deck.notMemorizedSlides.length) > 0) {
                showNextAvailableSlide();
            }
            
			// Force screen refresh, since it doesn't happen automatically
            updateScreenText();
        };
	resetPiles = function()
		{
			// Resetting the piles puts all finished slides where they belong, based on whether they're memorized or not.
			
			// Loop backward so we can delete from finishedSlides pile as we go.
			for (i = deck.finishedSlides.length - 1; i >= 0; i--)
            {
                slide = deck.finishedSlides[i];
                if (slide != null && slide.isMemorized)
                {
                    deck.remainingSlides.push(slide);
                }
                else
                {
                    deck.notMemorizedSlides.push(slide);
                }

				// equivalent to deck.finishedSlides.removeAtIndex(i) which JS doesn't have
                deck.finishedSlides.splice(i, 1);
            }

			// Handling new slides to ensure they're re-sorted and that the next available slide is shown.
            handleNewSlides();
		};
	handleDeckChange = function()
		{
			// Handle new deck being selected.
			
			// Save old deck.
			// And by setting the deckChanging = true, it will make the saveSlides callback load the new slides.
			deckChanging = true;
			saveSlides();
			
		};
	loadDecks = function()
		{
			// Load the decks from the database by sending an AJAX call to a backend PHP script.
			// It responds with a single JSON string, which is de-serialized by the jquery.json library.
			
			// Just to be clear, this loads the NAMES of the decks, and their internal IDs. It does not
			// load any of the slides. That is done by loadSlides(), and it only loads the currently active deck.
			$.post("ajax.php", { mode: "getdecks" },
				function(data) {
					if (data == "LOGIN_ERROR") { // The PHP script returns this string if the user wans't logged in to Wordpress.
						alert("You are not logged in. Nothing you do will be saved!");
					} else {
						decks = $.secureEvalJSON(data); // de-serialization
						// Construct the valid #deckchoose div
						newhtml = "Choose your deck: <select name='deckchoice' id='deckchoice'>";
						active = decks['active'];
						for (aDeck in decks) {
							if (aDeck != "active") {
								if (aDeck == active) {
									newhtml += "<option selected='selected' value='" + aDeck + "'>" + decks[aDeck] + "</option>";
								} else {
									newhtml += "<option value='" + aDeck + "'>" + decks[aDeck] + "</option>";
								}
							}
						}
						newhtml += "</select>";
						$('div#deckchoose').html(newhtml);
						
						// Map the event handler of the newly created select
						$('select#deckchoice').change(handleDeckChange);
						
						// now load the slides of the active deck
						loadSlides();
					}
				});
		};
	loadSlides = function()
		{
			// Load the slides of the active deck from the database by sending an AJAX call to a backend PHP script.
			// It responds with a single JSON string, which is de-serialized by the jquery.json library.
			$.post("ajax.php", { "mode": "get", "active": active },
				function(data) {
					if (data == "LOGIN_ERROR") { // The PHP script returns this string if the user wans't logged in to Wordpress.
						alert("You are not logged in. Nothing you do will be saved!");
					} else {
						deck = $.secureEvalJSON(data); // de-serialization
						handleNewSlides();
					}
				});
		};
	saveSlides = function()
		{
			// Save the slides to the database by serializing the deck to JSON and sending via AJAX to the PHP script.
			// It will reply with the string "SUCCESS" if all went well.
			// This also prepends a success of fail message to the div#savelog.
			$.post("ajax.php", { 'mode': "save", 'deck': $.toJSON(deck), 'active': active },
				function(data) {
					var d = new Date();
					if (data == "SUCCESS") {
						$('div#savelog').prepend("Successful save @ " + d.toString('yyyy-MM-dd mm:hh:ss') + "<br/>");
						// During a deck change, this callback is responsible for loading the next slides.
						// This is so that we don't load a new deck until the old one has been successfully saved.
						if (deckChanging == true) {
							deckChanging = false;
							// Update 'active' variable
							active = $("select#deckchoice option:selected").val();
							// Delete currentSlide so we start fresh
							currentSlide = null;
							// And finally load the new slides
							loadSlides();
						}
					} else {
						$('div#savelog').prepend("<font color='red'>FAILED</font> save @ " + d.toString('yyyy-MM-dd mm:hh:ss') + "<br/>");
						// During a deck change, a failed save of the old deck cancels the operation.
						if (deckChanging == true) {
							deckChanging = false;
							$('div#savelog').prepend("Cannot change decks, since old one failed to save. <br/>");
						}
					}
				});
		};
		
	// Map the mouse clicks to the appropriate event handlers
	$('button#new').click(newSlideEventHandler);
	$('button#edit').click(editSlideEventHandler);
	$('button#delete').click(deleteCurrentSlide);
	$('button#reset').click(resetPiles);
	$('button#showDeck').click(showDeckEventHandler);
	$('button#saveSlide').click(saveSlideEventHandler);
	$('button#up').click(upEventHandler);
	$('button#down').click(downEventHandler);
	$('button#memorizedToggle').click(toggleMemorized);
	$('button#next').click(advanceSlide);
	$('button#save').click(saveSlides);
	
	// The actual init code to run
	// Start off by loading decks from DB
	loadDecks();
});
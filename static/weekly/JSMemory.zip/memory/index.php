<?php
require("../wp-load.php");
global $current_user;
get_currentuserinfo();

if (current_user_can(edit_posts)) {
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>VerseMemory</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="jquery.json-2.3.min.js"></script>
<script type="text/javascript" src="memory.js"></script>
</head>

<body>
	<div id="container">
	
		<div id="deckview">
		</div>
		
    	<div id="neweditslide">
        	<table>
            <tr><td>Question:</td><td><input type="text" size="40" id="questionText" /></td></tr>
            <tr><td>Answer:</td><td><textarea cols="40" rows="10" id="answerText"></textarea></td></tr>
            <tr><td></td><td align="left"><button tabindex="0" id="saveSlide" style="width:100%">Save Slide</button></td></tr>
            </table>
        </div>
		
		<div id="deckchoose">
			<img src="loading.gif">
		</div> <!-- end #deckchoose -->
        
    	<div id="topstatus">
        	<p>Remaining: 0</p>
            <p>Finished: 0</p>
            <p>Not Memorized: 0</p>
        </div> <!-- end #topstatus -->
        
        <div id="topbuttons">
            <button id="new">New</button>
            <button id="edit">Edit</button>
            <button id="delete">Delete</button>
            <button id="reset">Reset</button>
			 <button id="showDeck">Show Deck</button>
        </div> <!-- end #topbuttons -->
        
        <div id="main">
        	<img src="loading.gif">
        </div> <!-- end #main -->
        
        <div id="bottomstatus">
        	<p>Weight: 0</p>
            <p>Not Memorized</p>
        </div>
        
        <div id="bottombuttons">
        	<button id="up">Up</button>
            <button id="down">Down</button>
            <button id="memorizedToggle">M</button>
            <button id="next">Next</button>
            <br/>
            <button id="save">Save</button>
        </div> <!-- end #bottombuttons -->
        <div id="savelog">
        	
        </div>
    </div> <!-- end #container -->
</body>
</html>

<?php

} else {
	header("location: http://YOURSITEHERE.com/wp-login.php?redirect_to=http%3A%2F%YOURSITEHERE.com%2Fmemory%2F");
}

?>
package com.robwilliams.mibox.exceptions;

public class IntegrityError extends Exception {

	public IntegrityError(String message) {
		super(message);
	}

	private static final long serialVersionUID = -4130992815214746669L;

}

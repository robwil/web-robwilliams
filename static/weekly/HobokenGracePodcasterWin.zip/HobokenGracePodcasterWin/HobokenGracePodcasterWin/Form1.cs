﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using CookComputing.XmlRpc;
using System.IO;
using System.Windows.Controls;
using System.Windows.Media;

namespace HobokenGracePodcasterWin
{
    public partial class Form1 : Form
    {
        private const String username = "admin";
        private const String password = "password";

        public Form1()
        {
            InitializeComponent();
            txtImage.Text = "default.jpg";
            picAlbum.Load("default.jpg");
        }

        private void btnBrowseAudio_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Wave Audio File|*.wav|MP3 Audio File|*.mp3";
            if (dialog.ShowDialog() != DialogResult.Cancel)
                txtAudio.Text = dialog.FileName;
            txtTitle.Focus();
        }

        private void btnBrowseImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() != DialogResult.Cancel)
                txtImage.Text = dialog.FileName;
            picAlbum.Load(txtImage.Text);
            txtTitle.Focus();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            // validate fields
            if (txtAudio.Text.Length <= 0)
            {
                MessageBox.Show("You must browse to an input audio file.", "Missing Input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (txtTitle.Text.Length <= 0)
            {
                MessageBox.Show("You must provide a title.", "Missing Input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (txtDescription.Text.Length <= 0)
            {
                MessageBox.Show("You must provide a description.", "Missing Input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            progressBar.Value = 5;

            // make sure status starts cleared
            txtStatus.Text = "";
            // get filename in string for easy use
            String filename = txtAudio.Text;
            // if input file is not MP3, must first convert to MP3
            if (!filename.EndsWith("mp3"))
            {
                Process process = new Process();
                // setup call to lame.exe, specifying proper arguments
                process.StartInfo.FileName = "lame.exe";
                String arguments = "-V8 --vbr-new -q0 -B128 --lowpass 11.6 --resample 22 ";
                if (txtImage.Text.Length != 0)
                    arguments += "--ti " + txtImage.Text + " ";
                arguments += filename + " ";
                filename = filename.Replace(".wav", ".mp3");
                arguments += filename;
                process.StartInfo.Arguments = arguments;
                // run the lame process
                try
                {
                    process.Start();
                    appendToStatus("Starting conversion from WAV to MP3...");
                    //appendToStatus(arguments );
                    process.WaitForExit();
                    if (process.ExitCode != 0)
                    {
                        MessageBox.Show("Non-zero exit code: " + process.ExitCode + ". Something went wrong!", "Error converting file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    appendToStatus("Conversion done!");
                    process.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error converting file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            }
            progressBar.Value = 40;

            // at this point, there is an MP3 file (either original or converted), so proceed with upload
            byte[] fileContents = ReadFile(filename);
            IWordpressRPC proxy = XmlRpcProxyGen.Create<IWordpressRPC>();
            FileValue file;
            file.name = Path.GetFileName(filename);
            file.type = "audio/mpeg";
            file.bits = fileContents;
            file.overwrite = false;
            appendToStatus(Environment.NewLine + "Uploading " + filename + ". This will take a few minutes depending on the file's size.");
            FileReturnValue ret = proxy.uploadFile(1, username, password, file);
            appendToStatus("Done uploading. File is at URL " + ret.url);
            progressBar.Value = 80;

            // create the actual blog post
            // BUT first, we need info about the mp3 file (duration and file size)
            MediaPlayer player = new MediaPlayer();
            Uri path = new Uri(filename);
            player.Open(path);
            TimeSpan maxWaitTime = TimeSpan.FromSeconds(10);
            DateTime end = DateTime.Now + maxWaitTime;
            String fileTime = "";
            while (DateTime.Now < end)
            {
                System.Threading.Thread.Sleep(100);
                if (player.NaturalDuration.HasTimeSpan)
                {
                    int hours = player.NaturalDuration.TimeSpan.Hours;
                    int minutes = player.NaturalDuration.TimeSpan.Minutes;
                    int seconds = player.NaturalDuration.TimeSpan.Seconds;
                    fileTime = String.Format("{0:0}:{1:00}:{2:00}", hours, minutes, seconds);
                    //appendToStatus("Duration is " + fileTime );
                    break;
                }
            }
            // return error if duration could not be calculated
            if (fileTime.Equals(""))
            {
                MessageBox.Show("Failed to get the duration of the audio file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // find file length
            int fileLength = fileContents.Length;
            //appendToStatus("Length is " + fileLength );
            progressBar.Value = 85;

            // NOW, ready to make Wordpress post
            String enclosure = ret.url + Environment.NewLine + fileLength + Environment.NewLine + "audio/mpeg" + Environment.NewLine;
            enclosure += "a:1:{s:8:\"duration\";s:7:\"" + fileTime + "\";}";
            //appendToStatus("Enclosure is " + enclosure );
            PostValue post = new PostValue();
            post.title = txtTitle.Text;
            post.description = txtDescription.Text;
            String[] categories = { "Podcast" };
            FieldType field;
            field.key = "enclosure";
            field.value = enclosure;
            FieldType[] custom_fields = { field };
            post.categories = categories;
            post.post_type = "post";
            post.custom_fields = custom_fields;
            appendToStatus(Environment.NewLine + "Creating podcast post...");
            String url = proxy.newPost(1, username, password, post, true);
            appendToStatus("All done. You can see the post at http://www.hobokengrace.com/wp/?p=" + url);
            progressBar.Value = 100;
        }

        public void appendToStatus(String message)
        {
            txtStatus.Text += message + Environment.NewLine;
            txtStatus.SelectionStart = txtStatus.Text.Length;
            txtStatus.ScrollToCaret();
        }

        public static byte[] ReadFile(string filePath)
        {
            byte[] buffer;
            FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            try
            {
                int length = (int)fileStream.Length;  // get file length
                buffer = new byte[length];            // create buffer
                int count;                            // actual number of bytes read
                int sum = 0;                          // total number of bytes read

                // read until Read method returns 0 (end of the stream has been reached)
                while ((count = fileStream.Read(buffer, sum, length - sum)) > 0)
                    sum += count;  // sum is a buffer offset for next reading
            }
            finally
            {
                fileStream.Close();
            }
            return buffer;
        }
    }

}

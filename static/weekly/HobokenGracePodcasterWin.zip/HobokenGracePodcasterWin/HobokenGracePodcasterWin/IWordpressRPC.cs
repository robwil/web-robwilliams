﻿using CookComputing.XmlRpc;
using System;

public struct FileReturnValue {
    public String file;
    public String url;
    public String type;
};

public struct FileValue
{
    public String name;
    public String type;
    public Byte[] bits;
    public Boolean overwrite;
};

public struct FieldType
{
    public String key;
    public String value;
}

public struct PostValue {
    public String title;
    public String description;
    public String[] categories;
    public String post_type;
    public FieldType[] custom_fields;
};

[XmlRpcUrl("http://www.yoururlhere.com/wp/xmlrpc.php")]
public interface IWordpressRPC : IXmlRpcProxy
{
    [XmlRpcMethod("wp.uploadFile")]
    FileReturnValue uploadFile(Int32 blog_id, String username, String password, FileValue file);

    [XmlRpcMethod("metaWeblog.newPost")]
    String newPost(Int32 blog_id, String username, String password, PostValue content, Boolean published);
}
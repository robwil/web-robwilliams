<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		session_start();
		if (isset($_SESSION['logged_in'])) {
			redirect('pack');
		}
	}

	public function index()
	{
		$this->load->library('PasswordHash', array(8, FALSE));
		//echo $this->passwordhash->HashPassword('password'); die();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="warning">', '</p>');
		
		// Form Validation rules
		$this->form_validation->set_rules('password', 'Password', 'required');
		if ($this->form_validation->run() != FALSE)
		{
			// Form is valid, so check authentication
			if ($this->passwordhash->CheckPassword($this->input->post('password'),'YOUR_PASSWORD_HERE'))
			{
				$_SESSION['logged_in'] = true;
				redirect('pack');
			}
		}
			
		// If form info was not valid (or password wrong), show form.
		// This also applies when there was no form data (i.e. first coming to this page)
		$this->load->view('admin/login_form');
	}
	
	public function logout()
	{
		session_destroy();
		redirect('admin');
	}
}
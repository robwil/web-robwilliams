<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pack extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		session_start();
		if (!isset($_SESSION['logged_in'])) {
			redirect('admin');
		}
	}

	public function index()
	{
		$data['lists'] = $this->db->query('SELECT L.list_id, L.name FROM list L ORDER BY L.weight DESC')->result();
		$data['trips'] = $this->db->query('SELECT T.trip_id, T.name FROM trip T ORDER BY T.weight DESC')->result();
		$data['instances'] = $this->db->query('SELECT I.instance_id, I.name FROM instance I ORDER BY I.weight DESC')->result();
		$this->load->view('main', $data);
	}
	
	public function lists()
	{
		// extract id from URI segment and query list name and items using it
		$id = $this->uri->segment(3); // first two parts of segmant are /controller/action/. 3rd is the id
		$data['name'] = $this->db->query('SELECT L.name FROM list L WHERE list_id=?', array($id))->row()->name;
		$data['id'] = $id;
		$data['items'] = $this->db->query('SELECT LI.name as item_name, LI.item_id as item_id, LI.weight FROM list_item LI INNER JOIN list L ON LI.list_id=L.list_id WHERE L.list_id=? ORDER BY LI.weight DESC', array($id))->result();
		$this->load->view('list_view', $data);
	}
	
	public function create_list()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="warning">', '</p>');
		
		// Form Validation rules
		$this->form_validation->set_rules('name', 'Name', 'trim|required|max_length[255]');
		$this->form_validation->set_rules('weight', 'Weight', 'trim|required|numeric');
		if ($this->form_validation->run() == FALSE)
		{
			// If form info was not valid, show form.
			// This also applies when there was no form data (i.e. first coming to this page)
			$this->load->view('create_list_form');
		}
		else
		{
			// Populate DB object with columns for new List entity
			$this->db->set('name', $_POST['name']);
			$this->db->set('weight', $_POST['weight']);
			// Insert into DB
			$this->db->insert('list');
			// Create success notice which will be shown to user on main page.
			$this->session->set_flashdata('notice', 'Successfully created list "'.$_POST['name'].'"');
			redirect('/');
		}
	}
	
	public function delete_list()
	{
		// URI for delete_list_item will be /pack/delete_list/{list_id}
		$this->db->delete('list', array('list_id' => $this->uri->segment(3)));
		// Create success notice which will be shown to user on main page.
		$this->session->set_flashdata('notice', 'Successfully deleted list.');
		redirect('/');
	}
	
	public function create_list_item()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="warning">', '</p>');
		
		// Form Validation rules
		$this->form_validation->set_rules('name', 'Name', 'trim|required|max_length[255]');
		$this->form_validation->set_rules('weight', 'Weight', 'trim|required|numeric');
		if ($this->form_validation->run() == FALSE)
		{
			// If form info was not valid, show form.
			// This also applies when there was no form data (i.e. first coming to this page)
			$this->load->view('create_list_item_form', array('form_action' => 'create_list_item'));
		}
		else
		{
			// Insert into DB
			$this->db->insert('list_item', $_POST);
			
			// Redirect to List View page
			redirect('pack/lists/'.$_POST['list_id']);
		}
	}
	
	public function edit_list_item()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="warning">', '</p>');
		
		// Form Validation rules
		$this->form_validation->set_rules('name', 'Name', 'trim|required|max_length[255]');
		$this->form_validation->set_rules('weight', 'Weight', 'trim|required|numeric');
		if ($this->form_validation->run() == FALSE)
		{
			$row = $this->db->get_where('list_item', array('item_id' => $this->uri->segment(4)))->row();
			$_POST['list_id'] = $this->uri->segment(3);
			$_POST['name'] = $row->name;
			$_POST['weight'] = $row->weight;
			
			// If form info was not valid, show form.
			// This also applies when there was no form data (i.e. first coming to this page)
			$this->load->view('create_list_item_form', array('form_action' => 'edit_list_item'));
		}
		else
		{
			// Update DB
			$this->db->update('list_item', $_POST, array('item_id' => $_POST['item_id']));
			
			// Redirect to List View page
			redirect('pack/lists/'.$_POST['list_id']);
		}
	}
	
	public function delete_list_item()
	{
		// URI for delete_list_item will be /pack/delete_list_item/{list_id}/{item_id}
		$this->db->delete('list_item', array('item_id' => $this->uri->segment(4)));
		redirect('pack/lists/'.$this->uri->segment(3));
	}
	
	public function trips()
	{
		// extract id from URI segment and query list name and items using it
		$id = $this->uri->segment(3); // first two parts of segmant are /controller/action/. 3rd is the id
		$data['name'] = $this->db->query('SELECT T.name FROM trip T WHERE trip_id=?', array($id))->row()->name;
		$data['id'] = $id;
		$data['lists'] = $this->db->query('SELECT L.name as list_name, L.list_id as list_id, L.weight, (SELECT count(*) FROM list_item LI WHERE LI.list_id=L.list_id) as items_count FROM trip T INNER JOIN trip_list TL ON T.trip_id=TL.trip_id INNER JOIN list L ON TL.list_id=L.list_id WHERE T.trip_id=? ORDER BY L.weight DESC', array($id))->result();
		$this->load->view('trip_view', $data);
	}
	
	public function create_trip()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="warning">', '</p>');
		
		// Form Validation rules
		$this->form_validation->set_rules('name', 'Name', 'trim|required|max_length[255]');
		$this->form_validation->set_rules('weight', 'Weight', 'trim|required|numeric');
		if ($this->form_validation->run() == FALSE)
		{
			// If form info was not valid, show form.
			// This also applies when there was no form data (i.e. first coming to this page)
			$this->load->view('create_trip_form');
		}
		else
		{
			// Populate DB object with columns for new Trip entity
			$this->db->set('name', $_POST['name']);
			$this->db->set('weight', $_POST['weight']);
			// Insert into DB
			$this->db->insert('trip');
			// Create success notice which will be shown to user on main page.
			$this->session->set_flashdata('notice', 'Successfully created trip "'.$_POST['name'].'"');
			redirect('/');
		}
	}
	
	public function clone_trip()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="warning">', '</p>');
		
		// Form Validation rules
		$this->form_validation->set_rules('trip_id', 'Trip', 'required');
		$this->form_validation->set_rules('new_name', 'New Name', 'trim|required|max_length[255]');
		if ($this->form_validation->run() == FALSE)
		{
			// Get list of Trips for the drop-down menu
			$data['trips'] = $this->db->query('SELECT * FROM trip T ORDER BY T.weight DESC')->result();
			// If form info was not valid, show form.
			// This also applies when there was no form data (i.e. first coming to this page)
			$this->load->view('clone_trip_form', $data);
		}
		else
		{
			// Get existing Trip entity (that we are cloning)
			$trip_to_clone = $this->db->get_where('trip', array('trip_id' => $_POST['trip_id']))->row();
			// Populate DB object with columns for new Trip entity
			$this->db->set('name', $_POST['new_name']);
			$this->db->set('weight', $trip_to_clone->name);
			// Insert into DB
			$this->db->insert('trip');
			$trip_id = $this->db->insert_id();
			
			// Now for the cloning part. Simply create a Trip List entity for each one that exists
			// for the existing Trip entity (that we are cloning)
			$trip_lists_to_clone = $this->db->query('SELECT TL.list_id FROM trip_list TL WHERE TL.trip_id=?', array($_POST['trip_id']))->result();
			foreach ($trip_lists_to_clone as $trip_list) {
				$this->db->set('trip_id', $trip_id);
				$this->db->set('list_id', $trip_list->list_id);
				$this->db->insert('trip_list');
			}
			
			// Create success notice which will be shown to user on main page.
			$this->session->set_flashdata('notice', 'Successfully cloned trip "'.$trip_to_clone->name.'".');
			redirect('/');
		}
	}
	
	public function delete_trip()
	{
		// URI for delete_list_item will be /pack/delete_trip/{trip_id}
		$this->db->delete('trip', array('trip_id' => $this->uri->segment(3)));
		// Create success notice which will be shown to user on main page.
		$this->session->set_flashdata('notice', 'Successfully deleted trip.');
		redirect('/');
	}
	
	public function create_trip_link()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="warning">', '</p>');
		
		// Form Validation rules
		$this->form_validation->set_rules('list_id', 'Linked List', 'required');
		if ($this->form_validation->run() == FALSE)
		{
			// Get list of Lists for the drop-down box
			// But exclude lists that are already linked by this trip.
			$trip_id = $this->uri->segment(3);
			$data['lists'] = $this->db->query('SELECT * FROM list L WHERE L.list_id NOT IN (SELECT TL.list_id FROM trip_list TL WHERE TL.trip_id=?) ORDER BY L.weight DESC', array($trip_id))->result();
			// If form info was not valid, show form.
			// This also applies when there was no form data (i.e. first coming to this page)
			$this->load->view('create_trip_link_form', $data);
		}
		else
		{
			// Populate DB object with columns for new List Item entity
			$this->db->set('trip_id', $_POST['trip_id']);
			$this->db->set('list_id', $_POST['list_id']);
			// Insert into DB
			$this->db->insert('trip_list');
			
			// Redirect to Trip View page
			redirect('pack/trips/'.$_POST['trip_id']);
		}
	}
	
	public function instances()
	{
		// extract id from URI segment and query list name and items using it
		$id = $this->uri->segment(3); // first two parts of segmant are /controller/action/. 3rd is the id
		$data['name'] = $this->db->query('SELECT I.name FROM instance I WHERE instance_id=?', array($id))->row()->name;
		$data['id'] = $id;
		$data['items'] = $this->db->query('SELECT II.* FROM instance_item II INNER JOIN instance I ON II.instance_id=I.instance_id WHERE I.instance_id=? ORDER BY II.from_list ASC, II.weight DESC', array($id))->result();
		$this->load->view('instance_view', $data);
	}
	
	public function create_instance()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="warning">', '</p>');
		
		// Form Validation rules
		$this->form_validation->set_rules('trip_id', 'Trip', 'required');
		$this->form_validation->set_rules('name', 'Name', 'trim|required|max_length[255]');
		$this->form_validation->set_rules('weight', 'Weight', 'trim|required|numeric');
		if ($this->form_validation->run() == FALSE)
		{
			// Get list of Trips for the drop-down menu
			$data['trips'] = $this->db->query('SELECT * FROM trip T ORDER BY T.weight DESC')->result();
			// If form info was not valid, show form.
			// This also applies when there was no form data (i.e. first coming to this page)
			$this->load->view('create_instance_form', $data);
		}
		else
		{
			// Populate DB object with columns for new Instance entity
			$this->db->set('name', $_POST['name']);
			$this->db->set('weight', $_POST['weight']);
			// Insert into DB
			$this->db->insert('instance');
			$instance_id = $this->db->insert_id();
			
			// Now for the snapshot part. Loop through all the lists within the selected Trip
			// and add all those items as Instance Items.
			$linked_items = $this->db->query('SELECT LI.name, L.name as list_name, LI.weight FROM trip_list TL INNER JOIN list_item LI ON TL.list_id=LI.list_id INNER JOIN list L ON L.list_id=LI.list_id WHERE TL.trip_id=?', array($_POST['trip_id']))->result();
			foreach ($linked_items as $item) {
				$this->db->set('instance_id', $instance_id);
				$this->db->set('name', $item->name);
				$this->db->set('weight', $item->weight);
				$this->db->set('from_list', $item->list_name);
				$this->db->insert('instance_item');
			}
			
			// Create success notice which will be shown to user on main page.
			$this->session->set_flashdata('notice', 'Successfully created instance "'.$_POST['name'].'"');
			redirect('/');
		}
	}
	
	public function delete_instance()
	{
		// URI for delete_list_item will be /pack/delete_list/{instance_id}
		$this->db->delete('instance', array('instance_id' => $this->uri->segment(3)));
		// Create success notice which will be shown to user on main page.
		$this->session->set_flashdata('notice', 'Successfully deleted instance.');
		redirect('/');
	}
	
	public function instance_item_edit() {
		$this->db->update('instance_item', $_POST, array('item_id'=>$_POST['item_id']));
	}
}
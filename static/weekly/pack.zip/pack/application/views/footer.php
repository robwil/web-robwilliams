</div> <!-- end #body -->
	<p class="footer">
		<?php if (isset($_SESSION['logged_in'])) echo anchor('admin/logout', 'Logout', 'style="float:left; font-weight: bold;"'); ?>
		Page rendered in <strong>{elapsed_time}</strong> seconds
	</p>
</div>

</body>
</html>
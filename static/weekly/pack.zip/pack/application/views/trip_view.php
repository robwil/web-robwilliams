<?php $this->load->view('header', array('page_title' => '"'.$name.'" trip')); ?>

	<?php foreach($lists as $list) : ?>
	<input type='checkbox' name='lists[]' value='<?php echo $list->list_id; ?>' disabled='disabled'>
		<?php echo $list->list_name ?>
		<span class="ref">[
		<?php echo 'weight='.$list->weight.', items='.$list->items_count; ?>
		]</span>
	</input><br/>
	<?php endforeach; ?>
	
	<?php echo anchor('pack/create_trip_link/'.$id, 'Create Link to List'); ?><br/>
	<?php echo anchor('pack/delete_trip/'.$id, 'Delete Trip', 'onclick=\'return confirm("Are you sure you want to delete this trip?")\''); ?>

<?php $this->load->view('footer'); ?>
<?php $this->load->view('header', array('page_title' => '"'.$name.'" instance')); ?>

	<div id="should_pack" class="instance_column">
	<?php $current_from_list = ''; ?>
	<h3>Should Pack?</h3>
	<ul>
	<?php foreach($items as $item) : ?>
	<?php if ($current_from_list != $item->from_list) {
		$current_from_list = $item->from_list;
		echo $item->from_list.'<br/>';
	} ?>
	<?php if ($item->should_pack) echo '<del>'; ?>
	<li>
		<input type='checkbox' id='should_pack<?php echo $item->item_id; ?>' <?php if ($item->should_pack) echo "checked='checked'"; ?>/>
		<label for='should_pack<?php echo $item->item_id; ?>'><?php echo $item->name ?></label>
	</li>
	<?php if ($item->should_pack) echo '</del>'; ?>
	<?php endforeach; ?>
	</ul>
	</div>
	
	<div id="packed" class="instance_column">
	<h3>Packed?</h3>
	<ul>
	<?php foreach($items as $item) : ?>
	<?php if ($item->should_pack == 0) continue; ?>
	<?php if ($item->packed) echo '<del>'; ?>
	<li>
		<input type='checkbox' id='packed<?php echo $item->item_id; ?>' <?php if ($item->packed) echo "checked='checked'"; ?>/>
		<label for='packed<?php echo $item->item_id; ?>'><?php echo $item->name ?></label>
	</li>
	<?php if ($item->packed) echo '</del>'; ?>
	<?php endforeach; ?>
	</ul>
	</div>
	
	<div id="repacked" class="instance_column">
	<h3>Repacked?</h3>
	<ul>
	<?php foreach($items as $item) : ?>
	<?php if ($item->packed == 0) continue; ?>
	<?php if ($item->repacked) echo '<del>'; ?>
	<li>
		<input type='checkbox' id='repacked<?php echo $item->item_id; ?>' <?php if ($item->repacked) echo "checked='checked'"; ?>/>
		<label for='repacked<?php echo $item->item_id; ?>'><?php echo $item->name ?></label>
	</li>
	<?php if ($item->repacked) echo '</del>'; ?>
	<?php endforeach; ?>
	</ul>
	</div>
	
	<script type="text/javascript">
		$(document).ready(function() {
			// get CSRF-preventing cookie
			var csr = $.cookie('csrf_cookie_name');
			
			// Click handler for Should Pack check/uncheck
			shouldPackHandler = function() {
				// extract id
				var item_id = $(this).attr("id").replace("should_pack","");
				// Handle when box is checked
				if ($(this).is(':checked')) {
					// checked items are wrapped in <del> to strike through appropriately
					$(this).parent().wrap('<del>');
					// use AJAX to update database (handled by "instance_item_edit" action in "pack" Controller)
					$.post("<?php echo site_url().'/pack/instance_item_edit';?>", {'csrf_test_name': csr, 'should_pack':'1', 'item_id':item_id}).error(function() { alert("something AJAXy went wrong");});
					// "clone" checkbox into Packed div to reflect how DB now looks
					var new_item = $('<li><input type="checkbox" id="packed' + item_id + '"><label for="packed' + item_id +'"> ' + $.trim($(this).parent().text()) + '</label></input></li>').hide();
					$('#packed ul').append(new_item);
					new_item.show('slide');
					// ensure this new cloned checkbox has the right click handler
					$('#packed'+item_id).click(packedHandler);
				} else {
					// remove <del> wrapping to get rid of strike through
					$(this).parent().unwrap('<del>');
					// use AJAX to update database (handled by "instance_item_edit" action in "pack" Controller)
					// also sets packed and repacked to 0
					$.post("<?php echo site_url().'/pack/instance_item_edit';?>", {'csrf_test_name': csr, 'should_pack':'0', 'packed':'0', 'repacked':'0', 'item_id':item_id}).error(function() { alert("something AJAXy went wrong");});
					// remove corresponding checkbox from packed and (possibly) repacked columns
					$('#packed'+item_id).parent().hide('slide', function() { $(this).remove(); });
					$('#repacked'+item_id).parent().hide('slide', function() { $(this).remove(); });
				}
			};
			// Click handler for Packed check/uncheck
			packedHandler = function() {
				// extract id
				var item_id = $(this).attr("id").replace("packed","");
				// Handle when box is checked
				if ($(this).is(':checked')) {
					// checked items are wrapped in <del> to strike through appropriately
					$(this).parent().wrap('<del>');
					// use AJAX to update database (handled by "instance_item_edit" action in "pack" Controller)
					$.post("<?php echo site_url().'/pack/instance_item_edit';?>", {'csrf_test_name': csr, 'packed':'1', 'item_id':item_id}).error(function() { alert("something AJAXy went wrong");});
					// "clone" checkbox into Repacked div to reflect how DB now looks
					var new_item = $('<li><input type="checkbox" id="repacked' + item_id + '"><label for="repacked' + item_id + '"> ' + $.trim($(this).parent().text()) + '</label></input></li>').hide();
					$('#repacked ul').append(new_item);
					new_item.show('slide');
					// ensure this new cloned checkbox has the right click handler
					$('#repacked'+item_id).click(repackedHandler);
				} else {
					// remove <del> wrapping to get rid of strike through
					$(this).parent().unwrap('<del>');
					// use AJAX to update database (handled by "instance_item_edit" action in "pack" Controller)
					// also sets repacked to 0
					$.post("<?php echo site_url().'/pack/instance_item_edit';?>", {'csrf_test_name': csr, 'packed':'0', 'repacked':'0', 'item_id':item_id}).error(function() { alert("something AJAXy went wrong");});
					// remove corresponding checkbox from repacked columns
					$('#repacked'+item_id).parent().hide('slide', function() { $(this).remove(); });
				}
			};
			// Click handler for Repacked check/uncheck
			repackedHandler = function() {
				// extract id
				var item_id = $(this).attr("id").replace("repacked","");
				// Handle when box is checked
				if ($(this).is(':checked')) {
					// checked items are wrapped in <del> to strike through appropriately
					$(this).parent().wrap('<del>');
					// use AJAX to update database (handled by "instance_item_edit" action in "pack" Controller)
					$.post("<?php echo site_url().'/pack/instance_item_edit';?>", {'csrf_test_name': csr, 'repacked':'1', 'item_id':item_id}).error(function() { alert("something AJAXy went wrong");});
				} else {
					// remove <del> wrapping to get rid of strike through
					$(this).parent().unwrap('<del>');
					// use AJAX to update database (handled by "instance_item_edit" action in "pack" Controller)
					$.post("<?php echo site_url().'/pack/instance_item_edit';?>", {'csrf_test_name': csr, 'repacked':'0', 'item_id':item_id}).error(function() { alert("something AJAXy went wrong");});
				}
			};
		
			// Setup click handlers
			$('input[id^="should_pack"]').click(shouldPackHandler);
			$('input[id^="packed"]').click(packedHandler);
			$('input[id^="repacked"]').click(repackedHandler);
			
		});
	</script>
	
	<br clear="both"/>
	<?php echo anchor('pack/delete_instance/'.$id, 'Delete Instance', 'onclick=\'return confirm("Are you sure you want to delete this instance?")\''); ?>
	
<?php $this->load->view('footer'); ?>
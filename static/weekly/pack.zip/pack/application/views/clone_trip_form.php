<?php $this->load->view('header', array('page_title' => 'Clone Trip')); ?>

<?php
echo validation_errors();

echo form_open('pack/clone_trip');

echo '<table>';
echo '<tr><td>'.form_label('Trip to Clone: ', 'trip_id').'</td>';
foreach ($trips as $trip) {
	$options[$trip->trip_id] = $trip->name;
}
echo '<td>'.form_dropdown('trip_id', $options).'</td></tr>';
echo '<tr><td>'.form_label('New Name: ', 'new_name').'</td>';
echo '<td>'.form_input('new_name', set_value('new_name')).'</td></tr>';
echo '<tr><td colspan="2">'.form_submit('submit', 'Create').'</td></tr>';
echo '</table>';

echo form_close();

echo anchor('/', 'Back to Home');
?>

<?php $this->load->view('footer'); ?>
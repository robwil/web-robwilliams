<?php $this->load->view('header', array('page_title' => '"'.$name.'" list')); ?>

	<?php foreach($items as $item) : ?>
	<input type='checkbox' name='items[]' value='<?php echo $item->item_id; ?>' disabled='disabled'>
		<?php echo anchor('pack/edit_list_item/'.$id.'/'.$item->item_id, $item->item_name); ?>
		<span class="ref">[
		<?php echo 'weight='.$item->weight; ?>
		]</span>
	</input><br/>
	<?php endforeach; ?>
	
	<?php echo anchor('pack/create_list_item/'.$id, 'Create Item'); ?><br/>
	<?php echo anchor('pack/delete_list/'.$id, 'Delete List', 'onclick=\'return confirm("Are you sure you want to delete this list?")\''); ?>

<?php $this->load->view('footer'); ?>
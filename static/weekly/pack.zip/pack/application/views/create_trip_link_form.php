<?php $this->load->view('header', array('page_title' => 'Create Link to List')); ?>

<?php
echo validation_errors();

echo form_open('pack/create_trip_link/'.$this->uri->segment(3));
echo form_hidden('trip_id', $this->uri->segment(3));

if (empty($lists)) {
	echo "You have already linked to every list. You cannot create another link.";
} else {
	echo '<table>';
	echo '<tr><td>'.form_label('List: ', 'list_id').'</td>';
	foreach ($lists as $list) {
		$options[$list->list_id] = $list->name;
	}
	echo '<td>'.form_dropdown('list_id', $options).'</td></tr>';
	echo '<tr><td colspan="2">'.form_submit('submit', 'Create').'</td></tr>';
	echo '</table>';
}

echo form_close();

echo anchor('pack/trips/'.$this->uri->segment(3), 'Back to Trip');
?>

<?php $this->load->view('footer'); ?>
<?php $this->load->view('header', array('page_title' => 'Login'));

echo form_open('admin');
echo form_label('Password: ', 'password');
echo form_password('password', '');
echo form_submit('submit', 'Login');

$this->load->view('footer');
?>
<?php
if ($form_action == 'create_list_item') {
	$title = 'Create List Item';
} else { // edit_list_item
	$title = 'Edit List Item';
}
$this->load->view('header', array('page_title' => $title)); ?>

<?php
echo validation_errors();

if ($form_action == 'create_list_item') {
	echo form_open('pack/create_list_item/'.$this->uri->segment(3));
} else { // edit_list_item
	echo form_open('pack/edit_list_item/'.$this->uri->segment(3).'/'.$this->uri->segment(4));
	echo form_hidden('item_id', $this->uri->segment(4));
}
echo form_hidden('list_id', $this->uri->segment(3));

echo '<table>';
echo '<tr><td>'.form_label('Name: ', 'name').'</td>';
if (isset($_POST['name'])) {
	echo '<td>'.form_input('name', $_POST['name']).'</td></tr>';
} else {
	echo '<td>'.form_input('name', '').'</td></tr>';
}
echo '<tr><td>'.form_label('Weight: ', 'weight').'</td>';
if (isset($_POST['weight'])) {
	echo '<td>'.form_input('weight', $_POST['weight']).'</td></tr>';
} else {
	echo '<td>'.form_input('weight', 0).'</td></tr>';
}
if ($form_action == 'create_list_item') {
	echo '<tr><td colspan="2">'.form_submit('', 'Create').'</td></tr>';
} else { // edit_list_item
	echo '<tr><td colspan="2">'.form_submit('', 'Edit').'</td></tr>';
}
echo '</table>';

echo form_close();

if ($form_action == 'edit_list_item') {
	echo anchor('pack/delete_list_item/'.$this->uri->segment(3).'/'.$this->uri->segment(4), 'Delete Item', 'onclick=\'return confirm("Are you sure you want to delete this item?")\'').'<br/>';
}
echo anchor('pack/lists/'.$this->uri->segment(3), 'Back to List');

?>

<?php $this->load->view('footer'); ?>
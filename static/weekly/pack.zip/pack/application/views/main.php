<?php $this->load->view('header', array('page_title' => 'Welcome to Pack!')); ?>

		<?php
			$notice = $this->session->flashdata('notice');
			if (isset($notice) && strlen($notice) > 0) { echo '<p class="notice">'.$notice.'</p>'; }
		?>

		<h2>Lists</h2>
		<?php if (empty($lists)) {
			echo "You have no lists yet. Create one using the link below.<br/>";
		} else { ?>
		<ul>
			<?php foreach($lists as $list) : ?>
			<li>
				<?php echo anchor('pack/lists/'.$list->list_id, $list->name); ?>
			</li>
			<?php endforeach; ?>
		</ul>
		<?php } ?>
		<?php echo anchor('pack/create_list', 'Create List'); ?>
		
		<h2>Trips</h2>
		<?php if (empty($trips)) {
			echo "You have no trips yet. Create one using the link below.<br/>";
		} else { ?>
		<ul>
			<?php foreach($trips as $trip) : ?>
			<li><?php echo anchor('pack/trips/'.$trip->trip_id, $trip->name); ?></li>
			<?php endforeach; ?>
		</ul>
		<?php } ?>
		<?php echo anchor('pack/create_trip', 'Create Trip'); ?><br/>
		<?php echo anchor('pack/clone_trip', 'Clone Trip'); ?>
		
		<h2>Instances</h2>
		<?php if (empty($instances)) {
			echo "You have no instances yet. Create one using the link below.<br/>";
		} else { ?>
		<ul>
			<?php foreach($instances as $instance) : ?>
			<li><?php echo anchor('pack/instances/'.$instance->instance_id, $instance->name); ?></li>
			<?php endforeach; ?>
		</ul>
		<?php } ?>
		<?php echo anchor('pack/create_instance', 'Create Instance'); ?>

<?php $this->load->view('footer'); ?>
<?php $this->load->view('header', array('page_title' => 'Create List')); ?>

<?php
echo validation_errors();

echo form_open('pack/create_list');

echo '<table>';
echo '<tr><td>'.form_label('Name: ', 'name').'</td>';
echo '<td>'.form_input('name', set_value('name')).'</td></tr>';
echo '<tr><td>'.form_label('Weight: ', 'weight').'</td>';
echo '<td>'.form_input('weight', set_value('weight', '0')).'</td></tr>';
echo '<tr><td colspan="2">'.form_submit('submit', 'Create').'</td></tr>';
echo '</table>';

echo form_close();

echo anchor('/', 'Back to Home');

?>

<?php $this->load->view('footer'); ?>
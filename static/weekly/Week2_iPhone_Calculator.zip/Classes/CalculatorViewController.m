//
//  CalculatorViewController.m
//  Calculator
//
//  Created by Rob Williams on 8/31/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "CalculatorViewController.h"

@implementation CalculatorViewController
@synthesize output;
@synthesize memory;
@synthesize pickerData;

- (IBAction) buttonPressed:(id)sender {
	int tag = [sender tag];
	
	if (output.text.length >= 22) {
		if (tag == Clear) {
			output.text = @"";
			[self resetState];
		}
		return;
	}
	// entering something other than an operator
	if (tag >= 0 && tag <= 10) {
		if (shouldClear) {
			output.text = @"";
			decimal = false;
			shouldClear = false;
		}
	}
	
	// Entering a number.
	if (tag >= 0 && tag <= 9) {
		// check to see if current display shows 0. If it does, clear it out because we are pressing a number.
		if ([output.text isEqualToString:@"0"]) {
			output.text = @"";
			decimal = false;
			shouldClear = false;
		}
		
	}
	
	//NSLog(@"tag: %d\nshouldClear:%d\ncurrentOp:%d\npreviousNum:%lf\ncurrentNum:%lf", tag,shouldClear,currentOp,previousNum,currentNum);
	
	
	switch ( tag ) {
		case 1:
			output.text = [output.text stringByAppendingString:@"1"];
			break;
		case 2:
			output.text = [output.text stringByAppendingString:@"2"];
			break;
		case 3:
			output.text = [output.text stringByAppendingString:@"3"];
			break;
		case 4:
			output.text = [output.text stringByAppendingString:@"4"];
			break;
		case 5:
			output.text = [output.text stringByAppendingString:@"5"];
			break;
		case 6:
			output.text = [output.text stringByAppendingString:@"6"];
			break;
		case 7:
			output.text = [output.text stringByAppendingString:@"7"];
			break;
		case 8:
			output.text = [output.text stringByAppendingString:@"8"];
			break;
		case 9:
			output.text = [output.text stringByAppendingString:@"9"];
			break;
		case 0:
			output.text = [output.text stringByAppendingString:@"0"];
			break;
		case Decimal:
			if (!decimal) {
				if ([output.text isEqualToString:@""]) output.text = @"0";
				output.text = [output.text stringByAppendingString:@"."];
				decimal = true;
			}
			break;
		case Equals:
			[self showResult];
			[self resetState];
			shouldClear = true;
			break;
		case Add:
			if (previousNum != 0) [self showResult];
			else previousNum = [output.text doubleValue];
			currentOp = Add;
			shouldClear = true;
			break;
		case Subtract:
			if (previousNum != 0) [self showResult];
			else previousNum = [output.text doubleValue];
			currentOp = Subtract;
			shouldClear = true;
			break;
		case Multiply: 
			if (previousNum != 0) [self showResult];
			else previousNum = [output.text doubleValue];
			currentOp = Multiply;
			shouldClear = true;
			break;
		case Divide: 
			if (previousNum != 0) [self showResult];
			else previousNum = [output.text doubleValue];
			currentOp = Divide;
			shouldClear = true;
			break;
		case RCL:
			output.text = [pickerData objectAtIndex:[memory selectedRowInComponent:0]];
			//[self resetState];
			break;
		case STO:
			[pickerData addObject:output.text];
			[memory reloadAllComponents];
			break;
		case Power:
			if (previousNum != 0) [self showResult];
			else previousNum = [output.text doubleValue];
			currentOp = Power;
			shouldClear = true;
			break;
		case Sqrt:
			currentNum = [output.text doubleValue];
			output.text = [[NSString alloc] initWithFormat:@"%lf",sqrt(currentNum)];
			previousNum = [output.text doubleValue];
			break;
		case Clear:
			output.text = @"0";
			[self resetState];
			break;
	}
}

- (void)resetState {
	decimal = false;
	currentOp = 0;
	shouldClear = false;
	previousNum = 0.0;
	currentNum = 0.0;
}

- (void)showResult {
	if (currentOp == 0) return;
	currentNum = [output.text doubleValue];
	switch (currentOp) {
		case Add:
			output.text = [[NSString alloc] initWithFormat:@"%lf",currentNum+previousNum];
			break;
		case Subtract:
			output.text = [[NSString alloc] initWithFormat:@"%lf",previousNum-currentNum];
			break;
		case Multiply:
			output.text = [[NSString alloc] initWithFormat:@"%lf",currentNum*previousNum];
			break;
		case Divide:
			output.text = [[NSString alloc] initWithFormat:@"%lf",previousNum/currentNum];
			break;
		case Power:
			output.text = [[NSString alloc] initWithFormat:@"%lf",pow(previousNum,currentNum)];
			break;
	}
	previousNum = [output.text doubleValue];
	shouldClear = true;
}

- (void)viewDidLoad {
	decimal = false;
	currentOp = 0;
	NSMutableArray *array = [[NSMutableArray alloc] initWithObjects: nil];
	self.pickerData = array;
	[array release];
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[output release];
	[memory release];
	[pickerData release];
    [super dealloc];
}

#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
	return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
	return [pickerData count];
}

#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
	return [pickerData objectAtIndex:row];
}

@end

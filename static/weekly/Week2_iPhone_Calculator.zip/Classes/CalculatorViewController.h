//
//  CalculatorViewController.h
//  Calculator
//
//  Created by Rob Williams on 8/31/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
	Add = 12,
	Subtract = 13,
	Multiply = 14,
	Divide = 15,
	Power = 18
} Operators;

typedef enum {
	Decimal = 10,
	Equals = 11,
	RCL = 16,
	STO = 17,
	Sqrt = 19,
	Clear = 20
} Others;

@interface CalculatorViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {
	bool decimal;
	bool shouldClear;
	int currentOp;
	double previousNum;
	double currentNum;
	UITextField *output;
	UIPickerView *memory;
	NSMutableArray *pickerData;
}

@property (nonatomic, retain) IBOutlet UITextField *output;
@property (nonatomic, retain) IBOutlet UIPickerView *memory;
@property (nonatomic, retain) NSMutableArray *pickerData;

- (IBAction) buttonPressed:(id)sender;
- (void)resetState;
- (void)showResult;

@end


require 'bencoding'

# handle arguments
if ARGV.length < 1
  puts "Usage: torrent_parser.rb [v] <torrent_file>"
  exit
end
if ARGV.length == 1
  torrentFile = ARGV[0]
  verbose = false
else
  torrentFile = ARGV[1]
  verbose = true if ARGV[0] == "v"
end

# open file and decode
$file = File.new(torrentFile)
metainfo = Bencoding.bdecode()
#pp metainfo
if metainfo.class.to_s != "Hash"
  puts "invalid torrent file"
  exit
end

# output torrent information by reading the root dictionary (metainfo)
puts
puts "====== Torrent Information ======"
puts
# Get Tracker Information.
# Two cases - Either there is an 'announce-list' key which lists multiple trackers,
#             or there is an 'announce' key which has one tracker URL in it.
puts "Tracker(s)"
puts "-------------------"
if metainfo['announce-list']
  metainfo['announce-list'].flatten.each do |tracker|
    puts "Tracker URL: \t" + tracker
  end
else
  puts "Tracker URL: \t" + metainfo['announce']
end
puts
# Get File Information
# Two cases - Either this is a Single File torrent, in which case there is 1 file.
#             Or this is a Multi File torrent, in which case there is a directory
#             and then a bunch of files.
if metainfo['info']['files'].nil? # we have a Single File Torrent
  puts "Single File Torrent"
  puts "-------------------"
  puts "Filename: \t" + metainfo['info']['name']
  puts "File size: \t" + metainfo['info']['length'].to_s
  puts "MD5 Sum: \t" + metainfo['info']['md5sum'] if metainfo['info']['md5sum']
else # we have Multi-File torrent
  puts "Multi File Torrent"
  puts "-------------------"
  puts "Directory: \t" + metainfo['info']['name']
  puts
  puts "Files"
  print "-------------------"
  # output info for each file
  for file in metainfo['info']['files']
    puts
    print "File path: \t"
    path = ""
    # File paths are stored in a list (array) of strings, one for each part of the path
    # e.g. Heroes/Season 1/Episode 1.avi is stored as ["Heroes", "Season 1", "Episode 1.avi"]
    for dir_piece in file['path']
      path += dir_piece + "/"
    end 
    puts path.chop # chop gets rid of extra trailing '/'
    puts "File size: \t" + file['length'].to_s
    puts "MD5 Sum: \t" + file['md5sum'] if file['md5sum']
  end
end
puts
# Get Miscellaneous info.. basically just reading from dictionary and printing.
puts "Miscellaneous Info"
puts "-------------------"
puts "Private: \t" + (metainfo['info']['private'] == 1).to_s if metainfo['info']['private']
puts "Piece Length: \t" + metainfo['info']['piece length'].to_s
puts "Created On: \t" + Time.at(metainfo['creation date']).to_s if metainfo['creation date']
puts "Created By: \t" + metainfo['created by'] if metainfo['created by']
puts "Comment: \t" + metainfo['comment'] if metainfo['comment']
puts 

# if user specified verbose option, we print out Pieces (not like anyone would want this?)
# There is one ugly line in there which essentially takes all of the binary bytes of the SHA1 hash
# as they are stored (in a standard string), and prints out their Hex/Ascii values with spaces in between,
# just like most hex editors do.
if verbose
  puts "Pieces"
  puts "(Encoding: " + metainfo['encoding'] + ")" if metainfo['encoding']
  puts "-------------------"
  pieces = metainfo['info']['pieces']
  amount_of_pieces = pieces.length / 20
  for i in 1 .. amount_of_pieces
    print "Piece " + i.to_s + ": \t"
    # .slice!(0..19) takes 20 bytes off front of string -- each piece's hash is 20 bytes
    # .split(//) turns string into array e.g. "test" => ["t", "e", "s", "t"]
    # .each iterates over array created in last line
    # |c| makes variable c which represents the current character we're dealing with (in the loop)
    # c.unpack("H2") gets the hex value of the character
    # we print out the hex value each time, followed by a space
    pieces.slice!(0..19).split(//).each {|c| print c.unpack("H2").to_s + " " }
    puts
  end
end
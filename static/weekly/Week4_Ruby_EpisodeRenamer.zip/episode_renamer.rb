require 'rubygems'
require 'hpricot'
require 'open-uri'

if ARGV.length != 2
  puts "Usage: episode_renamer.rb <series_name> <path_to_season_folder>"
end

showName = ARGV[0]
folderPath = ARGV[1]
seriesID = 0

# get filenames
files = []
newnames = []
directory = Dir.new(folderPath)
directory.each do |file|
  files << file if file =~ /^[^\.]/;
end
if files.length == 0
  puts "No files in specified pathname: #{folderPath}"
  exit
end

# get series ID from TheTVDB
begin
  url = "http://www.thetvdb.com/api/GetSeries.php?seriesname=" + showName + "&language=English"
  doc = open(url) { |f| Hpricot::XML(f) }
  (doc/"Series").each do |serie|
    if (serie/"SeriesName").inner_html.downcase == showName.downcase
      seriesID = (serie/"seriesid").inner_html
      puts "Series ID: " + seriesID
      break
    end
  end
rescue OpenURI::HTTPError => e
  puts "There was a problem downloading the series information. Check the series name."
  exit
end

# get episode information from TheTVDB
begin
  files.each do |file|
    file =~ /.*0?(\d+)( |\.|\-)*(e|x|E|X) *0?(\d*).*\.(.+)$/
    season = $1
    episode = $4
    extension = $5
    url = "http://www.thetvdb.com/api/A97C434D80F2BEF5/series/" + seriesID + "/default/" + season + "/" + episode + "/english.xml"
    doc = open(url) { |f| Hpricot::XML(f) }
    (doc/"Episode").each do |ep|
      if (ep/"seriesid").text.to_i == seriesID.to_i
        newname = "#{showName} S"
        newname += "0" if season.to_i < 10
        newname += "#{season}E"
        newname += "0" if episode.to_i < 10
        newname += "#{episode} - "
        newname += (ep/"EpisodeName").inner_html + ".#{extension}"
        newnames << newname
        puts "<#{file}> ==> <#{newname}>"
      end
    end
  end
rescue OpenURI::HTTPError => e
 puts "There was a problem downloading the episode information. Check the series ID."
 exit
end 

print "Confirm renaming? (y/n) "
answer = STDIN.gets.chomp
if (answer.downcase == "y")
  i = 0
  files.each do |file|
    File.rename(folderPath + "/" + file, folderPath + "/" + newnames[i])
    puts "Renamed #{file} to #{newnames[i]}"
    i += 1
  end
end
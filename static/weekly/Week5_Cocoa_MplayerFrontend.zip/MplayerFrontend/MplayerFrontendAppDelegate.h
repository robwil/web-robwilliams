//
//  MplayerFrontendAppDelegate.h
//  MplayerFrontend
//
//  Created by Rob Williams on 9/22/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MplayerFrontendAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
	NSTextField *filePath;
	NSButton *frameSkip;
	NSButton *verbose;
	NSTextView *output;
}

@property (assign) IBOutlet NSWindow *window;
@property (nonatomic, retain) IBOutlet NSTextField *filePath;
@property (nonatomic, retain) IBOutlet NSButton *frameSkip;
@property (nonatomic, retain) IBOutlet NSButton *verbose;
@property (nonatomic, retain) IBOutlet NSTextView *output;


- (IBAction) playMovie:(id)sender;
- (IBAction) browse:(id)sender;

@end

//
//  MplayerFrontendAppDelegate.m
//  MplayerFrontend
//
//  Created by Rob Williams on 9/22/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MplayerFrontendAppDelegate.h"

@implementation MplayerFrontendAppDelegate

@synthesize window;
@synthesize filePath;
@synthesize frameSkip;
@synthesize verbose;
@synthesize output;

- (IBAction) playMovie:(id)sender {
	NSTask *task;
	task = [[NSTask alloc] init];
	[task setLaunchPath:@"/usr/local/bin/mplayer"];
	
	NSMutableArray *arguments;
	NSString *path = [[NSString alloc] initWithString:[filePath stringValue]];
	arguments = [NSMutableArray array];
	if ([verbose state] == 1)
		[arguments addObject:@"-v"];
	if ([frameSkip state] == 1)
		[arguments addObjectsFromArray:[NSArray arrayWithObjects:@"-vfm", @"ffmpeg", @"-lavdopts", @"lowres=1:fast:skiploopfilter=all", nil]];
	[arguments addObject: path];
	[task setArguments:arguments];
	
	NSPipe *pipe;
	pipe = [NSPipe pipe];
	[task setStandardOutput:pipe];
	[task setStandardError:pipe];
	NSFileHandle *file;
	file = [pipe fileHandleForReading];
	
	[task launch];
	NSData *data;
	data = [file readDataToEndOfFile];
	
	NSString *string;
	string = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
	[output setString:string];
}
- (IBAction) browse:(id)sender {	
	// Create the File Open Dialog class.
	NSOpenPanel* openDlg = [NSOpenPanel openPanel];
	
	// Enable the selection of one file only in the dialog.
	[openDlg setCanChooseFiles:YES];
	[openDlg setCanChooseDirectories:NO];
	[openDlg setAllowsMultipleSelection:NO];
	
	// Display the dialog, and put path in text box if OK was pressed.
	if ( [openDlg runModalForDirectory:nil file:nil] == NSOKButton )
		[filePath setStringValue: [openDlg filename]];
	
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {	
}

@end

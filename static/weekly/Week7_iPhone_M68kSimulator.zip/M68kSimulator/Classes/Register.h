//
//  Register.h
//  M68kSimulator
//
//  Created by Rob Williams on 10/21/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Register : NSObject {
	@private int value;
	UIButton* correspondingButton;
}
@property (nonatomic, retain) UIButton* correspondingButton;
- (id)initWithValue: (int) val corButton:(UIButton*) button;
- (int)getValue;
- (void)setValue:(int) newval;
- (void)clearFormatting;

@end

//
//  Memory.m
//  M68kSimulator
//
//  Created by Rob Williams on 10/22/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Memory.h"


@implementation Memory

/* constructor */
- (id)initWithMemoryView:(UITextView**)textview {
	if (self = [super init]) {
		bytes = 0x2000;
		memory = (unsigned char*) malloc(sizeof(unsigned char)*bytes);
		bzero(memory, 0x2000);
		memoryView = textview;
    }
	return self;
}

/* Changes Memory Text View to show the address range specified. It truncates bounds to [0, 2000] if they are more/less */
- (void)showMemoryFrom:(int)from to: (int)to {
	int i, j;
	
	NSLog(@"%d", memory[0x1000]);
	
	if (from < 0) from = 0;
	if (to >= bytes) to = bytes-1;
	NSMutableString* contents = [[NSMutableString alloc] init];
	for (i = from, j = 0; i < to; i++, j++) {
		if (j % 16 == 0) {
			if (j != 0) [contents appendString:@"\n"];
			[contents appendFormat:@"$%04x ", i];
		}
		[contents appendFormat:@"%02x ", memory[i]];
		//if (j != 0 && j % 15 == 0)
		//	[contents appendString:@"\n"];
	}
	[*memoryView setText:contents];
	[contents release];
}

/* Return an integer containing the value requests at location <address> */
- (int)getMemoryAt:(int)address size:(char)size {
	int retval = 0;
	
	if (address >= bytes) address = bytes - 1;
	if (address < 0) address = 0;
	if (size == 'b')
		return memory[address];
	else if (size == 'w') {
		retval |= memory[address++] << 8;
		retval |= memory[address];
		return retval;
	} else {
		retval |= memory[address++] << 24;
		retval |= memory[address++] << 16;
		retval |= memory[address++] << 8;
		retval |= memory[address];
		return retval;
	}
}

/* Set memory at location <address> to the value <value>, but only using the lower <size> of <value> */
- (void)setMemoryAt:(int)address to: (int)value size: (char)size {
	if (address >= bytes) address = bytes - 1;
	if (address < 0) address = 0;
	if (size == 'b')
		memory[address] = (char)(value & 0x000000ff);
	else if (size == 'w') {
		value &= 0x0000ffff;
		memory[address+1] = (char)(value & 0x000000ff);
		value >>= 8;
		memory[address] = (char)(value & 0x000000ff);
	} else {
		memory[address+3] = (char)(value & 0x000000ff);
		value >>= 8;
		memory[address+2] = (char)(value & 0x000000ff);
		value >>= 8;
		memory[address+1] = (char)(value & 0x000000ff);
		value >>= 8;
		memory[address] = (char)(value & 0x000000ff);
	}
}

@end

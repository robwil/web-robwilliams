//
//  Memory.h
//  M68kSimulator
//
//  Created by Rob Williams on 10/22/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Memory : NSObject {
	@private unsigned char* memory;
	@private int bytes;
	@private UITextView** memoryView;
}

- (id)initWithMemoryView:(UITextView**)textview;
- (void)showMemoryFrom:(int)from to: (int)to;
- (int)getMemoryAt:(int)address size: (char) size;
- (void)setMemoryAt:(int)address to: (int)value size: (char)size;

@end

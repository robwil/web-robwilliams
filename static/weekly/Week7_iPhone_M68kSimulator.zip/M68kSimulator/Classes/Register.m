//
//  Register.m
//  M68kSimulator
//
//  Created by Rob Williams on 10/21/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Register.h"


@implementation Register
@synthesize correspondingButton;

/* constructor */
- (id)initWithValue: (int) val corButton:(UIButton*) button {
	if (self = [super init]) {
		correspondingButton = [button retain];
		[self setValue: val];
    }
	return self;
}

/* accessor for value */
- (int)getValue {
	return value;
}

/* mutator for value */
- (void)setValue:(int) newval {
	/* If the value is new, set it and make button red */
	if (value != newval) {
		value = newval;
		[correspondingButton setTitle:[NSString stringWithFormat:@"$%08x", value] forState:UIControlStateNormal];
		[correspondingButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
	/* otherwise, clear formatting to make it black */
	} else {
		[self clearFormatting];
	}
}

/* Set corresponding button to black, essentially clearing any red format it may have. */
- (void)clearFormatting {
	[correspondingButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

@end

//
//  FirstViewController.h
//  M68kSimulator
//
//  Created by Rob Williams on 10/21/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Register.h"
#import "Memory.h"

@interface FirstViewController : UIViewController {	
	/* Outlets for RegistersView */
	UIButton *d0;
	UIButton *d1;
	UIButton *d2;
	UIButton *d3;
	UIButton *d4;
	UIButton *d5;
	UIButton *d6;
	UIButton *d7;
	UIButton *a0;
	UIButton *a1;
	UIButton *a2;
	UIButton *a3;
	UIButton *a4;
	UIButton *a5;
	UIButton *a6;
	UIButton *a7;
	UIButton *pc;
	UIButton *sr;
	
	/* Outlets for MemoryView */
	UITextField *from;
	UITextField *to;
	UITextView *memoryView;
	
	/* Outlets for CodeView */
	UITextField *newInstruction;
	UITextView *log;
	UITextView *previousInstructions;
}

/* Properties for RegistersView */
@property (nonatomic, retain) IBOutlet UIButton *d0;
@property (nonatomic, retain) IBOutlet UIButton *d1;
@property (nonatomic, retain) IBOutlet UIButton *d2;
@property (nonatomic, retain) IBOutlet UIButton *d3;
@property (nonatomic, retain) IBOutlet UIButton *d4;
@property (nonatomic, retain) IBOutlet UIButton *d5;
@property (nonatomic, retain) IBOutlet UIButton *d6;
@property (nonatomic, retain) IBOutlet UIButton *d7;
@property (nonatomic, retain) IBOutlet UIButton *a0;
@property (nonatomic, retain) IBOutlet UIButton *a1;
@property (nonatomic, retain) IBOutlet UIButton *a2;
@property (nonatomic, retain) IBOutlet UIButton *a3;
@property (nonatomic, retain) IBOutlet UIButton *a4;
@property (nonatomic, retain) IBOutlet UIButton *a5;
@property (nonatomic, retain) IBOutlet UIButton *a6;
@property (nonatomic, retain) IBOutlet UIButton *a7;
@property (nonatomic, retain) IBOutlet UIButton *pc;
@property (nonatomic, retain) IBOutlet UIButton *sr;

/* Properties for MemoryView */
@property (nonatomic, retain) IBOutlet UITextField *from;
@property (nonatomic, retain) IBOutlet UITextField *to;
@property (nonatomic, retain) IBOutlet UITextView *memoryView;

/* Properties for CodeView */
@property (nonatomic, retain) IBOutlet UITextField *newInstruction;
@property (nonatomic, retain) IBOutlet UITextView *log;
@property (nonatomic, retain) IBOutlet UITextView *previousInstructions;

/* Actions for MemoryView */
- (IBAction)toFromTextFieldDoneEditing:(id)sender;
- (IBAction)viewMemory:(id)sender;

/* Actions for CodeView */
- (IBAction)textFieldDoneEditing:(id)sender;
- (IBAction)codeViewBackgroundClick:(id)sender;
- (IBAction)testButton:(id)sender;

/* My Methods */
- (void)setupRegisters;
- (void)setupMemory;
- (NSString*)executeInstruction:(NSString*)instruction;
- (int)getSourceFromCString: (char**) buffer size: (char) size;
- (char*)getDestinationFromCString: (char**) buffer size: (char) size;
- (void)setRegister:(char*) reg toValue:(int) value;
- (int)getRegisterValue:(char*) reg;
- (Register*)getRegister:(char*) reg;
- (void)setSR:(int) value;
- (void)clearRegistersFormatting;
- (int)baseToDecimal: (char*)number type:(char) type;

@end

//
//  FirstViewController.m
//  M68kSimulator
//
//  Created by Rob Williams on 10/21/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "FirstViewController.h"


@implementation FirstViewController
@synthesize d0, d1, d2, d3, d4, d5, d6, d7, a0, a1, a2, a3, a4, a5, a6, a7, pc, sr;
@synthesize from, to, memoryView;
@synthesize newInstruction, log, previousInstructions;

bool registersSetup = false;
char memorySetup = 0;
/* Store registers as Register objects. 0-7 are D0 - D7. 8 - 15 are A0 - A7. 16 is PC. */
Register* registers[17];
int SR[2]; /* made separate because it has two separate bytes which are displayed as bits
			Note: the bottom byte is USER-space, only system can modify the upper byte */
/* Memory stored as Memory object. */
Memory* memory;
UITextView* ptrMemoryView; /* Allows Memory *memory to be created even when our real memoryView doesn't exist
								(Which is the case when Memory tab isn't clicked yet) */

/* Using viewDidLoad as type of constructor to set up things */

- (void)viewDidLoad {
    [super viewDidLoad];
	if (!registersSetup)
		[self setupRegisters];
}

#pragma mark GUI Actions

/* To make keyboard entry go away after user presses "Done" on CodeView */
- (IBAction)textFieldDoneEditing:(id)sender {
	[sender resignFirstResponder];
	[log setText: [self executeInstruction:[newInstruction text]]];
}

/* To make keyboard entry go away after user clicks any blank area on the screen in CodeView */
- (IBAction)codeViewBackgroundClick:(id)sender {
	[newInstruction resignFirstResponder];
}

- (IBAction)testButton:(id)sender {
	[self setRegister:"A3" toValue:123];
	[log setText:@"blah"];
}

- (IBAction)toFromTextFieldDoneEditing:(id)sender {
	[sender resignFirstResponder];
}

- (IBAction)viewMemory:(id)sender {
	if (memorySetup != 2) {
		ptrMemoryView = memoryView;
		if (!memorySetup)
			[self setupMemory];
		memorySetup = 2;
	}
	[memory showMemoryFrom:[self baseToDecimal:(char*)[[from text] UTF8String] type:'$'] to:[self baseToDecimal:(char*)[[to text] UTF8String] type:'$']];	
}

#pragma mark Register methods

/* associates each Register object in registers with the appropriate UIButton in the interface */
- (void)setupRegisters {
	registers[0] = [[Register alloc] initWithValue: 0 corButton: d0];
	registers[1] = [[Register alloc] initWithValue: 0 corButton: d1];
	registers[2] = [[Register alloc] initWithValue: 0 corButton: d2];
	registers[3] = [[Register alloc] initWithValue: 0 corButton: d3];
	registers[4] = [[Register alloc] initWithValue: 0 corButton: d4];
	registers[5] = [[Register alloc] initWithValue: 0 corButton: d5];
	registers[6] = [[Register alloc] initWithValue: 0 corButton: d6];
	registers[7] = [[Register alloc] initWithValue: 0 corButton: d7];
	registers[8] = [[Register alloc] initWithValue: 0 corButton: a0];
	registers[9] = [[Register alloc] initWithValue: 0 corButton: a1];
	registers[10] = [[Register alloc] initWithValue: 0 corButton: a2];
	registers[11] = [[Register alloc] initWithValue: 0 corButton: a3];
	registers[12] = [[Register alloc] initWithValue: 0 corButton: a4];
	registers[13] = [[Register alloc] initWithValue: 0 corButton: a5];
	registers[14] = [[Register alloc] initWithValue: 0 corButton: a6];
	/* PC starts at $1000, A7 starts at $2000, SR starts at 0 */
	registers[15] = [[Register alloc] initWithValue: 0x2000 corButton: a7];
	registers[16] = [[Register alloc] initWithValue: 0x4000 corButton: pc];
	/* SR is handle separately */
	[self setSR: 0];
	/* Clear all registers formatting to start with clean slate */
	[self clearRegistersFormatting];
	registersSetup = true;
}

/* Sets given register to a value, using the backend registers[] array. */
- (void)setRegister:(char*) reg toValue:(int) value {	
	/* sp is a pointer to the Register object corresponding to the register we want to set */
	Register* regptr = [self getRegister:reg];
	if (regptr == NULL) // if NULL, must have asked for SR
		[self setSR: value]; // set SR using special method
	else if ((int)regptr == -1) // -1 is in case of error, so just do nothing
		;
	else {
		/* If we are setting a value, clear formatting of all registers so that only one highlighted red is one we are setting now */
		if (strcmp(reg,"PC") && strcmp(reg, "pc") && strcmp(reg, "A7") && strcmp(reg, "a7"))
			[self clearRegistersFormatting];
		/* set actual value using mutator of Register object -- this takes care of putting it on screen with red color */
		[regptr setValue:value];
	}
}

/* Return the integer (decimal) value of the given register */
- (int)getRegisterValue:(char*) reg {
	Register* regptr = [self getRegister:reg];
	if (regptr == NULL) // if NULL, must have asked for SR
		return SR[1]; // return SR[1] in case of SR since we don't need to get value from Register
	else if ((int)regptr == -1) // -1 is in case of error, so just return -1
		return -1;
	else
		return [regptr getValue];
}

/* Return a pointer to the Register object corresponding to the given register name */
- (Register*)getRegister:(char*) reg {
	/* sp is a pointer to the Register object corresponding to the register we want to get */
	Register* sp = NULL;
	
	NSLog(@"In getRegister. reg: %s", reg);
	
	/* Figure out if register is data, address, PC, or SR, and set *sp appropriately */
	if (reg[0] == 'D' || reg[0] == 'd') sp = registers[reg[1]-'0'];
	else if (reg[0] == 'A' || reg[0] == 'a') sp = registers[8 + (reg[1]-'0')]; // since all A registers are offset by 8 D registers
	else if (!strcmp(reg,"PC") || !strcmp(reg, "pc")) sp = registers[16]; // PC is registers[16]
	
	/* SR is special case since it isn't stored in a Register object */
	else if (!strcmp(reg,"SR") || !strcmp(reg, "sr")) { return NULL; }
	
	/* Error case */
	else return (Register*)-1;
	
	return sp;
}

/* Set value of SR */
- (void)setSR:(int) value {
	/* set actual value for SR, and put on screen with red color, but only if value changed */
	if (SR[1] != value) {
		SR[1] = value; // because user can't modify upper byte (SR[0]), we assign directly to SR[1]
		[sr setTitle:[NSString stringWithFormat:@"%%%08d %08d", SR[0], SR[1]] forState:UIControlStateNormal];
		[sr setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
	}
}

/* Clear formatting for all registers (except SR, which is handled separately) */
- (void)clearRegistersFormatting {
	int i;
	
	for (i = 0; i < 17; i++)
		[registers[i] clearFormatting];
}

#pragma mark Memory Methods

/* sets up Memory object and connects it to memoryView UITextView */
- (void)setupMemory {
	memory = [[Memory alloc] initWithMemoryView: &ptrMemoryView];
	memorySetup = true;
}

#pragma mark Instruction Execution Methods

- (NSString*)executeInstruction:(NSString*)instruction {
	char* opcode = "";
	char size = '\0';
	int src;
	char* oldval;
	char* dest;
	char newval[9];
	int mem_addr = 0;
	int i = 0;
	
	/* Make sure memory exists */
	if (!memorySetup)
		[self setupMemory];
	
	/* Convert incoming NSString from UITextField into C String for easier parsing */
	const char* cstr = [[instruction lowercaseString] UTF8String];
	char* instr = (char*) malloc(sizeof(char) * strlen(cstr));
	strcpy(instr, cstr);
	//NSLog(@"%s", instr);
	
	/* Create buffer which will be used to hold parts of instruction as we parse it */
	char* buffer = (char*)malloc(sizeof(char)*1024);
	
	/* Parse out opcode and size (if present) */
	bool st_opcode = false;	// state of whether opcode was parsed out yet or not
	while (*instr) {
		if (st_opcode && *instr == ' ') // effectively strips spaces from instruction
			*instr++;
		else if (!st_opcode && (*instr == ' ' || *instr == '.')) {
			st_opcode = true; // set state
			buffer[i] = '\0'; // null-terminate string
			opcode = (char*) malloc(sizeof(char) * strlen(buffer)); // allocate space for opcode, now that it's in buffer
			strcpy(opcode, buffer); // copy opcode string into 'opcode' variable
			i = 0; // reset buffer pointer
			if (*instr++ == '.') { // we have a size, so get it
				size = *instr++;
				if (size != 'b' && size != 'w' && size != 'l') {// make sure size is one of the allowed types
					return @"Failed to parse instruction: Possible Incorrect Size Specified";
				}
			}
		} else {
			buffer[i++] = *instr++;
		}
	}
	buffer[i] = '\0';
	NSLog(@"%s\n%c\n%s", opcode, size, buffer);
	
	if (opcode == "")
		return @"Failed to parse instruction: No Opcode?";
	if (!strcmp(opcode,"move")) {
		if (size == '\0')
			return @"Failed to parse instruction: MOVE requires size";
		if ((src = [self getSourceFromCString: &buffer size:size]) != -1) { /* when src returns, it contains the string value (in decimal) 
																			   that will be assigned to dest */
			/* Move buffer by 1, because getSourceFromCString leaves the comma separator */
			buffer++;
			if ((dest = [self getDestinationFromCString: &buffer size:size]) != NULL) { /* when dest returns, it contains either the register or memory
																				location that will receive the SRC value from above */
				
				/* Parse the dest return variable to see if it's a register or memory location. */
				if (dest[0] == 'a' || dest[0] == 'd') { /* must be register */
					/* In case of registers, we must take care to only set LOWER byte/word/longword. We do this here: */
					/* If SRC value less than full Long Word, pad with enough content from old value */
					oldval = (char*)[[[[[self getRegister:dest] correspondingButton] currentTitle] substringFromIndex:1] UTF8String];
					if (size == 'b') {
						strncpy(newval, oldval, 6);
						sprintf(newval+6, "%02x", src);
					} else if (size == 'w') {
						strncpy(newval, oldval, 4);
						sprintf(newval+4, "%04x", src);
					} else
						sprintf(newval, "%08x", src);
					/* newval is correct value, in hex string form; put it into src as decimal int */
					sscanf(newval, "%08x", &src);
					[self setRegister: dest toValue: src];
					[self setRegister: "pc" toValue: [self getRegisterValue:"pc"] + 1];
					[previousInstructions setText:[instruction stringByAppendingFormat:@"\n%@",[previousInstructions text]]];
					return [NSString stringWithFormat:@"Successfully moved %d into %s", src, dest];
				} else {
					/* In the case of memory, we can just set using method of the Memory object, since that handles sizes internally */
					/* But first we have to convert string version of memory address to int */
					mem_addr = atoi(dest);
					[memory setMemoryAt:mem_addr to:src size:size];
					[self setRegister: "pc" toValue: [self getRegisterValue:"pc"] + 1];
					[previousInstructions setText:[instruction stringByAppendingFormat:@"\n%@",[previousInstructions text]]];
					return [NSString stringWithFormat:@"Set memory location at %d to %d", mem_addr, src];
				}
			} else
				return @"Failed to parse instruction: Problem reading destination of MOVE instruction";
		} else
			return @"Failed to parse instruction: Problem reading source of MOVE instruction";
	} else {
		return @"Unknown opcode";
	}
	free(buffer);
	free(instr);
}

/* Will return the value referred to by either a register or a memory location, depending on what the SOURCE was.
 In the event of any shifting/increments/decrements, it does the valid action and then uses the new address (@) AFTER calculations
 ( which means the calling function doesn't need to worry about how the value was reached */
- (int)getSourceFromCString: (char**) buffer size: (char) size {
	/* setup char buffers used to format return value */
	char reg[3];
	char numberstr[33];// max number size is 32 bits, all specified in binary
	bzero(reg, 3);
	bzero(numberstr, 33);
	
	int oldval = 0;
	int i, sizemask, numberval;
	
	/* error checking */
	if (buffer == NULL || *buffer == NULL) return -1;
	
	/* setup sizemask. Used to only return lower Byte/Word/LongWord of value */
	switch (size) {
		case 'b':
			sizemask = 0x000000ff;
			break;
		case 'w':
			sizemask = 0x0000ffff;
			break;
		case 'l':
			sizemask = 0xffffffff;
			break;
		default:
			sizemask = 0x00000000;
			break;
	}
	
	/* Parse the first character of the source to determine addressing mode, then get value appropriately */
	char type = '\0';
	bool number = false;
	bool immediate = false;
	bool predec = false;
	NSLog(@"1");
	if (**buffer == '#') { /* Must be immediate value beginning */
		NSLog(@"Immediate = true");
		*(*buffer)++;
		immediate = true;
	}
	if (**buffer == '%' || **buffer == '$') { /* Must be absolute binary/hex (respectively) address beginning */
		NSLog(@"in buffer == '%' or '$'");
		type = 	*(*buffer)++;
		number = true;
	}
	else if (**buffer >= '0' && **buffer <= '9') { /* Must be absolute decimal address beginning */
		NSLog(@"in buffer == '0' thru '9'");
		type = 'd';
		number = true;
	}
	if (immediate && !number) /* A # must be followed by a number! */
		return -1;
	if (number) { /* If expecting a number, read it into numberstr and convert to int numberval */
		NSLog(@"reading number literal");
		i = 0;
		while ((type == '%' && **buffer == '0' || **buffer == '1') ||
			   (type == 'd' && **buffer >= '0' && **buffer <= '9') || 
			   (type == '$' && ((**buffer >= '0' && **buffer <= '9') || (**buffer >= 'a' && **buffer <= 'f'))))
			numberstr[i++] = *(*buffer)++;
		NSLog(@"numberstr:%s", numberstr);
		/* convert string numberstr into an int (decimal) representing the number */
		numberval = [self baseToDecimal:numberstr type:type];
		NSLog(@"got number val as %d", numberval);
		/* Now check the char after the number to determine exactly what @ mode we have */
		if (**buffer == '(') {
			if (immediate) return -1; // #xxx( is invalid
			*(*buffer)++; // skip paren
			/* Put register into reg */
			reg[0] = *(*buffer)++;
			reg[1] = *(*buffer)++;
			if (reg[0] != 'a') return -1; // must use A register in this type of address mode
			if (**buffer == ')') { // we're done, we know it was xxx(An)
				return [memory getMemoryAt:[self getRegisterValue:reg]+numberval size: size];
			}
			if (**buffer == ',') { // we're done, we know it was xxx(An,Xn.S)
				oldval = [self getRegisterValue:reg]+numberval;
				// oldval is now (An) + xxx. We now need to extract Xn.S and add the appropriate value
				*(*buffer)++; // skip comma
				reg[0] = *(*buffer)++;
				reg[1] = *(*buffer)++;
				*(*buffer)++; // skip period
				size = *(*buffer)++;
				if (*(*buffer)++ != ')' || **buffer != ',') // syntax error if we have xxx(An,Xn.S_ or xxx(An,Xn.S)_
					return -1;
				/* set up sizemask again (we have new register and size). Used to only return lower Byte/Word/LongWord of value */
				switch (size) {
					case 'w':
						sizemask = 0x0000ffff;
						break;
					case 'l':
						sizemask = 0xffffffff;
						break;
					default:
						return -1; // only .w or .l is allowed for this type of @ mode
				}
				return [memory getMemoryAt: oldval + ([self getRegisterValue:reg] & sizemask) size: size];; // add Xn.S to oldval and return total sum
				
			} else return -1; // means we have xxx(An_ where _ is not , or ).. illegal
		} else if (**buffer == ',') {
			if (immediate) { // we're done, we know it was #xxx (immediate value)
				return numberval & sizemask;
			} else { // we're done, we know it was xxx (absolute address)
				return [memory getMemoryAt:numberval size:size];
			}
		} else return -1; // invalid ... we have [|#]xxx[^,(] which doesn't correspond to anything
	}
	
	NSLog(@"2");
	// handle (An), -(An), and (An)+ cases
	if (**buffer == '-') {
		*(*buffer)++;
		predec = true;
	}
	if (**buffer == '(') {
		NSLog(@"in buffer == '('");
		*(*buffer)++; /* Skip the paren */
		/* Read @ register into reg */
		reg[0] = *(*buffer)++;
		reg[1] = *(*buffer)++;
		if (reg[0] != 'a') return -1; // must have address register inside parens
		if (*(*buffer)++ == ')') {
			if (predec) { // we're done. we know it was -(An)
				/* Get oldval, decrement register and olval (since it is a PRE-decrement) */
				oldval = [self getRegisterValue:reg];
				if (size == 'b' && oldval > 0)
					oldval -= 1;
				else if (size == 'w' && oldval > 1)
					oldval -= 2;
				else if (oldval > 3)
					oldval -= 4;
				[self setRegister:reg toValue:oldval];
				return [memory getMemoryAt:oldval size: size];
			}
			if (**buffer == '+') { // we're done. we know it was (An)+
				*(*buffer)++;
				/* Get oldval, increment register but not oldval (since it is POST-increment) */
				oldval = [self getRegisterValue:reg];
				if (size == 'b' && oldval < 0xffffffff)
					[self setRegister:reg toValue:oldval+1];
				else if (size == 'w' && oldval < 0xfffffffe)
					[self setRegister:reg toValue:oldval+2];
				else if (oldval < 0xfffffffc)
					[self setRegister:reg toValue:oldval+4];				
				return [memory getMemoryAt:oldval size: size];
			}
			if (**buffer == ',') { // we're done. we know it was (An)
				return [memory getMemoryAt:[self getRegisterValue:reg] size: size];
			}
			return -1; // there is an error if we had (An) followed by something other than a + or ,
		}
	}
	/* Case where we are directly referencing registers */
	if (**buffer == 'a' || **buffer == 'd') {
		reg[0] = *(*buffer)++;
		reg[1] = *(*buffer)++;
		return [self getRegisterValue:reg] & sizemask;
	}
	NSLog(@"3");
	return -1;
}

/* Will return the name of the register or address of memory location (as a string), depending on what the DESTINATION was.
 In the event of any shifting/increments/decrements, it does the valid action and then uses the new address (@) AFTER calculations
 ( which means the calling function doesn't need to worry about how the value was reached */
- (char*)getDestinationFromCString: (char**) buffer size:(char)size {
	
	/* setup char buffers used to format return value */
	char reg[3];
	char numberstr[33];// max number size is 32 bits, all specified in binary
	bzero(reg, 3);
	bzero(numberstr, 33);
	
	int oldval = 0, sizemask;
	int i, numberval;
	
	/* error checking */
	if (buffer == NULL || *buffer == NULL) return NULL;
	
	/* Setup return buffer */
	char* ret = (char*)malloc(sizeof(char)*10);
	
	/* Parse the first character of the destination to determine addressing mode, then get value appropriately */
	char type = '\0';
	bool number = false;
	bool predec = false;
	NSLog(@"1");
	if (**buffer == '#') { /* Must be immediate. Forget what the number is; immediate addressing illegal for destination! */
		return NULL;
	}
	if (**buffer == '%' || **buffer == '$') { /* Must be absolute binary/hex (respectively) address beginning */
		NSLog(@"in buffer == '%' or '$'");
		type = 	*(*buffer)++;
		number = true;
	}
	else if (**buffer >= '0' && **buffer <= '9') { /* Must be absolute decimal address beginning */
		NSLog(@"in buffer == '0' thru '9'");
		type = 'd';
		number = true;
	}
	if (number) { /* If expecting a number, read it into numberstr and convert to int numberval */
		NSLog(@"reading number literal");
		i = 0;
		while ((type == '%' && **buffer == '0' || **buffer == '1') ||
			   (type == 'd' && **buffer >= '0' && **buffer <= '9') || 
			   (type == '$' && ((**buffer >= '0' && **buffer <= '9') || (**buffer >= 'a' && **buffer <= 'f'))))
			numberstr[i++] = *(*buffer)++;
		NSLog(@"numberstr:%s", numberstr);
		/* convert string numberstr into an int (decimal) representing the number */
		numberval = [self baseToDecimal:numberstr type:type];
		NSLog(@"got number val as %d", numberval);
		/* Now check the char after the number to determine exactly what @ mode we have */
		if (**buffer == '(') {
			*(*buffer)++; // skip paren
			/* Put register into reg */
			reg[0] = *(*buffer)++;
			reg[1] = *(*buffer)++;
			if (reg[0] != 'a') return NULL; // must use A register in this type of address mode
			if (**buffer == ')') { // we're done, we know it was xxx(An)
				sprintf(ret, "%d", [self getRegisterValue:reg]+numberval);
				return ret;
			}
			if (**buffer == ',') { // we're done, we know it was xxx(An,Xn.S)
				oldval = [self getRegisterValue:reg]+numberval;
				// oldval is now (An) + xxx. We now need to extract Xn.S and add the appropriate value
				*(*buffer)++; // skip comma
				reg[0] = *(*buffer)++;
				reg[1] = *(*buffer)++;
				*(*buffer)++; // skip period
				size = *(*buffer)++;
				if (*(*buffer)++ != ')' || **buffer != '\0') // syntax error if we have xxx(An,Xn.S_ or xxx(An,Xn.S)_
					return NULL;
				/* set up sizemask. Used to only return lower Byte/Word/LongWord of value in Xn*/
				switch (size) {
					case 'w':
						sizemask = 0x0000ffff;
						break;
					case 'l':
						sizemask = 0xffffffff;
						break;
					default:
						return NULL; // only .w or .l is allowed for this type of @ mode
				}
				/* add Xn.S to oldval and return total sum */
				sprintf(ret, "%d", oldval + ([self getRegisterValue:reg] & sizemask));
				return ret;
				
			} else return NULL; // means we have xxx(An_ where _ is not , or ).. illegal
		} else if (**buffer == '\0') { // we're done, we know it was xxx (absolute address) (since there's no immediate in DESTINATION
			sprintf(ret, "%d", numberval);
			return ret;
		} else {
			NSLog(@"<%s>", *buffer);
			return NULL; // invalid ... we have [|#]xxx[^,(] which doesn't correspond to anything
		}
	}
	
	NSLog(@"2");
	/* handle (An), -(An), and (An)+ cases */
	if (**buffer == '-') {
		*(*buffer)++;
		predec = true;
	}
	if (**buffer == '(') {
		NSLog(@"in buffer == '('");
		*(*buffer)++; /* Skip the paren */
		/* Read @ register into reg */
		reg[0] = *(*buffer)++;
		reg[1] = *(*buffer)++;
		if (reg[0] != 'a') return NULL; // must have address register inside parens
		if (*(*buffer)++ == ')') {
			if (predec) { // we're done. we know it was -(An)
				/* Get oldval, decrement register and olval (since it is a PRE-decrement) */
				oldval = [self getRegisterValue:reg];
				if (size == 'b' && oldval > 0)
					oldval -= 1;
				else if (size == 'w' && oldval > 1)
					oldval -= 2;
				else if (oldval > 3)
					oldval -= 4;
				[self setRegister:reg toValue:oldval];
				sprintf(ret, "%d", oldval);
				return ret;
			}
			if (**buffer == '+') { // we're done. we know it was (An)+
				*(*buffer)++;
				/* Get oldval, increment register but not oldval (since it is POST-increment) */
				oldval = [self getRegisterValue:reg];
				if (size == 'b' && oldval < 0xffffffff)
					[self setRegister:reg toValue:oldval+1];
				else if (size == 'w' && oldval < 0xfffffffe)
					[self setRegister:reg toValue:oldval+2];
				else if (oldval < 0xfffffffc)
					[self setRegister:reg toValue:oldval+4];
				sprintf(ret, "%d", oldval);
				return ret;
			}
			if (**buffer == '\0') { // we're done. we know it was (An)
				sprintf(ret, "%d", [self getRegisterValue:reg]);
				return ret;
			}
			return NULL; // there is an error if we had (An) followed by something other than a + or ,
		}
	}
	/* Case where we are directly referencing registers */
	if (**buffer == 'a' || **buffer == 'd') {
		reg[0] = *(*buffer)++;
		reg[1] = *(*buffer)++;
		strcpy(ret, reg);
		return ret;
	}
	NSLog(@"3");
	return NULL;
}

#pragma mark My Helper Methods

/* Converts given number (given as C string) from given type (either decimal, hex, or binary) to decimal number (as int) */
- (int)baseToDecimal: (char*)number type:(char) type {
	int base;
	int weight;
	int i;
	char tmp;
	int retval = 0;
	
	if (type == 'd') return atoi(number);
	if (type == '%') base = 2;
	else if (type == '$') base = 16;
	else base = 10;
	for (i = 1, weight = 1; i < strlen(number); i++)
		weight *= base;
	for (i = 0; weight >= 1; i++) {
		if (number[i] >= 'a' && number[i] <= 'f')
			tmp = number[i] - 'a' + 10;
		else if (number[i] >= 'A' && number[i] <= 'F')
			tmp = number[i] - 'A' + 10;
		else
			tmp = number[i] - '0';
		retval += tmp * weight;
		weight /= base;
	}
	return retval;
}

#pragma mark Standard iPhone Methods

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end

<?php 

/////////////////////////////////////
/// CONFIGURE THESE OPTIONS ////////
////////////////////////////////////

$hash = "blah"; // This can be any string. It must match in PHP script and GM script. It's just so there's a little bit of authentication.
$password_hash = "098f6bcd4621d373cade4e832627b4f6"; // the hashed (md5) password needed to access the chat log viewer
$db_user = 'user'; // The username of someone with access to your DB
$db_pass = 'my_pass'; // the password of that user
$db_host = 'localhost'; // the URL of the database server (usually localhost if this is on a shared hosting provider)
$db_db = 'fb'; // the name of the database which will store the conversations

?>
<?php

// Frontend script for Facebook Chat Logger
// by Rob Williams - http://robwilliams.me

require("config.php");

/////////////////////////////////////
/// DON'T MODIFY BELOW HERE ////////
////////////////////////////////////

$authenticated = 0;
if (isset($_COOKIE['password'])) {
	if ($_COOKIE['password'] != $password_hash) {
		echo "Error: Bad cookie!";
		exit();
	}
	$authenticated = 1;
} else {
	if (isset($_POST['password'])) {
		if (md5($_POST['password']) != $password_hash) {
			echo "Error: Bad password!";
			exit();
		}
		// password is good so set cookie and continue
		setcookie('password', $password_hash, 60*60*24*60 + time());
		$authenticated = 1;
	} else {
		// show form
		?>
		<html>
		<head>
			<title>Facebook Chat Log Viewer</title>
			<style type="text/css" media="screen">
				@import url( style.css );
			</style>
		</head>
		<body>
		<form action='index.php' method='post'>
			Password: <input type='password' name='password'/> <br/>
			<input type='submit' value='Submit'/>
		</form>
	<?php
	}
}

if ($authenticated) {
	// load database class, and connect
	require("./databaseClass.php");
	$db = new database();
	$db->setup($db_user,$db_pass,$db_host,$db_db);
	
	if (!isset($_GET['mode']))
		$mode = "recent";
	else
		$mode = $_GET['mode'];
?>

<html>
<head>
	<title>Facebook Chat Log Viewer</title>
	<style type="text/css" media="screen">
		@import url( style.css );
	</style>
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("a.fetch").click(function(event){
				$("h4#title").html(this.innerHTML);
		    	$.get(this.href, function(data){
					$("pre#conversation").html(data);
				 });
				event.preventDefault();
		   	});
			$('#search').submit(function() {
				var keyword = $('#keyword').val();
				$("h4#title").html("Search for '" + keyword + "'");
				$.get("fetch.php?keyword=" + escape(keyword), function(data) {
					$("pre#conversation").html(data);
				});
				$('#keyword').val("");
			});
		});
	</script>
 
</head>
<body>
<div id="container">
	<div id="header"><h1>Facebook Chat Log Viewer</h1></div>
	<div id="sidebar">
		View By: 
		<?php
			if ($mode != "recent")
				echo "<a href='index.php?mode=recent'>Most Recent</a>";
			else
				echo "Most Recent";
			echo " | ";
			if ($mode != "friends")
				echo "<a href='index.php?mode=friends'>Friends</a>";
			else
				echo "Friends";
			echo " | ";
			if ($mode != "dates")
				echo "<a href='index.php?mode=dates'>Dates</a>";
			else
				echo "Dates";
		?>
		<br/>
		<form id="search" onsubmit='return false;' method='get'>
			<input type='text' name='keyword' id="keyword"/> <input type='submit' value='Search'/>
		</form>
		
		<?php
			
			echo "<ul>";
			if ($mode == "recent") {
				$sql = "SELECT U.name, C.date, U.id FROM users U JOIN chats C ON U.id=C.user_id ORDER BY C.date DESC;";
				$db->send_sql($sql);
				while (false !== ($row = $db->next_row())) {
					echo "<li><a class='fetch' href='fetch.php?id=" . $row[2] . "&date=" . $row[1] . "'>" . $row[0] . " - " . $row[1] . "</a></li>";
				}
			} else if ($mode == "friends") {
				$sql = "SELECT U.name, U.id FROM users U ORDER BY U.name ASC;";
				$db->send_sql($sql);
				while (false !== ($row = $db->next_row())) {
					echo "<li><a class='fetch' href='fetch.php?id=" . $row[1] . "'>" . $row[0] . "</a></li>";
				}
			} else if ($mode == "dates") {
				$sql = "SELECT C.date FROM chats C GROUP BY C.date;";
				$db->send_sql($sql);
				while (false !== ($row = $db->next_row())) {
					echo "<li><a class='fetch' href='fetch.php?date=" . $row[0] . "'>" . $row[0] . "</a></li>";
				}
			}
			
		?>
		</ul>
	</div>
	<div id="main">
		<h4 id="title"></h2>
		<pre id="conversation">
		</pre>
	</div>
</div>
</body>
</html>

<?php
}
?>
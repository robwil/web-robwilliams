<?php

// Fetch (middle) script for Facebook Chat Logger
// by Rob Williams - http://robwilliams.me

require("config.php");

/////////////////////////////////////
/// DON'T MODIFY BELOW HERE ////////
////////////////////////////////////

// load database class, and connect
require("./databaseClass.php");
$db = new database();
$db->setup($db_user,$db_pass,$db_host,$db_db);

if (isset($_GET['id']) && isset($_GET['date'])) {
	$sql = "SELECT C.content FROM users U JOIN chats C ON U.id=C.user_id WHERE U.id='" . $_GET['id'] . "' AND C.date='" . $_GET['date'] . "';";
	$db->send_sql($sql);
	$row = $db->next_row();
	echo $row[0];
} else if (isset($_GET['id'])) {
	$sql = "SELECT C.content, C.date FROM users U JOIN chats C ON U.id=C.user_id WHERE U.id='" . $_GET['id'] . "';";
	$db->send_sql($sql);
	while (false !== ($row = $db->next_row())) {
		echo "======= " . $row[1] . " =======\n";
		echo $row[0] . "\n\n";
	}
} else if (isset($_GET['date'])) {
	$sql = "SELECT C.content, U.name FROM users U JOIN chats C ON U.id=C.user_id WHERE C.date='" . $_GET['date'] . "';";
	$db->send_sql($sql);
	while (false !== ($row = $db->next_row())) {
		echo "======= " . $row[1] . " =======\n";
		echo $row[0] . "\n\n";
	}
} 	else if (isset($_GET['keyword'])) {
	$sql = "SELECT C.content, U.name, C.date FROM users U JOIN chats C ON U.id=C.user_id WHERE C.content LIKE '%" . $_GET['keyword'] . "%';";
	$db->send_sql($sql);
	while (false !== ($row = $db->next_row())) {
		echo "======= " . $row[1] . " - " . $row[2] . " =======\n";
		echo $row[0] . "\n\n";
	}
} else {
	echo "Bad GET data.";
}

?>


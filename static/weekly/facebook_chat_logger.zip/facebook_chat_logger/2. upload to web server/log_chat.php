<?php

// Backend script for Facebook Chat Logger
// by Rob Williams - http://robwilliams.me

require("config.php");

/////////////////////////////////////
/// DON'T MODIFY BELOW HERE ////////
////////////////////////////////////

if (isset($_POST['id']) && isset($_POST['name']) && isset($_POST['content']) && isset($_POST['hash'])) {
	$id = $_POST['id'];
	$name = $_POST['name'];
	$content = cleanup_html(urldecode($_POST['content'])); // cleanup_html defined below
	
	if ($_POST['hash'] != $hash) {
		echo "Error: Failed to authenticate.";
		exit();
	}
	
	// load database class, and connect
	require("./databaseClass.php");
	$db = new database();
	$db->setup($db_user,$db_pass,$db_host,$db_db);
	
	// record user information
	$sql = "INSERT INTO users(id, name, count) VALUES('" . mysql_real_escape_string($id) . "', '" . mysql_real_escape_string($name) . "', 0) ON DUPLICATE KEY UPDATE name='" . mysql_real_escape_string($name) . "', count=count+1;";
	$db->send_sql($sql);
	if ($db->affected_rows() < 1) {
		echo "Error: Couldn't add user info to DB.";
		exit();
	}

	// fetch old content from DB so we can compare and merge with new content
	$oldcontent = "";
	$sql = "SELECT content FROM chats WHERE user_id='" . mysql_real_escape_string($id) . "' AND date=CURDATE();";
	$db->send_sql($sql);
	while (false !== ($row = $db->next_row())) {
		$oldcontent = $row[0];
	}
	
	// if their not the same, merge then add to DB
	if ($oldcontent != $content) {
		$content = merge_content($oldcontent, $content); // merge_content defined below
		
		$sql = "INSERT INTO chats(user_id, date, content) VALUES('" . mysql_real_escape_string($id) . "', CURDATE(), '" . mysql_real_escape_string($content) . "') ON DUPLICATE KEY UPDATE content = '" . mysql_real_escape_string($content) . "';";
		$db->send_sql($sql);
		if ($db->affected_rows() < 1) {
			echo "Error: Couldn't add chat log into DB.";
			exit();
		}
		//echo "done.";
	} else {
		//echo "Nothing changed.";
	}
} else {
	echo "Error: POSTDATA corrupted.";
}

// cleanup_html takes the raw HTML from the Facebook chat window and converts it to a plain text format like so:
// Me (5:29 p.m.): Hey what's up
// Fred (5:30 p.m.): Nothing much..
// Fred (5:30 p.m.): You?
// which makes it easier to merge, and it's also easier to store in DB
function cleanup_html($html) {
	$ret = "";
	$html = stripslashes($html);
	// make DOM object to parse HTML
	$dom = new DOMDocument;
    $dom->loadHTML($html);
    $dom->preserveWhiteSpace = false;
	
	// get HTML information into DOM Node Lists for parsing
	$labels = $dom->getElementsByTagName('h5'); // user labels e.g., "Rob", "Dan" stored in <h5> tags, also has the timestamp
	$texts = $dom->getElementsByTagName('p'); // user's conversation text is stored in <p> tags
	
	// move through data
	$j = 0;
	for ($i = 0; $i < $labels->length && $j < $texts->length; $i++) {
		// extra whether current message is "self" or "other"
		$label = $labels->item($i)->attributes->getNamedItem("class")->nodeValue;
		// get timestamp node for the message
		$time = $labels->item($i)->getElementsByTagName('span')->item(0);
		// first time through, extract other person's name for display purposes
		if (!isset($name) && $label == "other") {
			$labels->item($i)->removeChild($time);
			$name = trim($labels->item($i)->nodeValue);
		}
		// extract time value from node
		$time = $time->nodeValue;	
		// $label is now set to the class it's expecting the messages to have
		$label = ($label == "self") ? "p_self pic_padding" : "p_other pic_padding";
		// $node is the first message under the label
		$node = $texts->item($j);
		$node = $node->attributes->getNamedItem("class")->nodeValue;
		// go through all messages below the label which belong to that person, and print all out using appropriate name and time from above
		while ($node == $label) {
			$text = $texts->item($j)->nodeValue;
			$ret .= ($label == "p_self pic_padding") ? "Me ($time): $text\n" : "$name ($time): $text\n";
			$j = $j + 1;
			$node = $texts->item($j);
			if ($node)
				$node = $node->attributes->getNamedItem("class")->nodeValue;
		}
	}

	return $ret; // return newly formatted text
	
}


// merge_content will take two conversations and merge them, so that there is no redundant data
// but also making sure it doesn't lose any of the old info. This is mostly done because FB randomly
// truncates conversations (I guess to save storage on their )
function merge_content($old, $new) {
	$ret = "";
	// we want to process each content line-by-line so explode into arrays of each line
	$old = explode("\n", $old);
	$new = explode("\n", $new);
	
	// move through old array, until we find a line it shares with new array
	for ($i = 0; $i < count($old); $i++) {
		if ($old[$i] == $new[0]) break;
		$ret .= $old[$i] . "\n";
	}
	// copy new into ret
	for ($i = 0; $i < count($new); $i++) {
		$ret .= $new[$i] . "\n";
	}
	
	return $ret;
}




?>